#pragma semicolon 1

#include <celmod>

#pragma newdecls required

#define LAND_MODEL "models/error.mdl"

bool g_bLandColor[MAXPLAYERS + 1];

ArrayList g_alSkinTiles[MAXPLAYERS + 1];
ConVar g_cvSkinTexture;
ConVar g_cvSkinTile;
int g_iLandSkin[MAXPLAYERS + 1];
bool g_bLate;

#define LANDSKIN_COUNT 26

ConVar g_cvMaxLandSize;

float g_fMaxLandSize;

Handle g_hGettingTop[MAXPLAYERS+1];
Handle g_hLandTimer[MAXPLAYERS+1];

int g_iBeam = -1;
int g_iCurrentLandEntity[MAXPLAYERS + 1];
int g_iCurrentLandOwner[MAXPLAYERS + 1];
int g_iHalo = -1;
int g_iLand = -1;
int g_iLandColor[MAXPLAYERS + 1][3];
int g_iLandEntOwner[MAXENTITIES + 1];
int g_iLaser = -1;
int g_iPhys = -1;

enum struct Land {
	bool bGodMode;
	bool bInCoopMode;
	bool bInDeathmatchMode;
	bool bInShopMode;
	bool bInsideLand;
	bool bLandCreated;
	bool bLandDrawing;
	bool bLandGettingTopPos;
	bool bModeCoop;
	bool bModeDeathmatch;
	bool bModeShop;
	
	float fLandGravity;
	float fLandPosBottom[3];
	float fLandPosBottomMiddle[3];
	float fLandPosBottomTop[3];
	float fLandPosStarting[3];
	float fLandPosTop[3];
	
	int iLandEntity;
	int iLandOwner;
	int iLandStage;
}

Land g_liLand[MAXPLAYERS+1];

public APLRes AskPluginLoad2(Handle hMyself, bool bLate, char[] sError, int iErr_max)
{
	CreateNative("Cel_ClearLand", Native_ClearLand);
	CreateNative("Cel_CreateLand", Native_CreateLand);
	CreateNative("Cel_DrawLandBorders", Native_DrawLandBorders);
	CreateNative("Cel_GetCurrentLandEntity", Native_GetCurrentLandEntity);
	CreateNative("Cel_GetCurrentLandOwner", Native_GetCurrentLandOwner);
	CreateNative("Cel_GetLandEntity", Native_GetLandEntity);
	CreateNative("Cel_GetLandGravity", Native_GetLandGravity);
	CreateNative("Cel_GetLandOwner", Native_GetLandOwner);
	CreateNative("Cel_GetLandOwnerFromEntity", Native_GetLandOwnerFromEntity);
	CreateNative("Cel_GetLandOwnerFromPosition", Native_GetLandOwnerFromPosition);
	CreateNative("Cel_GetLandPositions", Native_GetLandPositions);
	CreateNative("Cel_GetMiddleOfABox", Native_GetMiddleOfBox);
	CreateNative("Cel_IsClientCrosshairInLand", Native_IsClientCrosshairInLand);
	CreateNative("Cel_IsClientInLand", Native_IsClientInLand);
	CreateNative("Cel_IsEntityInLand", Native_IsEntityInLand);
	CreateNative("Cel_IsLandCreated", Native_IsLandCreated);
	CreateNative("Cel_IsPositionInBox", Native_IsPositionInBox);
	CreateNative("Cel_SetLandGravity", Native_SetLandGravity);
	CreateNative("Cel_SetCurrentLandEntity", Native_SetCurrentLandEntity);
	CreateNative("Cel_SetCurrentLandOwner", Native_SetCurrentLandOwner);
	
	g_bLate = bLate;
	
	return APLRes_Success;
}

public Plugin myinfo =
{
	name = "|CelMod| Land",
	author = CEL_AUTHOR,
	description = "Creates a personal building area.",
	version = CEL_VERSION,
	url = CEL_URL
};

public void OnPluginStart()
{
	LoadTranslations("celmod.phrases");
	
	if (g_bLate)
	{
		for (int i = 1; i < MaxClients; i++)
		{
			if (IsClientAuthorized(i))
			{
				OnClientPutInServer(i);
			}
		}
	}
	
	g_cvMaxLandSize = CreateConVar("cm_max_land_size", "1495.5", "Maximum land size allowed.");
	
	g_cvMaxLandSize.AddChangeHook(CMLand_OnConVarChanged);
	
	g_fMaxLandSize = g_cvMaxLandSize.FloatValue;
	
	AutoExecConfig(true, "celmod.land");
	
	RegConsoleCmd("v_coop", Command_LandCoop, "|CelMod| Changes the mode to co-op within the land.");
	RegConsoleCmd("v_deathmatch", Command_LandDeathmatch, "|CelMod| Changes the mode to deathmatch within the land.");
	RegConsoleCmd("v_dm", Command_LandDeathmatch, "|CelMod| Changes the mode to deathmatch within the land.");
	RegConsoleCmd("v_gravity", Command_LandGravity, "|CelMod| Changes the gravity within the land.");
	g_cvSkinTile = CreateConVar("cm_landskin_tile", "512", "Size in units of each land skin tile laid over a land's floor.", _, true, 64.0, true, 2048.0);
	g_cvSkinTexture = CreateConVar("cm_landskin_texture", "512", "Size in pixels of the land skin textures; sets how big each tile is drawn.", _, true, 16.0);
	
	for (int i = 0; i <= MAXPLAYERS; i++)
	{
		g_alSkinTiles[i] = new ArrayList();
	}
	
	RegConsoleCmd("v_landskin", Command_LandSkin, "|CelMod| Covers the floor of your land with a land skin (1 to 26), or removes it (off).");
	RegConsoleCmd("v_landcolor", Command_LandColor, "|CelMod| Changes the color of your land's border.");
	RegConsoleCmd("v_land", Command_Land, "|CelMod| Creates a building zone.");
	RegConsoleCmd("v_landcoop", Command_LandCoop, "|CelMod| Changes the mode to co-op within the land.");
	RegConsoleCmd("v_landdeathmatch", Command_LandDeathmatch, "|CelMod| Changes the mode to deathmatch within the land.");
	RegConsoleCmd("v_landgravity", Command_LandGravity, "|CelMod| Changes the gravity within the land.");
	RegConsoleCmd("v_landshop", Command_LandShop, "|CelMod| Changes the mode to shop (merchant) within the land.");
	RegConsoleCmd("v_shop", Command_LandShop, "|CelMod| Changes the mode to shop (merchant) within the land.");
}

public void OnClientPutInServer(int iClient)
{
	Cel_ClearLand(iClient);
	
	g_bLandColor[iClient] = false;
	
	SDKHook(iClient, SDKHook_OnTakeDamage, Hook_CoopDamage);
	
	g_iLandSkin[iClient] = Cel_GetClientSettingInt(iClient, "landskin");
	
	if (g_iLandSkin[iClient] < 1 || g_iLandSkin[iClient] > LANDSKIN_COUNT)
	{
		g_iLandSkin[iClient] = 0;
	}
	
	g_hGettingTop[iClient] = CreateTimer(0.1, Timer_GettingTop, GetClientUserId(iClient), TIMER_REPEAT);
	g_hLandTimer[iClient] = CreateTimer(0.1, Timer_Land, GetClientUserId(iClient), TIMER_REPEAT);
}

public void OnClientDisconnect(int iClient)
{
	Cel_ClearLand(iClient);
	
	if(g_hGettingTop[iClient] != INVALID_HANDLE)
	{
		CloseHandle(g_hGettingTop[iClient]);
	}
	
	if(g_hLandTimer[iClient] != INVALID_HANDLE)
	{
		CloseHandle(g_hLandTimer[iClient]);
	}
}

public void OnMapStart()
{
	g_iBeam = PrecacheModel("materials/sprites/laserbeam.vmt");
	g_iHalo = PrecacheModel("materials/sprites/halo01.vmt");
	g_iLand = PrecacheModel("materials/sprites/spotlight.vmt");
	g_iLaser = PrecacheModel("materials/sprites/laser.vmt");
	g_iPhys = PrecacheModel("materials/sprites/physbeam.vmt");
}

public void OnMapEnd()
{
	g_iBeam = -1;
	g_iHalo = -1;
	g_iLand = -1;
	g_iLaser = -1;
	g_iPhys = -1;
}

public void CMLand_OnConVarChanged(ConVar cvConVar, const char[] sOldValue, const char[] sNewValue)
{
	if (cvConVar == g_cvMaxLandSize)
	{
		g_fMaxLandSize = g_cvMaxLandSize.FloatValue;
		PrintToServer("|CelMod| Max land size updated to %s.", sNewValue);
	}
}

//Commands:
public Action Command_Land(int iClient, int iArgs)
{
	char sOption[64];
	
	GetCmdArg(1, sOption, sizeof(sOption));
	
	if(StrContains(sOption, "#clear", false) != -1)
	{
		if(Cel_IsLandCreated(iClient))
		{
			Cel_ClearLand(iClient);
			
			Cel_ReplyToCommand(iClient, "%t", "LandCleared");
		}else{
			Cel_ReplyToCommand(iClient, "%t", "LandNotStarted");
		}
		
		return Plugin_Handled;
	}else if(StrEqual(sOption, "")){
		switch(g_liLand[iClient].iLandStage)
		{
			case 0:
			{
				if(Cel_IsClientCrosshairInLand(iClient))
				{
					Cel_ReplyToCommand(iClient, "%t", "CantStartLandInLand");
					return Plugin_Handled;
				}
				
				Cel_GetCrosshairHitOrigin(iClient, g_liLand[iClient].fLandPosBottom);
				Cel_GetCrosshairHitOrigin(iClient, g_liLand[iClient].fLandPosStarting);
				
				g_liLand[iClient].bLandDrawing = true;
				g_liLand[iClient].bLandGettingTopPos = true;
				
				Cel_ReplyToCommand(iClient, "%t", "LandStarted");
				
				g_liLand[iClient].iLandStage = 1;
			}
			
			case 1:
			{
				if(Cel_IsClientCrosshairInLand(iClient))
				{
					Cel_ReplyToCommand(iClient, "%t", "CantEndLandInLand");
					return Plugin_Handled;
				}
				
				g_liLand[iClient].bLandGettingTopPos = false;
				g_liLand[iClient].bLandCreated = true;
				
				Cel_GetMiddleOfABox(g_liLand[iClient].fLandPosBottom, g_liLand[iClient].fLandPosTop, g_liLand[iClient].fLandPosBottomMiddle);
				
				g_liLand[iClient].fLandPosBottomMiddle[2] = g_liLand[iClient].fLandPosBottom[2];
				
				Cel_CreateLand(iClient, g_liLand[iClient].fLandPosBottom, g_liLand[iClient].fLandPosTop);
				
				//A land skin the player chose before is laid on the new land.
				ApplyLandSkin(iClient);
				
				g_liLand[iClient].iLandStage = 2;
				
				Cel_ReplyToCommand(iClient, "%t", "LandFinished");
			}
			
			case 2:
			{
				Cel_ClearLand(iClient);
				
				Cel_ReplyToCommand(iClient, "%t", "LandCleared");
			}
		}
	}else{
		Cel_ReplyToCommand(iClient, "%t", "CMD_Land");
		return Plugin_Handled;
	}
	
	return Plugin_Handled;
}

public Action Command_LandCoop(int iClient, int iArgs)
{
	g_liLand[iClient].bModeCoop = !g_liLand[iClient].bModeCoop;
	g_liLand[iClient].bModeDeathmatch = false;
	g_liLand[iClient].bModeShop = false;
	
	Cel_ReplyToCommand(iClient, "%t", g_liLand[iClient].bModeCoop ? "CoopOn" : "CoopOff");
	
	return Plugin_Handled;
}

public Action Command_LandDeathmatch(int iClient, int iArgs)
{
	g_liLand[iClient].bModeCoop = false;
	g_liLand[iClient].bModeDeathmatch = !g_liLand[iClient].bModeDeathmatch;
	g_liLand[iClient].bModeShop = false;
	
	Cel_ReplyToCommand(iClient, "%t", g_liLand[iClient].bModeDeathmatch ? "DeathmatchOn" : "DeathmatchOff");
	
	return Plugin_Handled;
}

public Action Command_LandGravity(int iClient, int iArgs)
{
	char sGravity[64];
	
	if (iArgs < 1)
	{
		Cel_ReplyToCommand(iClient, "%t", "CMD_LandGravity");
		return Plugin_Handled;
	}
	
	GetCmdArg(1, sGravity, sizeof(sGravity));
	
	float fGravity = StringToFloat(sGravity);
	
	//Either a multiplier (0.5 = half) or the game's own gravity units (600 is normal, 300 is half).
	if (fGravity > 10.0)
	{
		fGravity /= 600.0;
	}
	
	if (fGravity < 0.05 || fGravity > 4.0)
	{
		Cel_ReplyToCommand(iClient, "Gravity goes from {green}0.05{default} (almost none) to {green}4{default} (four times normal); {green}1{default} is normal. Game units such as {green}300{default} work too.");
		return Plugin_Handled;
	}
	
	Cel_SetLandGravity(iClient, fGravity);
	
	//Everyone already standing in the land feels it straight away.
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && IsPlayerAlive(i) && g_liLand[i].bInsideLand && Cel_GetCurrentLandOwner(i) == iClient)
		{
			SetEntityGravity(i, fGravity);
		}
	}
	
	Cel_ReplyToCommand(iClient, "Your land's gravity is now {green}%.2f{default} times normal.", fGravity);
	
	return Plugin_Handled;
}

public Action Command_LandShop(int iClient, int iArgs)
{
	g_liLand[iClient].bModeCoop = false;
	g_liLand[iClient].bModeDeathmatch = false;
	g_liLand[iClient].bModeShop = !g_liLand[iClient].bModeShop;
	
	Cel_ReplyToCommand(iClient, "%t", g_liLand[iClient].bModeShop ? "ShopOn" : "ShopOff");
	
	return Plugin_Handled;
}

//Natives:
public int Native_CreateLand(Handle hPlugin, int iNumParams)
{
	float fMax[3], fLandPosMiddle[3], fMin[3];
	int iClient, iEnt;
	
	iClient = GetNativeCell(1);
	
	GetNativeArray(2, fMin, 3);
	GetNativeArray(3, fMax, 3);
	
	iEnt = CreateEntityByName("trigger_multiple");
	
	DispatchKeyValue(iEnt, "spawnflags", "1103");
	DispatchKeyValue(iEnt, "wait", "0");
	
	DispatchSpawn(iEnt);
	ActivateEntity(iEnt);
	
	Cel_GetMiddleOfABox(fMin, fMax, fLandPosMiddle);
	
	TeleportEntity(iEnt, fLandPosMiddle, NULL_VECTOR, NULL_VECTOR);
	
	PrecacheModel(LAND_MODEL);
	SetEntityModel(iEnt, LAND_MODEL);
	
	fMin[0] = fMin[0] - fLandPosMiddle[0];
	if (fMin[0] > 0.0)
	fMin[0] *= -1.0;
	
	fMin[1] = fMin[1] - fLandPosMiddle[1];
	if (fMin[1] > 0.0)
	fMin[1] *= -1.0;
	
	fMin[2] = fMin[2] - fLandPosMiddle[2];
	if (fMin[2] > 0.0)
	fMin[2] *= -1.0;
	
	fMax[0] = fMax[0] - fLandPosMiddle[0];
	if (fMax[0] < 0.0)
	fMax[0] *= -1.0;
	
	fMax[1] = fMax[1] - fLandPosMiddle[1];
	if (fMax[1] < 0.0)
	fMax[1] *= -1.0;
	
	fMax[2] = fMax[2] - fLandPosMiddle[2];
	if (fMax[2] < 0.0)
	fMax[2] *= -1.0;
	
	SetEntPropVector(iEnt, Prop_Send, "m_vecMins", fMin);
	SetEntPropVector(iEnt, Prop_Send, "m_vecMaxs", fMax);
	
	SetEntProp(iEnt, Prop_Send, "m_nSolidType", 2);
	
	int iEffects = GetEntProp(iEnt, Prop_Send, "m_fEffects");
	iEffects |= 32;
	SetEntProp(iEnt, Prop_Send, "m_fEffects", iEffects);
	
	HookSingleEntityOutput(iEnt, "OnStartTouch", EntOut_LandOnStartTouch);
	HookSingleEntityOutput(iEnt, "OnTrigger", EntOut_LandOnTrigger);
	HookSingleEntityOutput(iEnt, "OnEndTouch", EntOut_LandOnEndTouch);
	
	g_iLandEntOwner[iEnt] = iClient;
	g_liLand[iClient].iLandEntity = iEnt;
	g_liLand[iClient].iLandOwner = iClient;
	
	g_liLand[iClient].bModeCoop = false;
	g_liLand[iClient].bModeDeathmatch = false;
	g_liLand[iClient].bModeShop = false;
	
	return g_liLand[iClient].iLandEntity;
}

public int Native_ClearLand(Handle hPlugin, int iNumParams)
{
	int iClient = GetNativeCell(1);
	
	RemoveLandSkin(iClient);
	
	g_liLand[iClient].bInCoopMode = false;
	g_liLand[iClient].bInDeathmatchMode = false;
	g_liLand[iClient].bInShopMode = false;
	g_liLand[iClient].bInsideLand = false;
	g_liLand[iClient].bLandDrawing = false;
	g_liLand[iClient].bLandGettingTopPos = false;
	g_liLand[iClient].bModeCoop = false;
	g_liLand[iClient].bModeDeathmatch = false;
	g_liLand[iClient].bModeShop = false;
	
	if(Cel_IsLandCreated(iClient))
	{
		AcceptEntityInput(g_liLand[iClient].iLandEntity, "kill");
	}
	
	g_liLand[iClient].bLandCreated = false;
	
	g_liLand[iClient].fLandPosBottom = g_fZero;
	g_liLand[iClient].fLandPosBottomTop = g_fZero;
	g_liLand[iClient].fLandGravity = 1.0;
	g_liLand[iClient].fLandPosBottomMiddle = g_fZero;
	g_liLand[iClient].fLandPosStarting = g_fZero;
	g_liLand[iClient].fLandPosTop = g_fZero;
	
	g_liLand[iClient].iLandEntity = -1;
	g_liLand[iClient].iLandOwner = -1;
	g_liLand[iClient].iLandStage = 0;
	
	return true;
}

public int Native_DrawLandBorders(Handle hPlugin, int iNumParams)
{
	bool bFlat = view_as<bool>(GetNativeCell(5));
	float fFrom[3], fLife, fTo[3];
	int iColor[4];
	
	GetNativeArray(1, fFrom, 3);
	GetNativeArray(2, fTo, 3);
	fLife = view_as<float>(GetNativeCell(3));
	
	GetNativeArray(4, iColor, 4);
	
	float fLeftBottomFront[3];
	
	fLeftBottomFront[0] = fFrom[0];
	fLeftBottomFront[1] = fFrom[1];
	
	if (bFlat)
	{
		fLeftBottomFront[2] = fTo[2] - 2;
	} else {
		fLeftBottomFront[2] = fTo[2];
	}
	
	float fRightBottomFront[3];
	
	fRightBottomFront[0] = fTo[0];
	fRightBottomFront[1] = fFrom[1];
	
	if (bFlat)
	{
		fRightBottomFront[2] = fTo[2] - 2;
	} else {
		fRightBottomFront[2] = fTo[2];
	}
	
	float fLeftBottomBack[3];
	
	fLeftBottomBack[0] = fFrom[0];
	fLeftBottomBack[1] = fTo[1];
	
	if (bFlat)
	{
		fLeftBottomBack[2] = fTo[2] - 2;
	} else {
		fLeftBottomBack[2] = fTo[2];
	}
	
	float fRightBottomBack[3];
	
	fRightBottomBack[0] = fTo[0];
	fRightBottomBack[1] = fTo[1];
	
	if (bFlat)
	{
		fRightBottomBack[2] = fTo[2] - 2;
	} else {
		fRightBottomBack[2] = fTo[2];
	}
	
	float fLeftTopFront[3];
	
	fLeftTopFront[0] = fFrom[0];
	fLeftTopFront[1] = fFrom[1];
	
	if (bFlat)
	{
		fLeftTopFront[2] = fFrom[2] + 3;
	} else {
		fLeftTopFront[2] = fFrom[2] + 100;
	}
	
	float fRightTopFront[3];
	
	fRightTopFront[0] = fTo[0];
	fRightTopFront[1] = fFrom[1];
	
	if (bFlat)
	{
		fRightTopFront[2] = fFrom[2] + 3;
	} else {
		fRightTopFront[2] = fFrom[2] + 100;
	}
	
	float fLeftTopBack[3];
	
	fLeftTopBack[0] = fFrom[0];
	fLeftTopBack[1] = fTo[1];
	
	if (bFlat)
	{
		fLeftTopBack[2] = fFrom[2] + 3;
	} else {
		fLeftTopBack[2] = fFrom[2] + 100;
	}
	
	float fRightTopBack[3];
	
	fRightTopBack[0] = fTo[0];
	fRightTopBack[1] = fTo[1];
	
	if (bFlat)
	{
		fRightTopBack[2] = fFrom[2] + 3;
	} else {
		fRightTopBack[2] = fFrom[2] + 100;
	}
	
	TE_SetupBeamPoints(fLeftTopFront, fRightTopFront, g_iLand, 0, 0, 0, fLife, 3.0, 3.0, 10, 0.0, iColor, 0); TE_SendToAll(0.0);
	TE_SetupBeamPoints(fLeftTopFront, fLeftTopBack, g_iLand, 0, 0, 0, fLife, 3.0, 3.0, 10, 0.0, iColor, 0); TE_SendToAll(0.0);
	TE_SetupBeamPoints(fRightTopBack, fLeftTopBack, g_iLand, 0, 0, 0, fLife, 3.0, 3.0, 10, 0.0, iColor, 0); TE_SendToAll(0.0);
	TE_SetupBeamPoints(fRightTopBack, fRightTopFront, g_iLand, 0, 0, 0, fLife, 3.0, 3.0, 10, 0.0, iColor, 0); TE_SendToAll(0.0);
	
	return true;
}

public int Native_GetLandEntity(Handle hPlugin, int iNumParams)
{
	float fLandPosBottom[3], fLandPosTop[3];
	
	GetNativeArray(1, fLandPosBottom, 3);
	GetNativeArray(2, fLandPosTop, 3);
	
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsClientAuthorized(i))
		{
			if(g_liLand[i].fLandPosBottom[0] == fLandPosBottom[0] && g_liLand[i].fLandPosBottom[1] == fLandPosBottom[1] && g_liLand[i].fLandPosBottom[2] == fLandPosBottom[2] && g_liLand[i].fLandPosTop[0] == fLandPosTop[0] && g_liLand[i].fLandPosTop[1] == fLandPosTop[1] && g_liLand[i].fLandPosTop[2] == fLandPosTop[2])
			{
				return g_liLand[i].iLandEntity;
			}
		}
	}
	
	return -1;
}

public int Native_GetLandOwner(Handle hPlugin, int iNumParams)
{
	float fLandPosBottom[3], fLandPosTop[3];
	
	GetNativeArray(1, fLandPosBottom, 3);
	GetNativeArray(2, fLandPosTop, 3);
	
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsClientAuthorized(i))
		{
			if(g_liLand[i].fLandPosBottom[0] == fLandPosBottom[0] && g_liLand[i].fLandPosBottom[1] == fLandPosBottom[1] && g_liLand[i].fLandPosBottom[2] == fLandPosBottom[2] && g_liLand[i].fLandPosTop[0] == fLandPosTop[0] && g_liLand[i].fLandPosTop[1] == fLandPosTop[1] && g_liLand[i].fLandPosTop[2] == fLandPosTop[2])
			{
				return g_liLand[i].iLandOwner;
			}
		}
	}
	
	return -1;
}

public int Native_GetLandOwnerFromEntity(Handle hPlugin, int iNumParams)
{
	float fOrigin[3], fMax[3], fMin[3];
	int iEntity = GetNativeCell(1);
	
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsClientAuthorized(i))
		{
			Entity_GetAbsOrigin(iEntity, fOrigin);
			GetEntPropVector(iEntity, Prop_Send, "m_vecMins", fMin);
			GetEntPropVector(iEntity, Prop_Send, "m_vecMaxs", fMax);
			
			fMin[0] = fOrigin[0] + fMin[0];
			fMin[1] = fOrigin[1] + fMin[1];
			fMin[2] = fOrigin[2] + fMin[2];
			
			fMax[0] = fOrigin[0] + fMax[0];
			fMax[1] = fOrigin[1] + fMax[1];
			fMax[2] = fOrigin[2] + fMax[2];
			
			if(Cel_IsPositionInBox(fMax, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop) || Cel_IsPositionInBox(fOrigin, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop) || Cel_IsPositionInBox(fMin, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop))
			{
				return g_liLand[i].iLandOwner;
			}
		}
	}
	
	return -1;
}

public int Native_GetLandOwnerFromPosition(Handle hPlugin, int iNumParams)
{
	float fOrigin[3];
	
	GetNativeArray(1, fOrigin, 3);
	
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsClientAuthorized(i))
		{
			if(Cel_IsPositionInBox(fOrigin, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop))
			{
				return g_liLand[i].iLandOwner;
			}
		}
	}
	
	return -1;
}

public void Native_GetLandPositions(Handle hPlugin, int iNumParams)
{
	float fPosition[3];
	int iClient = GetNativeCell(1), iPosition = GetNativeCell(2);
	
	switch(iPosition)
	{
		case 1:
		{
			fPosition = g_liLand[iClient].fLandPosStarting;
		}
		case 2:
		{
			fPosition = g_liLand[iClient].fLandPosBottom;
		}
		case 3:
		{
			fPosition = g_liLand[iClient].fLandPosTop;
		}
		case 4:
		{
			fPosition = g_liLand[iClient].fLandPosBottomTop;
		}
		case 5:
		{
			fPosition = g_liLand[iClient].fLandPosBottomMiddle;
		}
	}
	
	SetNativeArray(3, fPosition, 3);
}

public int Native_GetMiddleOfBox(Handle hPlugin, int iNumParams)
{
	float fBuffer[3], fMax[3], fMin[3];
	
	GetNativeArray(1, fMin, 3);
	GetNativeArray(2, fMax, 3);
	
	float fMid[3];
	
	MakeVectorFromPoints(fMin, fMax, fMid);
	
	fMid[0] = fMid[0] / 2.0;
	fMid[1] = fMid[1] / 2.0;
	fMid[2] = fMid[2] / 2.0;
	
	AddVectors(fMin, fMid, fBuffer);
	
	SetNativeArray(3, fBuffer, 3);
	
	return true;
}

public int Native_IsClientInLand(Handle hPlugin, int iNumParams)
{
	float fOrigin[3];
	int iClient = GetNativeCell(1);
	
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsClientAuthorized(i))
		{
			GetClientAbsOrigin(iClient, fOrigin);
			
			if(Cel_IsPositionInBox(fOrigin, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop))
			{
				return true;
			}
		}
	}
	
	return false;
}

public int Native_IsClientCrosshairInLand(Handle hPlugin, int iNumParams)
{
	float fOrigin[3];
	int iClient = GetNativeCell(1);
	
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsClientAuthorized(i))
		{
			Cel_GetCrosshairHitOrigin(iClient, fOrigin);
			
			fOrigin[2] += 1.0;
			
			if(Cel_IsPositionInBox(fOrigin, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop) && g_liLand[i].bLandCreated)
			{
				return true;
			}
		}else{
			return false;
		}
	}
	
	return false;
}

public int Native_IsEntityInLand(Handle hPlugin, int iNumParams)
{
	float fMax[3], fMin[3], fOrigin[3];
	int iEntity = GetNativeCell(1);
	
	for (int i = 1; i < MaxClients; i++)
	{
		if (IsClientAuthorized(i))
		{
			Entity_GetAbsOrigin(iEntity, fOrigin);
			GetEntPropVector(iEntity, Prop_Send, "m_vecMins", fMin);
			GetEntPropVector(iEntity, Prop_Send, "m_vecMaxs", fMax);
			
			fMin[0] = fOrigin[0] + fMin[0];
			fMin[1] = fOrigin[1] + fMin[1];
			fMin[2] = fOrigin[2] + fMin[2];
			
			fMax[0] = fOrigin[0] + fMax[0];
			fMax[1] = fOrigin[1] + fMax[1];
			fMax[2] = fOrigin[2] + fMax[2];
			
			if(Cel_IsPositionInBox(fMax, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop) || Cel_IsPositionInBox(fOrigin, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop) || Cel_IsPositionInBox(fMin, g_liLand[i].fLandPosBottom, g_liLand[i].fLandPosTop))
			{
				return true;
			}
		}else{
			return false;
		}
	}
	
	return false;
}

public int Native_IsLandCreated(Handle hPlugin, int iNumParams)
{
	int iClient = GetNativeCell(1);
	
	return g_liLand[iClient].bLandCreated;
}

public int Native_IsPositionInBox(Handle hPlugin, int iNumParams)
{
	float fCorner1[3], fCorner2[3], fPos[3];
	
	GetNativeArray(1, fPos, 3);
	GetNativeArray(2, fCorner1, 3);
	GetNativeArray(3, fCorner2, 3);
	
	float fEntity[3];
	float fField1[2];
	float fField2[2];
	float fField3[2];
	
	fEntity = fPos;
	
	//fEntity[2] += 25.0;
	
	if (FloatCompare(fCorner1[0], fCorner2[0]) == -1)
	{
		fField1[0] = fCorner1[0];
		fField1[1] = fCorner2[0];
	}
	else
	{
		fField1[0] = fCorner2[0];
		fField1[1] = fCorner1[0];
	}
	if (FloatCompare(fCorner1[1], fCorner2[1]) == -1)
	{
		fField2[0] = fCorner1[1];
		fField2[1] = fCorner2[1];
	}
	else
	{
		fField2[0] = fCorner2[1];
		fField2[1] = fCorner1[1];
	}
	if (FloatCompare(fCorner1[2], fCorner2[2]) == -1)
	{
		fField3[0] = fCorner1[2];
		fField3[1] = fCorner2[2];
	}
	else
	{
		fField3[0] = fCorner2[2];
		fField3[1] = fCorner1[2];
	}
	
	// Check the Vectors ...
	
	if (fEntity[0] < fField1[0] || fEntity[0] > fField1[1])
	{
		return false;
	}
	if (fEntity[1] < fField2[0] || fEntity[1] > fField2[1])
	{
		return false;
	}
	if (fEntity[2] < fField3[0] || fEntity[2] > fField3[1])
	{
		return false;
	}
	
	return true;
}

public void Native_SetLandGravity(Handle hPlugin, int iNumParams)
{
	int iClient = GetNativeCell(1);
	
	g_liLand[iClient].fLandGravity = GetNativeCell(2);
}

public any Native_GetLandGravity(Handle hPlugin, int iNumParams)
{
	int iClient = GetNativeCell(1);
	
	return g_liLand[iClient].fLandGravity;
}

public int Native_GetCurrentLandEntity(Handle hPlugin, int iNumParams)
{
	int iClient = GetNativeCell(1);
	
	return g_iCurrentLandEntity[iClient];
}

public int Native_GetCurrentLandOwner(Handle hPlugin, int iNumParams)
{
	int iClient = GetNativeCell(1);
	
	return g_iCurrentLandOwner[iClient];
}

public void Native_SetCurrentLandEntity(Handle hPlugin, int iNumParams)
{
	int iClient = GetNativeCell(1);
	
	g_iCurrentLandEntity[iClient] = GetNativeCell(2);
}

public void Native_SetCurrentLandOwner(Handle hPlugin, int iNumParams)
{
	int iClient = GetNativeCell(1);
	
	g_iCurrentLandOwner[iClient] = GetNativeCell(2);
}

//Outputs:
public void EntOut_LandOnStartTouch(const char[] sOutput, int iCaller, int iActivator, float fDelay)
{
	if (iActivator < 1 || iActivator > MaxClients || !IsClientInGame(iActivator) || !IsPlayerAlive(iActivator))
	return;
	
	char sName[64];
	
	int iOwner = g_iLandEntOwner[iCaller];
	
	if(Cel_IsPlayer(iActivator))
	{
		GetClientName(iOwner, sName, sizeof(sName));
		
		if(!g_liLand[iActivator].bInsideLand)
		{
			Cel_PrintToChat(iActivator, "%t", "EnteredLand", sName);
		}
		
		g_liLand[iActivator].bInsideLand = true;
		
		Cel_SetCurrentLandEntity(iActivator, g_liLand[iOwner].iLandEntity);
		Cel_SetCurrentLandOwner(iActivator, g_liLand[iOwner].iLandOwner);
	}
}

public void EntOut_LandOnTrigger(const char[] sOutput, int iCaller, int iActivator, float fDelay)
{
	if (iActivator < 1 || iActivator > MaxClients || !IsClientInGame(iActivator) || !IsPlayerAlive(iActivator))
	return;
	
	int iOwner = g_iLandEntOwner[iCaller];
	
	if(Cel_IsPlayer(iActivator))
	{
		if(g_liLand[iActivator].bInsideLand)
		{
			SetEntityGravity(iActivator, Cel_GetLandGravity(iOwner));
			
			if(g_liLand[iOwner].bModeDeathmatch && !g_liLand[iActivator].bInDeathmatchMode)
			{
				SetEntProp(iActivator, Prop_Data, "m_takedamage", 2, 1);
				
				g_liLand[iActivator].bInDeathmatchMode = true;
				
				Cel_PrintToChat(iActivator, "%t", "LandMode_Deathmatch");
			}
			
			//Co-op: players can be hurt (by the world, NPCs and falls) but not by other players.
			if(g_liLand[iOwner].bModeCoop && !g_liLand[iActivator].bInCoopMode)
			{
				SetEntProp(iActivator, Prop_Data, "m_takedamage", 2, 1);
				
				g_liLand[iActivator].bInCoopMode = true;
				
				Cel_PrintToChat(iActivator, "%t", "LandMode_Coop");
			}
			
			//Update land modes; a mode that was switched off gives the player their own god mode back.
			if(!g_liLand[iOwner].bModeCoop && g_liLand[iActivator].bInCoopMode)
			{
				g_liLand[iActivator].bInCoopMode = false;
				
				Cel_SetNoKill(iActivator, Cel_GetNoKill(iActivator));
			}
			
			if(!g_liLand[iOwner].bModeDeathmatch && g_liLand[iActivator].bInDeathmatchMode)
			{
				g_liLand[iActivator].bInDeathmatchMode = false;
				
				Cel_SetNoKill(iActivator, Cel_GetNoKill(iActivator));
			}
			
			if(!g_liLand[iOwner].bModeShop && g_liLand[iActivator].bInShopMode)
			{
				g_liLand[iActivator].bInShopMode = false;
			}
		}
	}
}

public void EntOut_LandOnEndTouch(const char[] sOutput, int iCaller, int iActivator, float fDelay)
{
	if (iActivator < 1 || iActivator > MaxClients || !IsClientInGame(iActivator) || !IsPlayerAlive(iActivator))
	return;
	
	if(Cel_IsPlayer(iActivator))
	{
		g_liLand[iActivator].bInsideLand = false;
		
		Cel_SetCurrentLandEntity(iActivator, -1);
		Cel_SetCurrentLandOwner(iActivator, -1);
		
		SetEntityGravity(iActivator, 1.0);
		
		if(g_liLand[iActivator].bInDeathmatchMode || g_liLand[iActivator].bInCoopMode)
		{
			Cel_SetNoKill(iActivator, Cel_GetNoKill(iActivator));
			
			g_liLand[iActivator].bInDeathmatchMode = false;
			g_liLand[iActivator].bInCoopMode = false;
		}
	}
}

//Timers:
public Action Timer_GettingTop(Handle hTimer, any iPlayer)
{
	int iClient = GetClientOfUserId(iPlayer);
	
	if(g_liLand[iClient].bLandGettingTopPos)
	{
		Cel_GetCrosshairHitOrigin(iClient, g_liLand[iClient].fLandPosBottomTop);
		
		Handle hTraceRay = TR_TraceRayEx(g_liLand[iClient].fLandPosBottomTop, g_fUp, MASK_ALL, RayType_Infinite);
		
		if (TR_DidHit(hTraceRay))
		{
			TR_GetEndPosition(g_liLand[iClient].fLandPosTop, hTraceRay);
			
			CloseHandle(hTraceRay);
		}
		
		//Thank you Instakill.
		for(int x = 0; x < 2; x++)
		{
			if(g_liLand[iClient].fLandPosBottomTop[x] > g_liLand[iClient].fLandPosBottom[x] + g_fMaxLandSize) {
				g_liLand[iClient].fLandPosBottomTop[x] = g_liLand[iClient].fLandPosBottom[x] + g_fMaxLandSize;
			}
			if(g_liLand[iClient].fLandPosTop[x] > g_liLand[iClient].fLandPosBottom[x] + g_fMaxLandSize) {
				g_liLand[iClient].fLandPosTop[x] = g_liLand[iClient].fLandPosBottom[x] + g_fMaxLandSize;
			}
			
			if(g_liLand[iClient].fLandPosBottomTop[x] < g_liLand[iClient].fLandPosBottom[x] - g_fMaxLandSize) {
				g_liLand[iClient].fLandPosBottomTop[x] = g_liLand[iClient].fLandPosBottom[x] - g_fMaxLandSize;
			}
			if(g_liLand[iClient].fLandPosTop[x] < g_liLand[iClient].fLandPosBottom[x] - g_fMaxLandSize) {
				g_liLand[iClient].fLandPosTop[x] = g_liLand[iClient].fLandPosBottom[x] - g_fMaxLandSize;
			}
		}
	}
	
	return Plugin_Continue;
}

//In a co-op land, damage from another player does nothing.
public Action Hook_CoopDamage(int iVictim, int &iAttacker, int &iInflictor, float &fDamage, int &iDamageType)
{
	if (iVictim < 1 || iVictim > MaxClients || !g_liLand[iVictim].bInCoopMode)
	{
		return Plugin_Continue;
	}
	
	int iFrom = iAttacker;
	
	//Thrown props and grenades count as the player who threw them.
	if (iFrom > MaxClients && iInflictor > 0 && iInflictor <= MaxClients)
	{
		iFrom = iInflictor;
	}
	
	if (iFrom > 0 && iFrom <= MaxClients && iFrom != iVictim)
	{
		fDamage = 0.0;
		
		return Plugin_Handled;
	}
	
	return Plugin_Continue;
}

//Land skins: materials/celmod/landskins/s1 to s26, drawn as flat tiles lying just above the land's floor.
void RemoveLandSkin(int iClient)
{
	for (int i = 0; i < g_alSkinTiles[iClient].Length; i++)
	{
		int iTile = EntRefToEntIndex(g_alSkinTiles[iClient].Get(i));

		if (iTile != INVALID_ENT_REFERENCE && iTile > MaxClients)
		{
			AcceptEntityInput(iTile, "kill");
		}
	}

	g_alSkinTiles[iClient].Clear();
}

void ApplyLandSkin(int iClient)
{
	char sMaterial[PLATFORM_MAX_PATH];
	float fAngles[3] = { -90.0, 0.0, 0.0 }, fMax[3], fMin[3], fPos[3];

	RemoveLandSkin(iClient);

	if (g_iLandSkin[iClient] < 1 || !g_liLand[iClient].bLandCreated)
	{
		return;
	}

	for (int k = 0; k < 3; k++)
	{
		fMin[k] = (g_liLand[iClient].fLandPosBottom[k] < g_liLand[iClient].fLandPosTop[k]) ? g_liLand[iClient].fLandPosBottom[k] : g_liLand[iClient].fLandPosTop[k];
		fMax[k] = (g_liLand[iClient].fLandPosBottom[k] < g_liLand[iClient].fLandPosTop[k]) ? g_liLand[iClient].fLandPosTop[k] : g_liLand[iClient].fLandPosBottom[k];
	}

	Format(sMaterial, sizeof(sMaterial), "celmod/landskins/s%d.vmt", g_iLandSkin[iClient]);

	float fTile = g_cvSkinTile.FloatValue;
	float fWidth = fMax[0] - fMin[0], fLength = fMax[1] - fMin[1];

	//Square tiles, overlapping a little where the land is not a whole number of tiles, so they cover it exactly.
	int iAcross = RoundToCeil(fWidth / fTile), iAlong = RoundToCeil(fLength / fTile);

	if (iAcross < 1) iAcross = 1;
	if (iAlong < 1) iAlong = 1;

	float fTileX = (fWidth < fTile) ? fWidth : fTile;
	float fTileY = (fLength < fTile) ? fLength : fTile;
	float fSize = (fTileX > fTileY) ? fTileX : fTileY;

	for (int x = 0; x < iAcross; x++)
	{
		for (int y = 0; y < iAlong; y++)
		{
			int iTile = CreateEntityByName("env_sprite_oriented");

			if (iTile == -1)
			{
				return;
			}

			fPos[0] = fMin[0] + fTileX * 0.5 + ((iAcross > 1) ? x * (fWidth - fTileX) / (iAcross - 1) : (fWidth - fTileX) * 0.5);
			fPos[1] = fMin[1] + fTileY * 0.5 + ((iAlong > 1) ? y * (fLength - fTileY) / (iAlong - 1) : (fLength - fTileY) * 0.5);

			//Just above the floor, each tile a hair apart in height so overlapping edges do not flicker.
			fPos[2] = fMin[2] + 1.0 + ((x + y) % 4) * 0.1;

			DispatchKeyValue(iTile, "model", sMaterial);
			DispatchKeyValue(iTile, "rendermode", "0");
			DispatchKeyValue(iTile, "renderamt", "255");
			DispatchKeyValue(iTile, "spawnflags", "1");
			DispatchKeyValue(iTile, "classname", "cel_landskin");
			DispatchKeyValueFloat(iTile, "scale", fSize / g_cvSkinTexture.FloatValue);

			DispatchSpawn(iTile);

			TeleportEntity(iTile, fPos, fAngles, NULL_VECTOR);

			AcceptEntityInput(iTile, "ShowSprite");

			g_alSkinTiles[iClient].Push(EntIndexToEntRef(iTile));
		}
	}
}

public Action Command_LandSkin(int iClient, int iArgs)
{
	char sArg[16], sDisplay[64];
	int iPrice;

	if (iClient < 1)
	{
		return Plugin_Handled;
	}

	if (iArgs < 1)
	{
		Cel_ReplyToCommand(iClient, "Usage: {green}[tag]landskin{default} <1-%d/off>", LANDSKIN_COUNT);
		return Plugin_Handled;
	}

	GetCmdArg(1, sArg, sizeof(sArg));

	if (StrEqual(sArg, "off", false) || StrEqual(sArg, "0"))
	{
		g_iLandSkin[iClient] = 0;

		Cel_SetClientSettingInt(iClient, "landskin", 0);

		RemoveLandSkin(iClient);

		Cel_ReplyToCommand(iClient, "Your land skin has been removed.");

		return Plugin_Handled;
	}

	int iSkin = StringToInt(sArg);

	if (iSkin < 1 || iSkin > LANDSKIN_COUNT)
	{
		Cel_ReplyToCommand(iClient, "Land skins go from {green}1{default} to {green}%d{default}.", LANDSKIN_COUNT);
		return Plugin_Handled;
	}

	//Land skins are bought once in the shop, when the shop sells them.
	if (Cel_CheckShopDB("landskin", iPrice, sDisplay, sizeof(sDisplay)) && !Cel_CheckClientPurchase(iClient, "landskin"))
	{
		Cel_ReplyToCommand(iClient, "Land skins cost {green}%d CL{default}. Buy them with {green}[tag]buy landskin{default}.", iPrice);
		return Plugin_Handled;
	}

	g_iLandSkin[iClient] = iSkin;

	Cel_SetClientSettingInt(iClient, "landskin", iSkin);

	if (!g_liLand[iClient].bLandCreated)
	{
		Cel_ReplyToCommand(iClient, "Land skin {green}%d{default} chosen. It will cover your land once you make one with {green}[tag]land{default}.", iSkin);
		return Plugin_Handled;
	}

	ApplyLandSkin(iClient);

	Cel_ReplyToCommand(iClient, "Your land now has land skin {green}%d{default}.", iSkin);

	return Plugin_Handled;
}

public Action Command_LandColor(int iClient, int iArgs)
{
	char sColor[64], sColorBuffer[3][8], sColorString[32];
	
	if (iClient < 1)
	{
		return Plugin_Handled;
	}
	
	if (iArgs < 1)
	{
		Cel_ReplyToCommand(iClient, "Usage: {green}[tag]landcolor{default} <color/off>");
		return Plugin_Handled;
	}
	
	GetCmdArg(1, sColor, sizeof(sColor));
	
	if (StrEqual(sColor, "off", false) || StrEqual(sColor, "none", false))
	{
		g_bLandColor[iClient] = false;
		
		Cel_ReplyToCommand(iClient, "Your land's border uses your HUD color again.");
		
		return Plugin_Handled;
	}
	
	if (!Cel_CheckColorDB(sColor, sColorString, sizeof(sColorString)))
	{
		Cel_ReplyToCommand(iClient, "There is no color called {green}%s{default}. Type {green}[tag]colorlist{default} to see them.", sColor);
		return Plugin_Handled;
	}
	
	ExplodeString(sColorString, "|", sColorBuffer, 3, sizeof(sColorBuffer[]));
	
	g_bLandColor[iClient] = true;
	g_iLandColor[iClient][0] = StringToInt(sColorBuffer[0]);
	g_iLandColor[iClient][1] = StringToInt(sColorBuffer[1]);
	g_iLandColor[iClient][2] = StringToInt(sColorBuffer[2]);
	
	Cel_ReplyToCommand(iClient, "Your land's border is now {green}%s{default}.", sColor);
	
	return Plugin_Handled;
}

public Action Timer_Land(Handle hTimer, any iPlayer)
{
	int iClient = GetClientOfUserId(iPlayer), iColor[4];
	
	Cel_GetHudColor(iClient, iColor);
	
	//A color chosen with !landcolor replaces the HUD color for the land's border.
	if (iClient > 0 && g_bLandColor[iClient])
	{
		iColor[0] = g_iLandColor[iClient][0];
		iColor[1] = g_iLandColor[iClient][1];
		iColor[2] = g_iLandColor[iClient][2];
	}
	
	if(g_liLand[iClient].bLandDrawing)
	{
		Cel_DrawLandBorders(g_liLand[iClient].fLandPosStarting, g_liLand[iClient].fLandPosTop, 0.1, iColor, true);
	}
	
	return Plugin_Continue;
}
