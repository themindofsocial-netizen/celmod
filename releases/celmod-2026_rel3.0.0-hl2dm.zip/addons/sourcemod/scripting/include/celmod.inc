#if defined _celmod_included
#endinput
#endif
#define _celmod_included

#include <sdkhooks>
#include <sdktools>
#include <morecolors>
#include <sourcemod>
#include <smlib>
#include <studio_hdr>

enum EntityCatagory
{
	ENTCATAGORY_BIT = 0,
	ENTCATAGORY_CEL = 1,
	ENTCATAGORY_PROP = 2,
	ENTCATAGORY_UNKNOWN = 3,
};

enum EntityType
{
	ENTTYPE_CYCLER = 0,
	ENTTYPE_DOOR = 1,
	ENTTYPE_DYNAMIC = 2,
	ENTTYPE_EFFECT = 3,
	ENTTYPE_INTERNET = 4,
	ENTTYPE_LADDER = 5,
	ENTTYPE_LIGHT = 6,
	ENTTYPE_PHYSICS = 7,
	ENTTYPE_CLEER = 8,
	ENTTYPE_BIT = 9,
	ENTTYPE_AMMO = 10,
	ENTTYPE_AMMOCRATE = 11,
	ENTTYPE_CHARGER = 12,
	ENTTYPE_WEAPONSPWNER = 13,
	ENTTYPE_TRIGGER = 14,
	ENTTYPE_LINK = 15,
	ENTTYPE_UNKNOWN = 16,
	ENTTYPE_EMBLEM = 17,
	ENTTYPE_HAT = 18,
	ENTTYPE_CELWEP = 19,
};

enum EffectType
{
	EFFECT_CORE = 0,
	EFFECT_EXPLOSION = 1,
	EFFECT_FIRE = 2,
	EFFECT_SHAKE = 3,
	EFFECT_SMOKESTACK = 4,
	EFFECT_SPOTLIGHT = 5,
	EFFECT_STEAM = 6,
	EFFECT_UNKNOWN = 7,
};

enum WeaponBitType
{
	WEPBIT_GRAVGUN = 0,
	WEPBIT_STUNSTICK = 1,
	WEPBIT_CROWBAR = 2,
	WEPBIT_PISTOL = 3,
	WEPBIT_MAGNUM = 4,
	WEPBIT_SMG = 5,
	WEPBIT_AR2 = 6,
	WEPBIT_SHOTGUN = 7,
	WEPBIT_CROSSBOW = 8,
	WEPBIT_GRENADE = 9,
	WEPBIT_RPG = 10,
	WEPBIT_SLAM = 11,
	WEPBIT_UNKNOWN = 12,
};

enum AmmoBitType
{
	AMMOBIT_PISTOL = 0,
	AMMOBIT_MAGNUM = 1,
	AMMOBIT_SMG = 2,
	AMMOBIT_AR2 = 3,
	AMMOBIT_SHOTGUN = 4,
	AMMOBIT_CROSSBOW = 5,
	AMMOBIT_RPG = 6,
	AMMOBIT_UNKNOWN = 7,
};

enum AmmoCrateType
{
	AMMOCRATEBIT_SMG = 1,
	AMMOCRATEBIT_AR2 = 2,
	AMMOCRATEBIT_RPG = 3,
	AMMOCRATEBIT_GRENADE = 5,
	AMMOCRATEBIT_CBALL = 8,
	AMMOCRATEBIT_UNKNOWN = 9,
};

enum ChargerType
{
	CHARGERBIT_HEALTH = 0,
	CHARGERBIT_SUIT = 1,
	CHARGERBIT_UNKNOWN = 2,
};

enum ControlTriggerType
{
	TRIGGERTYPE_BUTTON = 0,
	TRIGGERTYPE_STEP = 1,
};

#define CEL_AUTHOR "rockzehh"
#define CEL_URL "https://github.com/themindofsocial-netizen/celmod"
#define CEL_VERSION "3.0.0"

#define MAXENTITIES 2048

/**
 * The website moved from delaware.rockzehh.net to celmod.net, and its pages from .html to .php. A URL cvar
 * still holding an old address (from a saved cfg) is switched to the new one. Returns true if it changed.
 */
stock bool Cel_UpdateOldSiteURL(ConVar cvURL)
{
	char sURL[PLATFORM_MAX_PATH];

	cvURL.GetString(sURL, sizeof(sURL));

	if (StrContains(sURL, "delaware.rockzehh.net", false) == -1)
	{
		return false;
	}

	ReplaceString(sURL, sizeof(sURL), "http://", "https://", false);
	ReplaceString(sURL, sizeof(sURL), "delaware.rockzehh.net", "celmod.net", false);

	int iLength = strlen(sURL);

	if (iLength > 5 && StrEqual(sURL[iLength - 5], ".html", false))
	{
		strcopy(sURL[iLength - 5], sizeof(sURL) - (iLength - 5), ".php");
	}

	cvURL.SetString(sURL);

	return true;
}
#define PLAYER_CROWBAR_ATTACK_RADIUS 2.0
#define PLAYER_USE_RADIUS 80.0

float g_fDown[3] = { 90.0, 0.0, 0.0 };
float g_fUp[3] = { -90.0, 0.0, 0.0 };
float g_fZero[3] = { 0.0, 0.0, 0.0 };

//Colors:
int g_iBlue[4] =  { 0, 0, 255, 175 };
int g_iGray[4] =  { 255, 255, 255, 300 };
int g_iGreen[4] =  { 0, 255, 0, 175 };
int g_iOrange[4] =  { 255, 128, 0, 175 };
int g_iRed[4] =  { 255, 0, 0, 175 };
int g_iWhite[4] =  { 255, 255, 255, 175 };

//Forwards:
/**
 * Called when a Cel entity is spawned.
 *
 * @param iCel		  The entity index of the spawned Cel.
 * @param iOwner		The client index of the player who owns the Cel.
 * @param etEntityType  The type of entity being spawned, as defined in the EntityType enum.
 */
forward void Cel_OnCelSpawn(int iCel, int iOwner, EntityType etEntityType);

/**
 * Called when an effect entity is spawned.
 *
 * @param iEffect	   The entity index of the spawned effect.
 * @param iOwner		The client index of the effect owner.
 * @param etEffectType  The type of effect being spawned.
 */
forward void Cel_OnEffectSpawn(int iEffect, int iOwner, EffectType etEffectType);

/**
 * Called when an entity is removed from the game.
 *
 * @param iEntity  The entity index of the removed entity.
 * @param iOwner   The client index of the player who owned the entity, if applicable.
 * @param bCel	 True if the entity was a Cel entity, false otherwise.
 */
forward void Cel_OnEntityRemove(int iEntity, int iOwner, bool bCel);

/**
 * Called when a prop entity is spawned.
 *
 * @param iProp		 The entity index of the spawned prop.
 * @param iOwner		The client index of the player who owns the prop.
 * @param etEntityType  The type of entity being spawned, as defined in the EntityType enum.
 */
forward void Cel_OnPropSpawn(int iProp, int iOwner, EntityType etEntityType);

//Natives:
/**
 * Called when an entity passes from one player to another (sale, trade, gift or admin command).
 *
 * @param iEntity	The entity index.
 * @param iOldOwner  The client index of the previous owner.
 * @param iNewOwner  The client index of the new owner.
 */
forward void Cel_OnEntityOwnerChanged(int iEntity, int iOldOwner, int iNewOwner);

/**
 * Called after a client has loaded a build.
 *
 * @param iClient	The client index.
 * @param sSaveName  The name of the build that was loaded.
 */
forward void Cel_OnBuildLoaded(int iClient, const char[] sSaveName);

/**
 * Called for each entity while a build is being saved, so a plugin can store its own data with it.
 *
 * @param iEntity  The entity being saved.
 * @param kvSave   The save file, positioned on this entity's section. Do not move or close it.
 */
forward void Cel_OnSaveEntity(int iEntity, KeyValues kvSave);

/**
 * Called for each entity after it has been spawned from a build, so a plugin can restore its own data.
 *
 * @param iClient  The client loading the build.
 * @param iEntity  The entity that was spawned.
 * @param kvSave   The save file, positioned on this entity's section. Do not move or close it.
 */
forward void Cel_OnLoadEntity(int iClient, int iEntity, KeyValues kvSave);

native void Cel_AddToBlacklist(char[] sAlias);

/**
 * Increments the Cel entity count for a client.
 *
 * @param iClient  The client index whose Cel count should be increased.
 */
native void Cel_AddToCelCount(int iClient);

native void Cel_AddToClientBalance(int iClient, int iBalance);

/**
 * Increments the prop entity count for a client.
 *
 * @param iClient  The client index whose prop count should be increased.
 */
native void Cel_AddToPropCount(int iClient);

native void Cel_BuyCommand(int iClient, char[] sCommand, char[] sDisplayText, int iMaxLength);

native void Cel_BuyEntity(int iClient, int iOwner, int iProp, int iPrice);

native void Cel_CancelSale(int iClient, int iProp);

/**
 * Changes the beam effect of an entity.
 *
 * @param iClient  The client index performing the change.
 * @param iEntity  The entity index whose beam effect is being changed.
 */
native void Cel_ChangeBeam(int iClient, int iEntity);

/**
 * Moves an entity by adding an offset to its current position.
 *
 * @param iEntity	   The entity index to move.
 * @param fAddOrigin	The float array containing the X, Y, and Z offset values.
 */
native void Cel_ChangePositionRelativeToOrigin(int iEntity, const float fAddOrigin[3]);

native bool Cel_CheckBlacklistDB(const char[] sAlias);

/**
 * Checks if a client has reached their Cel entity limit.
 *
 * @param iClient  The client index to check.
 * @return		 True if the client is within the limit, false if they have exceeded it.
 */
native bool Cel_CheckCelCount(int iClient);

native bool Cel_CheckClientBalance(int iClient, int iPrice);

native bool Cel_CheckClientPurchase(int iClient, char[] sCommand);

/**
 * Validates a color name against the internal color database.
 *
 * @param sColor		The input color name to check.
 * @param sColorString  The output string that stores the validated color.
 * @param iMaxLength	The maximum length of the output string.
 * @return			  True if the color is valid, false otherwise.
 */
native bool Cel_CheckColorDB(const char[] sColor, char[] sColorString, int iMaxLength);

/**
 * Checks if the given effect matches a specified type.
 *
 * @param iEffect   The entity index of the effect.
 * @param sType	 The effect type to check against.
 * @return		  True if the effect matches the specified type, false otherwise.
 */
native bool Cel_CheckEffectType(const int iEffect, const char[] sType);

/**
 * Checks if an entity belongs to a specific category.
 *
 * @param iEntity		  The entity index to check.
 * @param ecEntityCatagory The category to compare against (EntityCatagory enum).
 * @return				 True if the entity matches the category, false otherwise.
 */
native bool Cel_CheckEntityCatagory(int iEntity, EntityCatagory ecEntityCatagory);

/**
 * Checks if an entity matches a specific type.
 *
 * @param iEntity	  The entity index to check.
 * @param sTypeCheck   The type name to compare against.
 * @return			 True if the entity matches the type, false otherwise.
 */
native bool Cel_CheckEntityType(int iEntity, const char[] sTypeCheck);

/**
 * Validates and processes a given input URL.
 *
 * @param sInput	 The input URL to validate.
 * @param sOutput	Buffer to store the processed or validated URL.
 * @param iMaxLength Maximum length of the output buffer.
 * @return		   The processed URL as a string.
 */
native char Cel_CheckInputURL(const char[] sInput, char[] sOutput, int iMaxLength);

/**
 * Verifies whether a client is the owner of a given entity.
 *
 * @param iClient  The client index to check.
 * @param iEntity  The entity index to verify ownership.
 * @return		 True if the client owns the entity, false otherwise.
 */
native bool Cel_CheckOwner(int iClient, int iEntity);

/**
 * Checks if a client has reached their prop entity limit.
 *
 * @param iClient  The client index to check.
 * @return		 True if the client is within the limit, false if they have exceeded it.
 */
native bool Cel_CheckPropCount(int iClient);

/**
 * Checks an entity's render effect type.
 *
 * @param iEntity  The entity index to check.
 * @param sType	The render effect type to compare.
 * @return		 True if the entity matches the render effect type, false otherwise.
 */
native bool Cel_CheckRenderFX(const int iEntity, const char[] sType);

native bool Cel_CheckShopDB(char[] sCommand, int &iPrice, char[] sDisplayText, int iMaxLength);

/**
 * Validates an alias against the internal spawn database.
 *
 * @param sAlias		The alias name to check.
 * @param sSpawnString  The output string containing the valid spawn entity name.
 * @param iMaxLength	The maximum length of the output string.
 * @return			  True if the alias exists in the database, false otherwise.
 */
native bool Cel_CheckSpawnDB(const char[] sAlias, char[] sSpawnString, int iMaxLength);

/**
 * Opens a menu for the client to choose a custom HUD color.
 *
 * @param iClient  The client index of the player.
 */
native void Cel_ChooseHudColor(int iClient);

/**
 * Clears the land data associated with a client.
 *
 * @param iClient  The client index of the player.
 */
native void Cel_ClearLand(int iClient);

native void Cel_CopyProp(int iClient, int iProp);

/**
 * Creates an initial set of purchases for the specified client.
 *
 * @param iClient  The client index.
 */
native void Cel_CreateClientPurchases(int iClient);

/**
 * Creates default settings for a client.
 *
 * @param iClient  The client index.
 */
native void Cel_CreateClientSettings(int iClient);

/**
 * Creates a land area for a client based on the provided coordinates.
 *
 * @param iClient  The client index of the player.
 * @param fMin	 The minimum (bottom corner) coordinates of the land.
 * @param fMax	 The maximum (top corner) coordinates of the land.
 * @return		 The entity index of the created land.
 */
native int Cel_CreateLand(int iClient, float fMin[3], float fMax[3]);

/**
 * Dissolves an entity in the game world.
 *
 * @param iEntity  The entity index to dissolve.
 */
native void Cel_DissolveEntity(int iEntity);

native void Cel_DownloadClientFiles();

/**
 * Draws visual border lines for a land area.
 *
 * @param fFrom   The starting coordinate of the border.
 * @param fTo	 The ending coordinate of the border.
 * @param fLife   The duration the border remains visible (in seconds).
 * @param iColor  RGBA color array for the border.
 * @param bFlat   Whether the borders should be drawn flat (default: true).
 */
native void Cel_DrawLandBorders(float fFrom[3], float fTo[3], float fLife, int iColor[4], bool bFlat=true);

native void Cel_DropEntityToFloor(int iEntity);

/**
 * Exports the color list to a file.
 *
 * @param bHTML   If true, exports in HTML format; otherwise, exports in plain text.
 * @return		True on success, false on failure.
 */
native bool Cel_ExportColorList(bool bHTML);

/**
 * Exports the list of available CelMod commands.
 *
 * @param bHTML   If true, exports in HTML format; otherwise, exports in plain text.
 * @return		True on success, false on failure.
 */
native bool Cel_ExportCommandList(bool bHTML);

/**
 * Exports the list of available prop entities.
 *
 * @param bHTML   If true, exports in HTML format; otherwise, exports in plain text.
 * @return		True on success, false on failure.
 */
native bool Cel_ExportPropList(bool bHTML);

native AmmoCrateType Cel_GetAmmoCrateType(int iEntity);

native AmmoCrateType Cel_GetAmmoCrateTypeFromName(char[] sAmmoCrate);

native void Cel_GetAmmoCrateTypeName(AmmoCrateType actType, const char[] sName, int iMaxLength);

native AmmoBitType Cel_GetAmmoType(int iEntity);

native AmmoBitType Cel_GetAmmoTypeFromName(char[] sAmmo);

native void Cel_GetAmmoTypeName(AmmoBitType abtType, const char[] sName, int iMaxLength);

native char Cel_GetAuthID(int iClient, char[] sAuthID, int iMaxLength);

/**
 * Retrieves the material used for beams.
 *
 * @return The index of the beam material.
 */
native int Cel_GetBeamMaterial();

/**
 * Retrieves the current Cel entity count for a client.
 *
 * @param iClient  The client index to check.
 * @return		 The number of Cels the client currently has spawned.
 */
native int Cel_GetCelCount(int iClient);

/**
 * Retrieves the maximum allowed number of Cels.
 *
 * @return The maximum limit of Cels a client can spawn.
 */
native int Cel_GetCelLimit();

native ChargerType Cel_GetChargerType(int iEntity);

native ChargerType Cel_GetChargerTypeFromName(char[] sCharger);

native void Cel_GetChargerTypeName(ChargerType ctType, const char[] sName, int iMaxLength);

/**
 * Retrieves the entity the client is currently aiming at.
 *
 * @param iClient  The client index to check.
 * @return		 The entity index of the aimed target, or -1 if none.
 */
native int Cel_GetClientAimTarget(int iClient);

native int Cel_GetClientBalance(int iClient);

native void Cel_GetClientBalanceTranslated(int iClient, char[] sBalance, int iMaxLength);

native bool Cel_GetClientPurchaseStatus(int iClient, char[] sCommand);

/**
 * Gets a client's setting value as a float.
 *
 * @param iClient  The client index.
 * @param sSetting The setting name to retrieve.
 * @return		 The value of the setting as a float.
 */
native float Cel_GetClientSettingFloat(int iClient, char[] sSetting);

/**
 * Gets a client's setting value as an integer.
 *
 * @param iClient  The client index.
 * @param sSetting The setting name to retrieve.
 * @return		 The value of the setting as an integer.
 */
native int Cel_GetClientSettingInt(int iClient, char[] sSetting);

/**
 * Gets a client's setting value as a string.
 *
 * @param iClient	The client index.
 * @param sSetting   The setting name to retrieve.
 * @param sValue	 The output string that will hold the setting's value.
 * @param iMaxLength The maximum length of the output string.
 */
native void Cel_GetClientSettingString(int iClient, char[] sSetting, char[] sValue, int iMaxLength);

/**
 * Retrieves the color of an entity.
 *
 * @param iEntity  The entity index.
 * @param iColor   An integer array [R, G, B, A] storing the color values.
 * @return		 The color as an integer array.
 */
/**
 * Retrieves the id of the emblem or hat an entity is (the section name in collectibles.txt).
 *
 * @return  True if the entity is an emblem or hat.
 */
native bool Cel_GetCollectibleId(int iEntity, char[] sId, int iMaxLength);

/**
 * Retrieves the display name of the emblem or hat an entity is.
 *
 * @return  True if the entity is an emblem or hat.
 */
native bool Cel_GetCollectibleName(int iEntity, char[] sName, int iMaxLength);

/**
 * Adds an emblem or hat to a client's inventory.
 *
 * @param sKind  "emblem" or "hat".
 * @param sId	The id or name of the item.
 * @return	   True if the item exists and was given.
 */
native bool Cel_GiveCollectible(int iClient, const char[] sKind, const char[] sId);

native bool Cel_IsCollectible(int iEntity);

/**
 * The emblem inside an emblem drop box.
 *
 * @return  False when the entity is not an emblem drop box.
 */
native bool Cel_GetDropBoxEmblem(int iEntity, char[] sName, int iMaxLength);

/**
 * Lets an emblem drop in emblem drops (or stops it), overriding collectibles.txt. Set from the website's admin panel.
 */
native bool Cel_SetEmblemDroppable(const char[] sId, bool bDroppable);

/** Every emblem goes back to collectibles.txt deciding whether it drops. */
native void Cel_ResetEmblemDroppable();

/**
 * Sets which emblems the one-time free emblem in a player's build is picked from (comma separated ids),
 * in place of cm_emblem_gift_list. An empty list goes back to the cvar.
 */
native void Cel_SetEmblemGiftList(const char[] sList);

/** Starts an emblem drop of a number of boxes (1 to 30). Returns how many fell. */
native int Cel_StartEmblemDrop(int iCount);

/**
 * Text describing a reward pickup (an event emblem, or a reward placed with !reward), for the HUD.
 *
 * @return  False when the entity is not a reward pickup.
 */
native bool Cel_GetRewardLabel(int iEntity, char[] sLabel, int iMaxLength);

#define CEL_ZONE_NONE -1
#define CEL_ZONE_RESTRICTED 0
#define CEL_ZONE_EVENT 1
#define CEL_ZONE_BUILD 2

/**
 * Which kind of admin made area a point is in (from the zones plugin, which may not be loaded: mark it optional).
 *
 * @return  CEL_ZONE_NONE, CEL_ZONE_RESTRICTED, CEL_ZONE_EVENT or CEL_ZONE_BUILD.
 */
native int Cel_GetZoneType(const float fPos[3]);

/**
 * Whether a player has the event and restricted area rules turned off (an admin's !zonebypass).
 * From the zones plugin, which may not be loaded: mark it optional.
 */
native bool Cel_IsZoneExempt(int iClient);

/**
 * The Guess Booth's area: a square fHalf units from its middle to each side, turned to fYaw, from its floor
 * (fCenter[2]) up to 160 units. Returns false when there's no booth on this map.
 */
native bool Cel_GetGuessBoothArea(float fCenter[3], float &fYaw, float &fHalf);

/**
 * Whether a land's box (two opposite corners) overlaps the Guess Booth's area, with fMargin units to spare
 * around the booth. False when the booth plugin isn't loaded or there's no booth.
 */
stock bool Cel_LandHitsGuessBooth(const float fCornerA[3], const float fCornerB[3], float fMargin = 16.0)
{
	float fCenter[3], fYaw, fHalf;

	if (GetFeatureStatus(FeatureType_Native, "Cel_GetGuessBoothArea") != FeatureStatus_Available || !Cel_GetGuessBoothArea(fCenter, fYaw, fHalf))
	{
		return false;
	}

	// Heights first: the land's box against the booth's floor to 160 units above it.
	float fLow = fCornerA[2] < fCornerB[2] ? fCornerA[2] : fCornerB[2], fHigh = fCornerA[2] < fCornerB[2] ? fCornerB[2] : fCornerA[2];

	if (fHigh < fCenter[2] - 32.0 || fLow > fCenter[2] + 160.0)
	{
		return false;
	}

	// Then from above: the land's rectangle against the booth's turned square (separating axis test).
	float fBoxMid[2], fBoxHalf[2];

	fBoxMid[0] = (fCornerA[0] + fCornerB[0]) / 2.0;
	fBoxMid[1] = (fCornerA[1] + fCornerB[1]) / 2.0;
	fBoxHalf[0] = FloatAbs(fCornerA[0] - fCornerB[0]) / 2.0;
	fBoxHalf[1] = FloatAbs(fCornerA[1] - fCornerB[1]) / 2.0;

	fHalf += fMargin;

	float fRad = DegToRad(fYaw);
	float fF[2], fR[2];

	fF[0] = Cosine(fRad); fF[1] = Sine(fRad);
	fR[0] = Sine(fRad); fR[1] = -Cosine(fRad);

	float fAxes[4][2];

	fAxes[0][0] = 1.0; fAxes[0][1] = 0.0;
	fAxes[1][0] = 0.0; fAxes[1][1] = 1.0;
	fAxes[2] = fF;
	fAxes[3] = fR;

	for (int i = 0; i < 4; i++)
	{
		float fDistance = FloatAbs((fBoxMid[0] - fCenter[0]) * fAxes[i][0] + (fBoxMid[1] - fCenter[1]) * fAxes[i][1]);
		float fBoxReach = fBoxHalf[0] * FloatAbs(fAxes[i][0]) + fBoxHalf[1] * FloatAbs(fAxes[i][1]);
		float fBoothReach = fHalf * (FloatAbs(fF[0] * fAxes[i][0] + fF[1] * fAxes[i][1]) + FloatAbs(fR[0] * fAxes[i][0] + fR[1] * fAxes[i][1]));

		if (fDistance > fBoxReach + fBoothReach)
		{
			return false;
		}
	}

	return true;
}

/** Cel_IsZoneExempt, or false when the zones plugin isn't loaded. */
stock bool Cel_ZoneExempt(int iClient)
{
	return GetFeatureStatus(FeatureType_Native, "Cel_IsZoneExempt") == FeatureStatus_Available && Cel_IsZoneExempt(iClient);
}

/**
 * How many of an emblem, hat or weapon a client owns.
 *
 * @return  The count, or -1 if there is no such item.
 */
native int Cel_GetCollectibleCount(int iClient, const char[] sKind, const char[] sId);

/** Number of player models in collectibles.txt. */
native int Cel_GetPlayerModelCount();

/**
 * Reads a player model from collectibles.txt by index (0 to Cel_GetPlayerModelCount() - 1).
 *
 * @param iAdminFlags  Admin flags that own it for free (0 = none).
 * @return             False if the index is out of range.
 */
native bool Cel_GetPlayerModelInfo(int iIndex, char[] sId, int iIdLength, char[] sName, int iNameLength, int &iPrice, int &iAdminFlags);

/**
 * The seasonal shop a player model is only sold in (a key from "Seasons" in shop.txt), or "" for all year.
 */
native void Cel_GetPlayerModelSeason(int iIndex, char[] sSeason, int iMaxLength);

/**
 * Whether a client owns a player model (bought, given, free, or through admin flags).
 *
 * @return  1 owned, 0 not owned, -1 no such model.
 */
native int Cel_OwnsPlayerModel(int iClient, const char[] sId);

/**
 * Gives a client a player model for good, like !givemodel.
 *
 * @return  True if the model exists and was given.
 */
native bool Cel_GivePlayerModel(int iClient, const char[] sId);

/**
 * Checks a prop alias against the shop's rare / discontinued props (the "Props" section of shop.txt).
 *
 * @param sSpawnString  Filled with "classname|model" when the client may spawn it.
 * @return              0 = not a shop prop (spawn it normally), 1 = the client owns it, -1 = locked.
 */
native int Cel_CheckShopProp(int iClient, const char[] sAlias, char[] sSpawnString, int iMaxLength);

/** Number of items in the shop catalog (celmod-shop). */
native int Cel_ShopGetItemCount();

/**
 * Reads a shop item by index (0 to Cel_ShopGetItemCount() - 1).
 *
 * @param sKey         What players type to buy it, e.g. "fire", "prop_megapumpkin", "model_gman".
 * @param iLeft        How many can still be sold, or -1 for no limit.
 * @param bRepeatable  True if it can be bought more than once (emblems).
 * @return             False if the index is out of range.
 */
native bool Cel_ShopGetItem(int iIndex, char[] sKey, int iKeyLength, char[] sName, int iNameLength, char[] sCategory, int iCategoryLength, char[] sDescription, int iDescriptionLength, int &iPrice, int &iLeft, bool &bRepeatable);

/**
 * What a shop item is: "command", "prop", "model", or a collectible kind ("emblem", "hat", "weapon"),
 * and what it unlocks (the command, prop alias, model id or collectible id).
 */
native bool Cel_ShopGetItemType(int iIndex, char[] sType, int iTypeLength, char[] sTarget, int iTargetLength);

/** Whether a client already owns a shop item (always false for items that can be bought again). */
native bool Cel_ShopOwnsItem(int iClient, const char[] sKey);

/** Index of a shop item by key, or -1. */
native int Cel_ShopFindItem(const char[] sKey);

/**
 * Sells a shop item to a client: checks it exists, is in stock, not already owned and affordable,
 * then charges the client, gives the item and counts it against the stock.
 *
 * @param iMaxPrice  Refuse if the price is now higher than this (web orders), or -1 for no limit.
 * @param sError     Why it failed, for the player.
 * @return           The price charged, or -1 if nothing was sold.
 */
native int Cel_ShopDeliver(int iClient, const char[] sKey, int iMaxPrice, char[] sError, int iErrorLength);

/**
 * Whether a seasonal shop's season (a key from "Seasons" in shop.txt, like "christmas") is on today.
 */
native bool Cel_IsSeasonOpen(const char[] sSeason);

/**
 * Adds to a player's leaderboard stat on the website (celmod-database): land_bans, kills, deaths, enemy_kills or
 * presents_given.
 */
native void Cel_AddPlayerStat(int iClient, const char[] sStat, int iAmount);

/**
 * Sets a player's leaderboard total on the website (celmod-database): emblems_owned.
 */
native void Cel_SetPlayerStat(int iClient, const char[] sStat, int iValue);

/** Cel_AddPlayerStat when the database plugin is loaded (it is optional). */
stock void Cel_AddStat(int iClient, const char[] sStat, int iAmount = 1)
{
	if (GetFeatureStatus(FeatureType_Native, "Cel_AddPlayerStat") == FeatureStatus_Available)
	{
		Cel_AddPlayerStat(iClient, sStat, iAmount);
	}
}

/** Cel_SetPlayerStat when the database plugin is loaded (it is optional). */
stock void Cel_SetStat(int iClient, const char[] sStat, int iValue)
{
	if (GetFeatureStatus(FeatureType_Native, "Cel_SetPlayerStat") == FeatureStatus_Available)
	{
		Cel_SetPlayerStat(iClient, sStat, iValue);
	}
}

/**
 * Looks up how an emblem, hat or weapon looks, to put one on display.
 *
 * @param sKind  "emblem", "hat" or "weapon".
 * @param sId	The id or name of the item.
 * @return	   True if the item exists.
 */
native bool Cel_GetCollectibleLook(const char[] sKind, const char[] sId, char[] sModel, int iModelLength, char[] sName, int iNameLength, int &iSkin, int iColor[4]);

native int Cel_GetColor(int iEntity, int iColor[4]);

native int Cel_GetCombinedCount(int iClient);

/**
 * Retrieves the world position where a client is aiming.
 *
 * @param iClient			 The client index.
 * @param fCrosshairOrigin	The output float array storing the position [X, Y, Z].
 * @return					The origin coordinates as a float array.
 */
native float Cel_GetCrosshairHitOrigin(int iClient, float fCrosshairOrigin[3]);

/**
 * Retrieves the current land entity associated with a client.
 *
 * @param iClient  The client index of the player.
 * @return		 The entity index of the land.
 */
native int Cel_GetCurrentLandEntity(int iClient);

/**
 * Retrieves the current owner of the land associated with a client.
 *
 * @param iClient  The client index of the player.
 * @return		 The client index of the land owner.
 */
native int Cel_GetCurrentLandOwner(int iClient);

/**
 * Retrieves the attachment index for an effect.
 *
 * @param iEffect   The entity index of the effect.
 * @return		  The attachment index used by the effect.
 */
native int Cel_GetEffectAttachment(int iEffect);

/**
 * Gets the type of an effect entity.
 *
 * @param iEffect   The entity index of the effect.
 * @return		  The EffectType enumeration of the effect.
 */
native EffectType Cel_GetEffectType(int iEffect);

/**
 * Retrieves the EffectType from a given effect name.
 *
 * @param sEffectName  The name of the effect type.
 * @return			 The corresponding EffectType enumeration.
 */
native EffectType Cel_GetEffectTypeFromName(const char[] sEffectName);

/**
 * Retrieves the name of an effect type.
 *
 * @param etEffectType  The EffectType enumeration.
 * @param sEffectType   Buffer to store the effect type name.
 * @param iMaxLength	Maximum length of the buffer.
 */
native char Cel_GetEffectTypeName(EffectType etEffectType, char[] sEffectType, int iMaxLength);

/**
 * Retrieves the category of a given entity.
 *
 * @param iEntity  The entity index.
 * @return		 The entity's category as an EntityCatagory enum.
 */
native EntityCatagory Cel_GetEntityCatagory(int iEntity);

/**
 * Retrieves the name of an entity category.
 *
 * @param iEntity			The entity index.
 * @param sEntityCatagory	The output string storing the category name.
 * @param iMaxLength		 The maximum length of the output string.
 * @return				   The category name as a string.
 */
native char Cel_GetEntityCatagoryName(int iEntity, char[] sEntityCatagory, int iMaxLength);

native int Cel_GetEntityPrice(int iEntity);

/**
 * Retrieves the type of a given entity.
 *
 * @param iEntity  The entity index.
 * @return		 The entity's type as an EntityType enum.
 */
native EntityType Cel_GetEntityType(int iEntity);

/**
 * Retrieves the EntityType enum from a string.
 *
 * @param sEntityType  The name of the entity type.
 * @return			 The corresponding EntityType enum.
 */
native EntityType Cel_GetEntityTypeFromName(const char[] sEntityType);

/**
 * Retrieves the name of an entity type.
 *
 * @param etEntityType  The EntityType enum to convert.
 * @param sEntityType   The output string storing the entity type name.
 * @param iMaxLength	The maximum length of the output string.
 * @return			  The entity type name as a string.
 */
native char Cel_GetEntityTypeName(EntityType etEntityType, char[] sEntityType, int iMaxLength);

native void Cel_GiveEntity(int iClient, int iTarget, int iEntity);

native void Cel_GetFadeColor(int iEntity, iFadeFrom[3], iFadeTo[3]);

/**
 * Retrieves the material used for halos.
 *
 * @return The index of the halo material.
 */
native int Cel_GetHaloMaterial();

/**
 * Retrieves the current HUD color settings for a client.
 *
 * @param iClient  The client index of the player.
 * @param iColor   Array to store the RGBA color values.
 * @return		 The HUD color as an integer array (R, G, B, A).
 */
native int Cel_GetHudColor(int iClient, int iColor[4]);

/**
 * Retrieves the URL associated with an Internet Cel entity.
 *
 * @param iEntity   The entity index.
 * @param sURL	  The output string storing the URL.
 * @param iMaxLength The maximum length of the output string.
 * @return		  The entity's assigned URL as a string.
 */
native char Cel_GetInternetURL(int iEntity, const char[] sURL, int iMaxLength);

/**
 * Retrieves the land entity within the given coordinate range.
 *
 * @param fBottomCorner  The bottom corner of the search area.
 * @param fTopCorner	 The top corner of the search area.
 * @return			   The entity index of the land found, or -1 if none.
 */
native int Cel_GetLandEntity(float fBottomCorner[3], float fTopCorner[3]);

/**
 * Gets the gravity setting of a specific land area.
 *
 * @param iLandOwner  The client index of the land owner.
 * @return			The gravity value of the land.
 */
native float Cel_GetLandGravity(int iLandOwner);

/**
 * Gets the owner of a specific land area based on coordinates.
 *
 * @param fBottomCorner  The bottom corner of the search area.
 * @param fTopCorner	 The top corner of the search area.
 * @return			   The client index of the land owner, or -1 if none.
 */
native int Cel_GetLandOwner(float fBottomCorner[3], float fTopCorner[3]);

native int Cel_GetLandOwnerFromEntity(int iEntity);

/**
 * Build teams: whether a player is on a land owner's build team (!addteam).
 */
native bool Cel_IsOnBuildTeam(int iLandOwner, int iClient);

/**
 * Whether a player may build on (move, colour, freeze, delete...) an entity: their own, or one owned by the land
 * owner or a teammate, sitting in the land of an owner whose build team they are on (or that they own).
 * Selling, giving and trading still need real ownership (Cel_CheckOwner).
 */
native bool Cel_CanEdit(int iClient, int iEntity);

native int Cel_GetLandOwnerFromPosition(float fOrigin[3]);

/**
 * Retrieves a position from a land entity, useful for determining points in a land area.
 *
 * @param iClient	The client index of the player.
 * @param iPosition  The position type (default: 1).
 * @param fPosition  The retrieved position stored in an array.
 * @return		   The position as a float array.
 */
native float Cel_GetLandPositions(int iClient, int iPosition=1, float fPosition[3]);

/**
 * Calculates the center point of a box given two opposite corners.
 *
 * @param fMin	  The minimum (bottom corner) coordinates.
 * @param fMax	  The maximum (top corner) coordinates.
 * @param fBuffer   The output buffer storing the center coordinates.
 */
native void Cel_GetMiddleOfABox(float fMin[3], float fMax[3], float fBuffer[3]);

/**
 * Checks if an entity has motion enabled.
 *
 * @param iEntity  The entity index to check.
 * @return		 True if the entity has motion, false otherwise.
 */
native bool Cel_GetMotion(int iEntity);

/**
 * Retrieves the NoKill status of a client.
 *
 * @param iClient  The client index.
 * @return		 An integer representing the NoKill status.
 */
native int Cel_GetNoKill(int iClient);

/**
 * Retrieves the owner of an entity.
 *
 * @param iEntity  The entity index.
 * @return		 The client index of the owner.
 */
native int Cel_GetOwner(int iEntity);

/**
 * Retrieves the default physics material.
 *
 * @return The index of the physics material.
 */
native int Cel_GetPhysicsMaterial();

/**
 * Retrieves the current prop entity count for a client.
 *
 * @param iClient  The client index.
 * @return		 The number of props the client currently has spawned.
 */
native int Cel_GetPropCount(int iClient);

/**
 * Counts the props and cels a client really has out and corrects their counts (which can drift).
 */
native void Cel_RecountClientEntities(int iClient);

/**
 * Bank items out in the world (emblems, hats and celweps, shop props, hobos) have their own count and limit
 * (cm_max_items) instead of counting toward the prop or cel limit.
 */
/**
 * Deletes the dug-up find (Vial, ore, turd, junk) the client is looking at, if they may. True when handled.
 */
native bool Cel_DeleteFind(int iClient);
native void Cel_MarkBankItem(int iEntity);
native bool Cel_IsBankItem(int iEntity);
native bool Cel_CheckItemCount(int iClient);
native int Cel_GetItemCount(int iClient);
native void Cel_SubFromItemCount(int iClient);
native void Cel_AddToItemCount(int iClient);

/**
 * Retrieves the maximum allowed number of props.
 *
 * @return The maximum limit of props a client can spawn.
 */
native int Cel_GetPropLimit();

/**
 * Retrieves the name of a prop entity.
 *
 * @param iEntity	 The entity index.
 * @param sPropName   The output string storing the prop name.
 * @param iMaxLength  The maximum length of the output string.
 * @return			The prop name as a string.
 */
native char Cel_GetPropName(int iEntity, const char[] sPropName, int iMaxLength);

/**
 * Retrieves the render effect applied to an entity.
 *
 * @param iEntity  The entity index.
 * @return		 The render effect as a RenderFx enum.
 */
native RenderFx Cel_GetRenderFX(int iEntity);

/**
 * Retrieves the RenderFx enum from a string name.
 *
 * @param sRenderFXName  The render effect name.
 * @return			   The corresponding RenderFx enum.
 */
native RenderFx Cel_GetRenderFXFromName(const char[] sRenderFXName);

/**
 * Retrieves the name of a render effect.
 *
 * @param rfRenderFX  The RenderFx enum.
 * @param sRenderFX   The output string storing the render effect name.
 * @param iMaxLength  The maximum length of the output string.
 * @return			The render effect name as a string.
 */
native char Cel_GetRenderFXName(RenderFx rfRenderFX, char[] sRenderFX, int iMaxLength);

native int Cel_GetSaveSystemVersion();

native int Cel_GetTriggerLink(int iEntity);

native void Cel_SetTriggerLink(int iEntity, int iTarget);

native int Cel_GetTriggerType(iEntity);

native WeaponBitType Cel_GetWeaponType(int iEntity);

native WeaponBitType Cel_GetWeaponTypeFromName(char[] sWeapon);

native void Cel_GetWeaponTypeName(WeaponBitType wbtType, const char[] sName, int iMaxLength);

native bool Cel_IsBreakable(int iEntity);

native bool Cel_IsCelCommand(char sCommandString[MAX_MESSAGE_LENGTH]);

native bool Cel_IsClientCrosshairInLand(int iClient);

native bool Cel_IsClientInLand(int iClient);

/**
 * Checks if an effect entity is currently active.
 *
 * @param iEffect   The entity index of the effect.
 * @return		  True if the effect is active, false otherwise.
 */
native bool Cel_IsEffectActive(int iEffect);

/**
 * Checks if an entity is valid.
 *
 * @param iEntity  The entity index.
 * @return		 True if the entity exists, false otherwise.
 */
native bool Cel_IsEntity(int iEntity);

native bool Cel_IsEntityForSale(int iEntity);

native bool Cel_IsEntityInLand(int iEntity);

native bool Cel_IsFading(int iEntity);

native bool Cel_IsLandCreated(int iClient);

native bool Cel_IsLocked(int iEntity);

/**
 * Perm (!perm): a prop that stays exactly where it is. It is frozen and can't be unfrozen, picked up with the
 * gravity gun, moved, turned, dropped or deleted on its own (!delall still removes everything) until !unperm.
 */
native bool Cel_IsPerm(int iEntity);
native void Cel_SetPerm(int iEntity, bool bPerm);

/**
 * Checks if a client is a valid player.
 *
 * @param iClient  The client index.
 * @return		 True if the client is a player, false otherwise.
 */
native bool Cel_IsPlayer(int iClient);

/**
 * Checks if a given position is inside a defined land area.
 *
 * @param fPos		   The position to check.
 * @param fBottomCorner  The bottom corner of the land area.
 * @param fTopCorner	 The top corner of the land area.
 * @return			   True if the position is inside the area, false otherwise.
 */
native bool Cel_IsPositionInBox(float fPos[3], float fBottomCorner[3], float fTopCorner[3]);

native bool Cel_IsRainbow(int iEntity);

/**
 * Checks if an entity is solid.
 *
 * @param iEntity  The entity index.
 * @return		 True if the entity is solid, false otherwise.
 */
native bool Cel_IsSolid(int iEntity);

native bool Cel_IsTrigger(iEntity);

/**
 * Loads a saved build for a client.
 *
 * @param iClient   The client index.
 * @param sSaveName The name of the save file.
 */
native void Cel_LoadBuild(int iClient, const char[] sSaveName);

native void Cel_LockEntity(int iEntity, bool bLocked);

/**
 * Notifies a client that they are not looking at a valid entity.
 *
 * @param iClient  The client index.
 */
native void Cel_NotLooking(int iClient);

/**
 * Notifies a client that an entity does not belong to them.
 *
 * @param iClient  The client index.
 * @param iEntity  The entity index.
 */
native void Cel_NotYours(int iClient, int iEntity);

/**
 * Opens a Message of the Day (MOTD) panel for a client.
 *
 * @param iClient	  The client index of the player.
 * @param bShow		True to show the MOTD panel, false to close it.
 * @param sTitle	   The title of the MOTD window.
 * @param sDestination The URL or text content to be displayed.
 * @param iType		The type of MOTD panel (default is MOTDPANEL_TYPE_URL).
 */
native void Cel_OpenMOTDOnClient(int iClient, bool bShow, const char[] sTitle, const char[] sDestination, int iType = MOTDPANEL_TYPE_URL);

native int Cel_PasteProp(int iClient, float fAngles[3], float fOrigin[3]);

/**
 * Plays a chat message sound for a client.
 *
 * @param iClient  The client index.
 */
native void Cel_PlayChatMessageSound(int iClient);

/**
 * Sends a message to a specific client in chat.
 *
 * @param iClient   The client index.
 * @param sMessage  The message format string.
 * @param ...	   Additional formatting arguments.
 */
native void Cel_PrintToChat(int iClient, const char[] sMessage, any ...);

/**
 * Sends a message to all clients in chat.
 *
 * @param sMessage  The message format string.
 * @param ...	   Additional formatting arguments.
 */
native void Cel_PrintToChatAll(const char[] sMessage, any ...);

/**
 * Creates a removal beam effect on an entity.
 *
 * @param iClient  The client index.
 * @param iEntity  The entity index to apply the effect on.
 */
native void Cel_RemovalBeam(int iClient, int iEntity);

/**
 * Removes a specific purchase for a client.
 *
 * @param iClient   The client index.
 * @param sPurchase The purchase to remove.
 */
native void Cel_RemoveClientPurchase(int iClient, char[] sPurchase);

native void Cel_RemoveFromBlacklist(char[] sAlias);

/**
 * Sends a command response to a client.
 *
 * @param iClient   The client index.
 * @param sMessage  The message format string.
 * @param ...	   Additional formatting arguments.
 */
native void Cel_ReplyToCommand(int iClient, const char[] sMessage, any ...);

native void Cel_ReplyToCommandEntity(int iClient, int iEntity, const char[] sMessage, any ...);

/**
 * Saves a client's current build.
 *
 * @param iClient   The client index.
 * @param sSaveName The name of the save file.
 */
native void Cel_SaveBuild(int iClient, const char[] sSaveName);

/**
 * Saves a purchase state for a client.
 *
 * @param iClient   The client index.
 * @param sPurchase The purchase name.
 * @param bPurchased The state of the purchase (true if purchased, false otherwise).
 */
native void Cel_SaveClientPurchase(int iClient, char[] sPurchase, bool bPurchased);

/**
 * How many of a purchase the client owns (shop props: one copy per purchase; older purchases count as 1).
 */
native int Cel_GetClientPurchaseCount(int iClient, const char[] sPurchase);

/**
 * Adds (or with a negative number takes away) copies of a purchase. Returns the new count.
 */
native int Cel_AddClientPurchase(int iClient, const char[] sPurchase, int iAdd);

/**
 * Sends a HUD message to a client with specific positioning, color, and effects.
 *
 * @param iClient   The client index of the player.
 * @param iChannel  The HUD channel to use (0-4).
 * @param fX		The X position of the message (0.0 - 1.0).
 * @param fY		The Y position of the message (0.0 - 1.0).
 * @param iR		Red color component (0-255).
 * @param iG		Green color component (0-255).
 * @param iB		Blue color component (0-255).
 * @param iA		Alpha (transparency) value (0-255).
 * @param iEffect   Text effect type (0 = none, 1 = fade in/out, 2 = flicker).
 * @param fFadeIn   Time for fade-in effect (in seconds).
 * @param fFadeOut  Time for fade-out effect (in seconds).
 * @param fHoldTime Duration the message stays on screen (in seconds).
 * @param fFxTime   Effect duration (for flicker or other effects).
 * @param sMessage  The message to display.
 */
native void Cel_SendHudMessage(int iClient, int iChannel, float fX, float fY, int iR, int iG, int iB, int iA, int iEffect, float fFadeIn, float fFadeOut, float fHoldTime, float fFxTime, char[] sMessage);

/**
 * Sets a client's authentication ID.
 *
 * @param iClient  The client index.
 */
native void Cel_SetAuthID(int iClient);

native void Cel_SetBreakable(int iEntity, bool bBreakable);

/**
 * Sets the Cel entity count for a client.
 *
 * @param iClient  The client index.
 * @param iCount   The new Cel count.
 */
native void Cel_SetCelCount(int iClient, int iCount);

/**
 * Sets the global Cel entity limit.
 *
 * @param iLimit  The new Cel entity limit.
 */
native void Cel_SetCelLimit(int iLimit);

native void Cel_SetClientBalance(int iClient, int iBalance);

/**
 * Sets a client's setting value as a float.
 *
 * @param iClient  The client index.
 * @param sSetting The setting name to modify.
 * @param fValue   The new value to set for the setting (as a float).
 */
native void Cel_SetClientSettingFloat(int iClient, char[] sSetting, float fValue);

/**
 * Sets a client's setting value as an integer.
 *
 * @param iClient  The client index.
 * @param sSetting The setting name to modify.
 * @param iValue   The new value to set for the setting (as an integer).
 */
native void Cel_SetClientSettingInt(int iClient, char[] sSetting, int iValue);

/**
 * Sets a client's setting value as a string.
 *
 * @param iClient  The client index.
 * @param sSetting The setting name to modify.
 * @param sValue   The new value to set for the setting (as a string).
 */
native void Cel_SetClientSettingString(int iClient, char[] sSetting, char[] sValue);

/**
 * Sets the color of an entity.
 *
 * @param iEntity  The entity index.
 * @param iR	   The red component (0-255).
 * @param iG	   The green component (0-255).
 * @param iB	   The blue component (0-255).
 * @param iA	   The alpha component (0-255).
 */
native void Cel_SetColor(int iEntity, int iR, int iG, int iB, int iA);

native void Cel_SetColorFade(int iEntity, bool bFade, int iR1, int iG1, int iB1, int iR2, int iG2, int iB2);

/**
 * Sets the current land entity for a client.
 *
 * @param iClient	  The client index of the player.
 * @param iLandEntity  The entity index of the land to set.
 */
native int Cel_SetCurrentLandEntity(int iClient, int iLandEntity);

/**
 * Sets the current land owner for a client.
 *
 * @param iClient	 The client index of the player.
 * @param iLandOwner  The client index of the new land owner.
 */
native int Cel_SetCurrentLandOwner(int iClient, int iLandOwner);

/**
 * Sets the active state of an effect.
 *
 * @param iEffect   The entity index of the effect.
 * @param bActive   True to activate the effect, false to deactivate it.
 */
native void Cel_SetEffectActive(int iEffect, bool bActive);

/**
 * Sets the attachment index for an effect entity.
 *
 * @param iEffect	  The entity index of the effect.
 * @param iAttachment  The new attachment index.
 */
native void Cel_SetEffectAttachment(int iEffect, int iAttachment);

/**
 * Changes the effect type of an entity.
 *
 * @param iEffect	   The entity index of the effect.
 * @param etEffectType  The new EffectType to assign.
 */
native void Cel_SetEffectType(int iEffect, EffectType etEffectType);

/**
 * Sets an entity's existence state.
 *
 * @param iEntity   The entity index.
 * @param bEntity   True to enable, false to disable.
 */
native void Cel_SetEntity(int iEntity, bool bEntity);

/**
 * Sets the custom HUD color for a client.
 *
 * @param iClient  The client index of the player.
 * @param iR	   Red color component (0-255).
 * @param iG	   Green color component (0-255).
 * @param iB	   Blue color component (0-255).
 * @param iA	   Alpha (transparency) value (0-255).
 */
native void Cel_SetHudColor(int iClient, int iR, int iG, int iB, int iA);

/**
 * Assigns a URL to an Internet Cel entity.
 *
 * @param iEntity  The entity index.
 * @param sURL	 The URL string to associate with the entity.
 */
native void Cel_SetInternetURL(int iEntity, const char[] sURL);

/**
 * Sets the gravity level for a specific land area.
 *
 * @param iLandOwner  The client index of the land owner.
 * @param fGravity	The new gravity value.
 */
native void Cel_SetLandGravity(int iLandOwner, float fGravity);

/**
 * Sets the motion state of an entity.
 *
 * @param iEntity  The entity index.
 * @param bMotion  True to enable motion, false to disable.
 */
native void Cel_SetMotion(int iEntity, bool bMotion);

/**
 * Sets the NoKill status of a client.
 *
 * @param iClient  The client index.
 * @param bNoKill  True to enable NoKill, false to disable.
 */
native void Cel_SetNoKill(int iClient, bool bNoKill);

/**
 * Assigns ownership of an entity to a client.
 *
 * @param iClient  The client index.
 * @param iEntity  The entity index.
 */
native void Cel_SetOwner(int iClient, int iEntity);

/**
 * Sets whether a client is treated as a player.
 *
 * @param iClient  The client index.
 * @param bPlayer  True to treat as a player, false otherwise.
 */
native void Cel_SetPlayer(int iClient, bool bPlayer);

/**
 * Sets the current prop count for a client.
 *
 * @param iClient  The client index.
 * @param iCount   The new prop count.
 */
native void Cel_SetPropCount(int iClient, int iCount);

/**
 * Sets the global prop limit.
 *
 * @param iLimit  The new prop limit.
 */
native void Cel_SetPropLimit(int iLimit);

/**
 * Sets the name of a prop entity.
 *
 * @param iEntity	The entity index.
 * @param sPropName  The new name for the prop.
 */
native void Cel_SetPropName(int iEntity, const char[] sPropName);

native void Cel_SetRainbow(int iEntity, bool bRainbow);

/**
 * Sets the render effect of an entity.
 *
 * @param iEntity	 The entity index.
 * @param rfRenderFX  The render effect to apply.
 */
native void Cel_SetRenderFX(int iEntity, RenderFx rfRenderFX);

/**
 * Sets whether an entity is solid.
 *
 * @param iEntity  The entity index.
 * @param bSolid   True to make solid, false to make non-solid.
 */
native void Cel_SetSolid(int iEntity, bool bSolid);

native int Cel_SpawnAmmoBit(int iClient, AmmoBitType abtType, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

native int Cel_SpawnAmmoCrate(int iClient, AmmoCrateType actType, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

native int Cel_SpawnButton(iClient, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

native int Cel_SpawnCharger(int iClient, ChargerType ctType, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

/**
 * Spawns a door entity.
 *
 * @param iClient   The client index.
 * @param iSkin	 The skin number for the door.
 * @param fAngles   The rotation angles of the door.
 * @param fOrigin   The spawn origin of the door.
 * @param iR		Red color component (0-255).
 * @param iG		Green color component (0-255).
 * @param iB		Blue color component (0-255).
 * @param iA		Alpha transparency (0-255).
 * @return		  The entity index of the spawned door.
 */
native int Cel_SpawnDoor(int iClient, int iSkin, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

/**
 * Spawns an emblem or hat entity the client owns. Fails if every copy the client owns is already spawned.
 *
 * @param sKind  "emblem" or "hat".
 * @param sId	The id or name of the item.
 * @return	   The entity index, or -1 on failure.
 */
native int Cel_SpawnCollectible(int iClient, const char[] sKind, const char[] sId, float fAngles[3], float fOrigin[3]);

/**
 * Spawns an effect at a specified location.
 *
 * @param iClient	The client index of the player spawning the effect.
 * @param fOrigin	The origin coordinates where the effect will be spawned.
 * @param etEffect   The EffectType to be spawned.
 * @param bActivate  Whether the effect should be active upon spawning.
 * @param iR		 The red color component (0-255).
 * @param iG		 The green color component (0-255).
 * @param iB		 The blue color component (0-255).
 * @param iA		 The alpha (transparency) component (0-255).
 * @return		   The entity index of the spawned effect.
 */
native int Cel_SpawnEffect(const int iClient, const float fOrigin[3], const EffectType etEffect, bool bActivate, const int iR, const int iG, const int iB, const int iA);

/**
 * Spawns an Internet entity with a URL.
 *
 * @param iClient   The client index.
 * @param sURL	  The associated URL.
 * @param fAngles   The rotation angles of the entity.
 * @param fOrigin   The spawn origin.
 * @param iR		Red color component (0-255).
 * @param iG		Green color component (0-255).
 * @param iB		Blue color component (0-255).
 * @param iA		Alpha transparency (0-255).
 * @return		  The entity index of the spawned Internet entity.
 */
native int Cel_SpawnInternet(int iClient, const char[] sURL, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

native int Cel_SpawnLadder(int iClient, const char[] sModel, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

native int Cel_SpawnLight(int iClient, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

/**
 * Spawns a prop entity.
 *
 * @param iClient	 The client index.
 * @param sAlias	  The alias name for the prop.
 * @param sEntityType The type of the entity.
 * @param sModel	  The model path for the prop.
 * @param fAngles	 The rotation angles.
 * @param fOrigin	 The spawn origin.
 * @param iR		  Red color component (0-255).
 * @param iG		  Green color component (0-255).
 * @param iB		  Blue color component (0-255).
 * @param iA		  Alpha transparency (0-255).
 * @return			The entity index of the spawned prop.
 */
native int Cel_SpawnProp(int iClient, const char[] sAlias, const char[] sEntityType, const char[] sModel, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

native int Cel_SpawnWeaponBit(int iClient, WeaponBitType wbtType, float fAngles[3], float fOrigin[3], int iR, int iG, int iB, int iA);

native void Cel_StartSale(int iClient, int iEntity, int iPrice);

/**
 * Tactics level: a player's level, earned with experience from playing, building and fighting.
 */
native int Cel_GetTacticsLevel(int iClient);

/**
 * Experience towards the next tactics level.
 */
native int Cel_GetTacticsXP(int iClient);

/**
 * Experience the next tactics level needs in total.
 */
native int Cel_GetTacticsXPNeeded(int iClient);

/**
 * Gives a player tactics experience, levelling them up when they have enough.
 */
native void Cel_AddTacticsXP(int iClient, int iAmount);

/** Cel_AddTacticsXP when the economy plugin is loaded (mark Cel_AddTacticsXP optional to use it). */
stock void Cel_AddXP(int iClient, int iAmount)
{
	if (iAmount > 0 && GetFeatureStatus(FeatureType_Native, "Cel_AddTacticsXP") == FeatureStatus_Available)
	{
		Cel_AddTacticsXP(iClient, iAmount);
	}
}

/**
 * Spawns a cleers box: an owned money box only its owner can open (E). It can be given away with !give.
 *
 * @param iOwner     Player who owns the box.
 * @param iAmount    Cleers inside. The box's skin shows the amount's unit.
 * @param fOrigin    Where the box appears.
 * @param bTakeMoney Whether the cleers come out of the owner's balance.
 * @return           The box, or -1.
 */
native int Cel_CreateCleerBox(int iOwner, int iAmount, const float fOrigin[3], bool bTakeMoney = false);

/**
 * Cleers inside a cleers box, or 0 when the entity is not one.
 */
native int Cel_GetCleerBoxAmount(int iEntity);

/**
 * Subtracts one from the Cel entity count for a client.
 *
 * @param iClient  The client index.
 */
native void Cel_SubFromCelCount(int iClient);

native void Cel_SubFromClientBalance(int iClient, int iBalance);

/**
 * Subtracts one from the prop count for a client.
 *
 * @param iClient  The client index.
 */
native void Cel_SubFromPropCount(int iClient);

native void Cel_TeleportInfrontOfClient(int iClient, int iEntity, float fAdd = 0.0);

native void Cel_TriggerEntity(int iClient, int iEntity);

//Stocks:
stock void Cel_ActivateEffect(int iEntity)
{
	//An effect without its attached entity (gone, or a broken copy) has nothing to switch.
	if (Cel_GetEffectAttachment(iEntity) <= MaxClients)
	{
		return;
	}
	
	switch(Cel_GetEffectType(iEntity))
	{
		case EFFECT_CORE:
		{
			SetVariantFloat(0.0);
			AcceptEntityInput(Cel_GetEffectAttachment(iEntity), Cel_IsEffectActive(iEntity) ? "StartDischarge" : "StartCharge");
		}
		case EFFECT_EXPLOSION:
		{
			AcceptEntityInput(Cel_GetEffectAttachment(iEntity), "Explode");
		}
		case EFFECT_FIRE:
		{
			SetVariantFloat(0.0);
			AcceptEntityInput(Cel_GetEffectAttachment(iEntity), Cel_IsEffectActive(iEntity) ? "StartFire" : "ExtinguishTemporary");
		}
		case EFFECT_SHAKE:
		{
			AcceptEntityInput(Cel_GetEffectAttachment(iEntity), "StartShake");
		}
		case EFFECT_SMOKESTACK:
		{
			AcceptEntityInput(Cel_GetEffectAttachment(iEntity), Cel_IsEffectActive(iEntity) ? "TurnOn" : "TurnOff");
		}
		case EFFECT_SPOTLIGHT:
		{
			AcceptEntityInput(Cel_GetEffectAttachment(iEntity), Cel_IsEffectActive(iEntity) ? "LightOn" : "LightOff");
		}
		case EFFECT_STEAM:
		{
			AcceptEntityInput(Cel_GetEffectAttachment(iEntity), Cel_IsEffectActive(iEntity) ? "TurnOn" : "TurnOff");
		}
	}
	
	Cel_SetEffectActive(iEntity, !Cel_IsEffectActive(iEntity));
}

/**
 * Special things that keep their own look and can't be copied: emblems, hats, celweps, cleers boxes, and finds such as
 * the hobo. They can still be moved, frozen or deleted by their owner.
 */
stock bool Cel_IsSpecialEntity(int iEntity)
{
	if (iEntity <= 0 || !IsValidEntity(iEntity))
	{
		return false;
	}
	
	EntityType etType = Cel_GetEntityType(iEntity);
	
	if (etType == ENTTYPE_CLEER || etType == ENTTYPE_EMBLEM || etType == ENTTYPE_HAT || etType == ENTTYPE_CELWEP)
	{
		return true;
	}
	
	char sName[64];
	
	Cel_GetPropName(iEntity, sName, sizeof(sName));
	
	return StrEqual(sName, "hobo", false);
}

// Entity slots kept free for the game itself (weapons, gibs, projectiles, NPCs): running out of them crashes the
// server, so player spawns stop this far from the limit (cm_edict_reserve).
// A short amount of money: 999, 1.5K, 250K, 20M, 1.2B (like the website). One decimal, dropped when it is .0.
stock void Cel_ShortCleers(int iAmount, char[] sBuffer, int iMaxLength)
{
	static const float fSizes[] = { 1000000000.0, 1000000.0, 1000.0 };
	static const char sSuffixes[][] = { "B", "M", "K" };
	
	float fAmount = float(iAmount), fAbs = FloatAbs(fAmount);
	
	for (int i = 0; i < sizeof(fSizes); i++)
	{
		if (fAbs >= fSizes[i])
		{
			// Rounded down to one decimal, so 1,999,999 never shows as 2M.
			float fValue = float(RoundToFloor(fAbs / fSizes[i] * 10.0)) / 10.0;
			
			if (fValue == float(RoundToFloor(fValue)))
			{
				FormatEx(sBuffer, iMaxLength, "%s%d%s", iAmount < 0 ? "-" : "", RoundToFloor(fValue), sSuffixes[i]);
			} else {
				FormatEx(sBuffer, iMaxLength, "%s%.1f%s", iAmount < 0 ? "-" : "", fValue, sSuffixes[i]);
			}
			
			return;
		}
	}
	
	IntToString(iAmount, sBuffer, iMaxLength);
}

// Cyclers (cel_doll): NPC models that change animation when shot (+use pauses / plays them). Their animation,
// frame and paused state are what a build saves and a copy keeps, for scenes.
stock bool Cel_IsCycler(int iEntity)
{
	char sClass[32];
	
	return (iEntity > MaxClients && IsValidEntity(iEntity) && GetEntityClassname(iEntity, sClass, sizeof(sClass)) && StrEqual(sClass, "cel_doll", false));
}

stock void Cel_GetCyclerAnim(int iEntity, int &iSequence, float &fCycle, bool &bPaused)
{
	iSequence = GetEntProp(iEntity, Prop_Send, "m_nSequence");
	fCycle = GetEntPropFloat(iEntity, Prop_Data, "m_flCycle");
	bPaused = HasEntProp(iEntity, Prop_Data, "m_animate") ? (GetEntProp(iEntity, Prop_Data, "m_animate") == 0) : false;
}

stock void Cel_SetCyclerAnim(int iEntity, int iSequence, float fCycle, bool bPaused)
{
	char sSequence[16];
	
	// The cycler's own SetSequence input (it only works while playing).
	if (HasEntProp(iEntity, Prop_Data, "m_animate"))
	{
		SetEntProp(iEntity, Prop_Data, "m_animate", 1);
	}
	
	SetEntPropFloat(iEntity, Prop_Data, "m_flPlaybackRate", 1.0);
	
	IntToString(iSequence, sSequence, sizeof(sSequence));
	SetVariantString(sSequence);
	AcceptEntityInput(iEntity, "SetSequence");
	
	SetEntPropFloat(iEntity, Prop_Data, "m_flCycle", fCycle);
	
	if (bPaused)
	{
		if (HasEntProp(iEntity, Prop_Data, "m_animate"))
		{
			SetEntProp(iEntity, Prop_Data, "m_animate", 0);
		}
		
		SetEntPropFloat(iEntity, Prop_Data, "m_flPlaybackRate", 0.0);
	}
}

// Refuses a move, turn or delete on a perm prop, with a message. Returns true when refused.
stock bool Cel_RefusePerm(int iClient, int iEntity)
{
	if (iEntity <= MaxClients || GetFeatureStatus(FeatureType_Native, "Cel_IsPerm") != FeatureStatus_Available || !Cel_IsPerm(iEntity))
	{
		return false;
	}
	
	Cel_ReplyToCommand(iClient, "That prop is {green}perm{default}: it can't be moved, turned or deleted. Type {green}[tag]unperm{default} while looking at it first.");
	
	return true;
}

// The other player whose land a spot is in, when iClient may not build there (0 = fine). The spot is tested a little
// above too: a land's box starts at the height of the corner its owner aimed at, and the ground can dip below that.
stock int Cel_OtherLandAt(int iClient, const float fPos[3])
{
	float fTest[3];
	static const float fHeights[] = { 0.0, 16.0, 48.0 };
	
	for (int h = 0; h < sizeof(fHeights); h++)
	{
		fTest = fPos;
		fTest[2] += fHeights[h];
		
		int iOwner = Cel_GetLandOwnerFromPosition(fTest);
		
		if (iOwner > 0 && iOwner <= MaxClients && iOwner != iClient && IsClientInGame(iOwner) && Cel_IsLandCreated(iOwner)
			&& !Cel_IsOnBuildTeam(iOwner, iClient) && !Cel_ZoneExempt(iClient))
		{
			return iOwner;
		}
	}
	
	return 0;
}

stock int Cel_EdictReserve()
{
	ConVar cvReserve = FindConVar("cm_edict_reserve");
	
	return (cvReserve != null) ? cvReserve.IntValue : 256;
}

stock bool Cel_EdictsLow(int iExtra = 1)
{
	return (GetEntityCount() + iExtra > GetMaxEntities() - Cel_EdictReserve());
}

// True when a model that isn't precached yet can't be: the model precache table is (nearly) full, and
// overflowing it shuts the server down.
stock bool Cel_ModelTableFull(const char[] sModel)
{
	if (IsModelPrecached(sModel))
	{
		return false;
	}
	
	int iTable = FindStringTable("modelprecache");
	
	if (iTable == INVALID_STRING_TABLE)
	{
		return false;
	}
	
	return (GetStringTableNumStrings(iTable) >= GetStringTableMaxStrings(iTable) - 32);
}

/** Says so and returns true when the entity is special (see Cel_IsSpecialEntity). */
stock bool Cel_RefuseSpecial(int iClient, int iEntity)
{
	if (!Cel_IsSpecialEntity(iEntity))
	{
		return false;
	}
	
	Cel_ReplyToCommand(iClient, "Emblems, hats, celweps, cleers boxes and other special items keep their own look and can't be copied.");
	
	return true;
}

#define CEL_MONEYBOX_MODEL "models/celmod/cleers.mdl"

/**
 * The model for a money box: CelMod's cleers box, or a plain box when the server does not have it.
 */
stock void Cel_GetMoneyBoxModel(char[] sModel, int iMaxLength)
{
	strcopy(sModel, iMaxLength, Cel_IsPhysicsModelComplete(CEL_MONEYBOX_MODEL) ? CEL_MONEYBOX_MODEL : "models/props_lab/box01a.mdl");
}

/**
 * Whether a model can be used as a physics prop: the .mdl alone draws nothing and has no collision,
 * it also needs its .vvd, .dx90.vtx and .phy files.
 */
stock bool Cel_IsPhysicsModelComplete(const char[] sModel)
{
	char sBase[PLATFORM_MAX_PATH], sFile[PLATFORM_MAX_PATH];
	
	//Searching the game's files (and every VPK) is slow, and loading a build asks for the same models again and
	//again: models found complete are remembered. (Missing ones are looked for again, in case they're added.)
	static StringMap smComplete = null;
	bool bDummy;
	
	if (smComplete == null)
	{
		smComplete = new StringMap();
	}
	
	if (smComplete.GetValue(sModel, bDummy))
	{
		return true;
	}

	if (!FileExists(sModel, true))
	{
		return false;
	}

	strcopy(sBase, sizeof(sBase), sModel);

	int iDot = FindCharInString(sBase, '.', true);

	if (iDot != -1)
	{
		sBase[iDot] = '\0';
	}

	Format(sFile, sizeof(sFile), "%s.vvd", sBase);

	if (!FileExists(sFile, true))
	{
		return false;
	}

	Format(sFile, sizeof(sFile), "%s.dx90.vtx", sBase);

	if (!FileExists(sFile, true))
	{
		return false;
	}

	Format(sFile, sizeof(sFile), "%s.phy", sBase);

	if (!FileExists(sFile, true))
	{
		return false;
	}
	
	smComplete.SetValue(sModel, true);
	
	return true;
}

/**
 * The money box skin for an amount. The cleers box's 7 skins are labelled with the amount's unit:
 * CL (under a thousand), K (thousands), M (millions), B (billions), T, QD and QN.
 */
stock int Cel_GetMoneyBoxSkin(int iAmount)
{
	if (iAmount >= 1000000000)
	{
		return 3;
	}
	else if (iAmount >= 1000000)
	{
		return 2;
	}
	else if (iAmount >= 1000)
	{
		return 1;
	}

	return 0;
}

/**
 * Adds a custom model to the downloads table: its .mdl, .vvd, .vtx and .phy files, and every material it uses
 * (read from the model's texture list) with the textures those materials name. Only files that are on the
 * server's own disk are added, so stock models add nothing.
 */
stock void Cel_AddModelDownloads(const char[] sModel)
{
	static const char sExtensions[][] = { ".mdl", ".vvd", ".phy", ".dx80.vtx", ".dx90.vtx", ".sw.vtx", ".vtx" };
	char sBase[PLATFORM_MAX_PATH], sFile[PLATFORM_MAX_PATH];
	
	if (!FileExists(sModel, false))
	{
		return;
	}
	
	PrecacheModel(sModel, true);
	
	strcopy(sBase, sizeof(sBase), sModel);
	
	int iDot = FindCharInString(sBase, '.', true);
	
	if (iDot != -1)
	{
		sBase[iDot] = '\0';
	}
	
	for (int i = 0; i < sizeof(sExtensions); i++)
	{
		Format(sFile, sizeof(sFile), "%s%s", sBase, sExtensions[i]);
		
		if (FileExists(sFile, false))
		{
			AddFileToDownloadsTable(sFile);
		}
	}
	
	//The model's texture names and the folders they are looked for in.
	File fModel = OpenFile(sModel, "rb");
	
	if (fModel == null)
	{
		return;
	}
	
	int iTextures = Cel_ReadIntAt(fModel, 204), iTextureIndex = Cel_ReadIntAt(fModel, 208);
	int iFolders = Cel_ReadIntAt(fModel, 212), iFolderIndex = Cel_ReadIntAt(fModel, 216);
	
	if (iTextures < 0 || iTextures > 64 || iFolders < 0 || iFolders > 16)
	{
		delete fModel;
		return;
	}
	
	char sTexture[64][PLATFORM_MAX_PATH], sFolder[16][PLATFORM_MAX_PATH];
	
	for (int i = 0; i < iTextures; i++)
	{
		int iEntry = iTextureIndex + i * 64;
		
		Cel_ReadStringAt(fModel, iEntry + Cel_ReadIntAt(fModel, iEntry), sTexture[i], sizeof(sTexture[]));
	}
	
	for (int i = 0; i < iFolders; i++)
	{
		Cel_ReadStringAt(fModel, Cel_ReadIntAt(fModel, iFolderIndex + i * 4), sFolder[i], sizeof(sFolder[]));
	}
	
	delete fModel;
	
	for (int t = 0; t < iTextures; t++)
	{
		for (int f = 0; f < iFolders; f++)
		{
			Format(sFile, sizeof(sFile), "materials/%s%s.vmt", sFolder[f], sTexture[t]);
			ReplaceString(sFile, sizeof(sFile), "\\", "/");
			
			if (FileExists(sFile, false))
			{
				AddFileToDownloadsTable(sFile);
				Cel_AddMaterialTextures(sFile);
				break;
			}
		}
	}
}

//The .vtf textures a material names ($basetexture, $bumpmap, ...).
stock void Cel_AddMaterialTextures(const char[] sMaterial)
{
	char sLine[256], sKey[64], sValue[PLATFORM_MAX_PATH], sFile[PLATFORM_MAX_PATH];
	
	File fMaterial = OpenFile(sMaterial, "r");
	
	if (fMaterial == null)
	{
		return;
	}
	
	while (fMaterial.ReadLine(sLine, sizeof(sLine)))
	{
		TrimString(sLine);
		
		int iPos = BreakString(sLine, sKey, sizeof(sKey));
		
		if (iPos == -1 || sKey[0] != '$')
		{
			continue;
		}
		
		BreakString(sLine[iPos], sValue, sizeof(sValue));
		
		if (sValue[0] == '\0' || StrContains(sValue, "_rt_") == 0)
		{
			continue;
		}
		
		Format(sFile, sizeof(sFile), "materials/%s.vtf", sValue);
		ReplaceString(sFile, sizeof(sFile), "\\", "/");
		ReplaceString(sFile, sizeof(sFile), ".vtf.vtf", ".vtf");
		
		if (FileExists(sFile, false))
		{
			AddFileToDownloadsTable(sFile);
		}
	}
	
	delete fMaterial;
}

stock int Cel_ReadIntAt(File fFile, int iOffset)
{
	int iValue = 0;
	
	if (!fFile.Seek(iOffset, SEEK_SET) || !fFile.ReadInt32(iValue))
	{
		return -1;
	}
	
	return iValue;
}

stock void Cel_ReadStringAt(File fFile, int iOffset, char[] sOut, int iMaxLength)
{
	sOut[0] = '\0';
	
	if (iOffset <= 0 || !fFile.Seek(iOffset, SEEK_SET))
	{
		return;
	}
	
	fFile.ReadString(sOut, iMaxLength, -1);
}

public bool Cel_FilterWorldOnly(int iEntity, int iContentsMask, any aData)
{
	return (iEntity == 0);
}

/**
 * Finds a random open spot somewhere in the playable part of the map.
 *
 * The search covers the area around the map's spawn points (widened a long way, so it reaches the whole map but
 * not the 3D skybox), and keeps the space a box of the given size needs clear of walls, props and water.
 *
 * @param bOnFloor    True: standing on flat ground. False: floating in the air somewhere above the ground.
 * @param fHalfWidth  Half the width of the box that must fit.
 * @param fHeight     Height of the box that must fit.
 * @param fSpot       The spot found: the middle of the box's floor.
 * @param fAvoid      A place the spot must stay away from (another booth), with fAvoidRadius.
 * @param fMaxAir     For spots in the air: the most it can be above the ground.
 * @param fReach      How far past the spawn points to look. A huge value searches the whole map.
 * @return            True if a spot was found.
 */
stock bool Cel_FindRandomMapSpot(bool bOnFloor, float fHalfWidth, float fHeight, float fSpot[3], const float fAvoid[3] = NULL_VECTOR, float fAvoidRadius = 0.0, float fMaxAir = 480.0, float fReach = 4000.0)
{
	static const char sSpawns[][] = { "info_player_deathmatch", "info_player_combine", "info_player_rebel", "info_player_start" };
	float fCamera[3], fGround[3], fMax[3], fMin[3], fOrigin[3], fTry[3];
	bool bAny = false, bCamera = false;
	int iEntity;

	for (int i = 0; i < sizeof(sSpawns); i++)
	{
		iEntity = -1;

		while ((iEntity = FindEntityByClassname(iEntity, sSpawns[i])) != -1)
		{
			GetEntPropVector(iEntity, Prop_Data, "m_vecAbsOrigin", fOrigin);

			for (int k = 0; k < 3; k++)
			{
				if (!bAny || fOrigin[k] < fMin[k]) fMin[k] = fOrigin[k];
				if (!bAny || fOrigin[k] > fMax[k]) fMax[k] = fOrigin[k];
			}

			bAny = true;
		}
	}

	if (!bAny)
	{
		return false;
	}

	//The whole map, as far as it reaches from where players play, but kept inside the world.
	float fWorldMin[3], fWorldMax[3];

	GetEntPropVector(0, Prop_Data, "m_WorldMins", fWorldMin);
	GetEntPropVector(0, Prop_Data, "m_WorldMaxs", fWorldMax);

	for (int k = 0; k < 2; k++)
	{
		fMin[k] -= fReach;
		fMax[k] += fReach;
	}

	fMin[2] -= (fReach > 4000.0) ? fReach : 768.0;
	fMax[2] += (fReach > 4000.0) ? fReach : 2048.0;

	for (int k = 0; k < 3; k++)
	{
		if (fMin[k] < fWorldMin[k]) fMin[k] = fWorldMin[k];
		if (fMax[k] > fWorldMax[k]) fMax[k] = fWorldMax[k];
	}

	//The 3D skybox is a small room of real map somewhere off to the side; nothing goes in it.
	iEntity = FindEntityByClassname(-1, "sky_camera");

	if (iEntity != -1)
	{
		GetEntPropVector(iEntity, Prop_Data, "m_vecAbsOrigin", fCamera);

		bCamera = true;
	}

	float fBoxMin[3], fBoxMax[3];

	fBoxMin[0] = -fHalfWidth;
	fBoxMin[1] = -fHalfWidth;
	fBoxMin[2] = 4.0;
	fBoxMax[0] = fHalfWidth;
	fBoxMax[1] = fHalfWidth;
	fBoxMax[2] = fHeight;

	for (int iTry = 0; iTry < 400; iTry++)
	{
		for (int k = 0; k < 3; k++)
		{
			fTry[k] = GetRandomFloat(fMin[k], fMax[k]);
		}

		if (bCamera && GetVectorDistance(fTry, fCamera) < 2500.0)
		{
			continue;
		}
		
		if (fAvoidRadius > 0.0 && GetVectorDistance(fTry, fAvoid) < fAvoidRadius)
		{
			continue;
		}

		if (TR_PointOutsideWorld(fTry) || (TR_GetPointContents(fTry) & (MASK_SOLID | MASK_WATER)))
		{
			continue;
		}

		//Drop straight down to the ground; the ground has to be the map itself, not a prop or the sky.
		float fDown[3];

		fDown = fTry;
		fDown[2] -= 16384.0;

		Handle hTrace = TR_TraceRayFilterEx(fTry, fDown, MASK_PLAYERSOLID, RayType_EndPoint, Cel_FilterWorldOnly, 0);

		if (!TR_DidHit(hTrace) || (TR_GetSurfaceFlags(hTrace) & (SURF_SKY | SURF_SKY2D)))
		{
			CloseHandle(hTrace);
			continue;
		}

		float fNormal[3];

		TR_GetEndPosition(fGround, hTrace);
		TR_GetPlaneNormal(hTrace, fNormal);

		CloseHandle(hTrace);

		if (fNormal[2] < 0.7)
		{
			continue;
		}

		fSpot = fGround;

		if (!bOnFloor)
		{
			//Somewhere in the air above that ground, under whatever is overhead.
			float fUp[3], fCeiling[3];

			fUp = fGround;
			fUp[2] += 4096.0;

			hTrace = TR_TraceRayFilterEx(fGround, fUp, MASK_PLAYERSOLID, RayType_EndPoint, Cel_FilterWorldOnly, 0);

			fCeiling = fUp;

			if (TR_DidHit(hTrace))
			{
				TR_GetEndPosition(fCeiling, hTrace);
			}

			CloseHandle(hTrace);

			float fRoom = fCeiling[2] - fGround[2] - fHeight - 16.0;

			if (fRoom < 64.0)
			{
				continue;
			}

			fSpot[2] = fGround[2] + GetRandomFloat(64.0, (fRoom < fMaxAir) ? fRoom : fMaxAir);
		} else {
			//A flat floor: the ground under every corner is about as high as the middle.
			bool bFlat = true;

			for (int c = 0; c < 4 && bFlat; c++)
			{
				float fCorner[3], fCornerDown[3];

				fCorner[0] = fGround[0] + ((c & 1) ? fHalfWidth : -fHalfWidth);
				fCorner[1] = fGround[1] + ((c & 2) ? fHalfWidth : -fHalfWidth);
				fCorner[2] = fGround[2] + 32.0;

				fCornerDown = fCorner;
				fCornerDown[2] -= 64.0;

				hTrace = TR_TraceRayFilterEx(fCorner, fCornerDown, MASK_PLAYERSOLID, RayType_EndPoint, Cel_FilterWorldOnly, 0);

				if (!TR_DidHit(hTrace))
				{
					bFlat = false;
				} else {
					float fHit[3];

					TR_GetEndPosition(fHit, hTrace);

					bFlat = (FloatAbs(fHit[2] - fGround[2]) <= 24.0);
				}

				CloseHandle(hTrace);
			}

			if (!bFlat)
			{
				continue;
			}

			float fAbove[3];

			fAbove = fGround;
			fAbove[2] += 16.0;

			if (TR_GetPointContents(fAbove) & MASK_WATER)
			{
				continue;
			}
		}

		//The box has to fit there without touching anything, the map or props.
		hTrace = TR_TraceHullEx(fSpot, fSpot, fBoxMin, fBoxMax, MASK_PLAYERSOLID);

		bool bBlocked = TR_DidHit(hTrace);

		CloseHandle(hTrace);

		if (!bBlocked)
		{
			return true;
		}
	}

	return false;
}

public bool Cel_FilterPlayer(int iEntity, int iContentsMask, any aData)
{
	return (iEntity != aData && iEntity > MaxClients);
}

stock void Cel_FixSpawnPosition(int iEntity, float fOrigin[3])
{
	float fMins[3];
	
	GetEntPropVector(iEntity, Prop_Send, "m_vecMinsPreScaled", fMins);
	
	fOrigin[2] = fOrigin[2] - fMins[2];
	
	TeleportEntity(iEntity, fOrigin, NULL_VECTOR, NULL_VECTOR);
}

/**
 * Retrieves the angles of an entity.
 *
 * @param iEntity  The entity index.
 * @param fAngles  The output array storing the entity angles.
 */
stock void Cel_GetEntityAngles(int iEntity, float fAngles[3])
{
	// The entity's own rotation is always current. The cached world rotation (m_angAbsRotation) is only brought
	// up to date when the engine next needs it, so right after a prop is turned it can still hold the old angles
	// (stacked copies and saved builds then came out rotated wrong). A welded prop's own rotation is relative to
	// what it is welded to, so for it the world rotation is the right one.
	if (HasEntProp(iEntity, Prop_Data, "m_hMoveParent") && GetEntPropEnt(iEntity, Prop_Data, "m_hMoveParent") != -1)
	{
		GetEntPropVector(iEntity, Prop_Data, "m_angAbsRotation", fAngles);
	} else {
		GetEntPropVector(iEntity, Prop_Data, "m_angRotation", fAngles);
	}
}

/**
 * Retrieves the origin position of an entity.
 *
 * @param iEntity   The entity index.
 * @param fOrigin   The output array storing the entity origin.
 */
stock void Cel_GetEntityOrigin(int iEntity, float fOrigin[3])
{
	GetEntPropVector(iEntity, Prop_Send, "m_vecOrigin", fOrigin);
}

stock void HSVtoRGB(float fH, float fS, float fV, int iRGB[3])
{
	fH -= 360.0 * RoundToFloor(fH / 360.0);
	
	int iSeg = RoundToFloor(fH / 60.0) % 6;
	float fFrac = (fH / 60.0) - iSeg;
	
	float fP = fV * (1.0 - fS);
	float fQ = fV * (1.0 - fFrac * fS);
	float fT = fV * (1.0 - (1.0 - fFrac) * fS);
	
	float fR, fG, fB;
	
	switch (iSeg)
	{
		case 0: { fR = fV; fG = fT; fB = fP; }
		case 1: { fR = fQ; fG = fV; fB = fP; }
		case 2: { fR = fP; fG = fV; fB = fT; }
		case 3: { fR = fP; fG = fQ; fB = fV; }
		case 4: { fR = fT; fG = fP; fB = fV; }
		default:{ fR = fV; fG = fP; fB = fQ; }
	}
	
	iRGB[0] = RoundToFloor(fR * 255.0);
	iRGB[1] = RoundToFloor(fG * 255.0);
	iRGB[2] = RoundToFloor(fB * 255.0);
}

stock void RGBtoHSV(int iR8, int iG8, int iB8, float &fH, float &fS, float &fV)
{
	float fR = iR8 / 255.0;
	float fG = iG8 / 255.0;
	float fB = iB8 / 255.0;
	
	float fCMax = fR;
	if (fG > fCMax) fCMax = fG;
	if (fB > fCMax) fCMax = fB;
	
	float fCMin = fR;
	if (fG < fCMin) fCMin = fG;
	if (fB < fCMin) fCMin = fB;
	
	float fDelta = fCMax - fCMin;
	
	if (fDelta == 0.0)
	{
		fH = 0.0;
	}
	else if (fCMax == fR)
	{
		fH = 60.0 * ((fG - fB) / fDelta);
		if (fH < 0.0) fH += 360.0;
	}
	else if (fCMax == fG)
	{
		fH = 60.0 * (((fB - fR) / fDelta) + 2.0);
	}
	else
	{
		fH = 60.0 * (((fR - fG) / fDelta) + 4.0);
	}
	
	fS = (fCMax == 0.0) ? 0.0 : (fDelta / fCMax);
	fV = fCMax;
}

//Hooks:
public void Hook_EffectUse(int iEntity, int iActivator, int iCaller, UseType utType, float fValue)
{
	if(!Cel_IsLocked(iEntity))
	{
		Cel_ActivateEffect(iEntity);
	}
}

public void Hook_InternetUse(int iEntity, int iActivator, int iCaller, UseType utType, float fValue)
{
	char sURL[PLATFORM_MAX_PATH];
	
	Cel_GetInternetURL(iEntity, sURL, sizeof(sURL));
	
	if(!Cel_IsLocked(iEntity))
	{
		Cel_OpenMOTDOnClient(iActivator, true, "|CelMod| Viewer", sURL, MOTDPANEL_TYPE_URL);
	}
}

//Timers:
public Action Timer_DelayRemove(Handle hTimer, any iRef)
{
	int iEntity = EntRefToEntIndex(iRef);
	
	if (iEntity != INVALID_ENT_REFERENCE && iEntity > MaxClients)
	{
		AcceptEntityInput(iEntity, "kill");
	}
	
	return Plugin_Continue;
}

public Action Timer_DisRemove(Handle hTimer, any iRef)
{
	int iEntity = EntRefToEntIndex(iRef);
	
	if (iEntity != INVALID_ENT_REFERENCE && iEntity > MaxClients)
	{
		Cel_DissolveEntity(iEntity);
	}
	
	return Plugin_Continue;
}