#pragma semicolon 1

#include <celmod>
#include <geoip>

#pragma newdecls required
#pragma dynamic 262144 // collectibles.txt is sent to the website whole

/*
 * |CelMod| Database
 *
 * Mirrors live server data into a shared MySQL database so the |CelMod|
 * website can show realtime analytics, player profiles and leaderboards,
 * and delivers orders placed in the website shop.
 *
 * The game server stays authoritative: balances and purchases still live in
 * data/celmod/users/<steamid>/ and this plugin only copies them out. Web shop
 * orders are re-checked (price, balance, already owned) in-game before the
 * player is charged.
 *
 * Setup: add a "celmod" entry to addons/sourcemod/configs/databases.cfg that
 * points at the same database as the website's config.php. Tables are
 * created automatically.
 */

#define SCHEMA_QUERIES 20
#define MIGRATION_QUERIES 14

Database g_dbCelMod;

bool g_bConnecting;
bool g_bMapLogged;
bool g_bTracked[MAXPLAYERS + 1];
bool g_bPurchasesSynced[MAXPLAYERS + 1];

char g_sMap[64];
char g_sSteamID[MAXPLAYERS + 1][32];

ArrayList g_alShopItems;

ConVar g_cvAddress;
ConVar g_cvConfig;
ConVar g_cvHeartbeat;
ConVar g_cvOrderPoll;
ConVar g_cvSample;
ConVar g_cvServerID;

Handle g_hHeartbeatTimer;
Handle g_hOrderTimer;
Handle g_hSampleTimer;

int g_iJoinTime[MAXPLAYERS + 1];
int g_iPlayMark[MAXPLAYERS + 1];
int g_iMapStart;
int g_iPendingCels[MAXPLAYERS + 1];
int g_iPendingEffects[MAXPLAYERS + 1];
int g_iPendingProps[MAXPLAYERS + 1];
int g_iPendingRemoved[MAXPLAYERS + 1];
int g_iDayCels;
int g_iDayEffects;
int g_iDayProps;
int g_iSessionID[MAXPLAYERS + 1];
int g_iTick;

StringMap g_smRecentlyLeft;

//Announcements from the website's admin panel (cm_announcements), checked every cm_db_announce_poll seconds.
#define MAX_ANNOUNCEMENTS 32
int g_iAnnounceCount;
int g_iAnnounceID[MAX_ANNOUNCEMENTS];
int g_iAnnounceRepeat[MAX_ANNOUNCEMENTS];
bool g_bAnnounceOnJoin[MAX_ANNOUNCEMENTS];
char g_sAnnounce[MAX_ANNOUNCEMENTS][256];

//Rotation (admin panel, Announcements tab): every few minutes one of the announcements, in a shuffled order that
//goes through the whole list before any is shown again.
int g_iRotateMinutes;
float g_fLastRotate;
int g_iRotateBag[MAX_ANNOUNCEMENTS];
int g_iRotateBagCount;
int g_iRotateLastID;

//!reportbug: one report a minute per player.
float g_fLastBugReport[MAXPLAYERS + 1];

//!dispute: pick the player causing problems, then what they're doing (or "Other", typed in chat).
static const char g_sDisputeReasons[][] =
{
	"Wrecking or stealing my build", "Blocking my land or spawn", "Spamming props or effects", "Harassing or spamming chat",
	"Killing me over and over", "Lagging or crashing the server", "Other (type it in chat)"
};
float g_fLastDispute[MAXPLAYERS + 1];
int g_iDisputeTarget[MAXPLAYERS + 1]; // userid of the player picked
bool g_bDisputeTyping[MAXPLAYERS + 1]; // waiting for the "Other" text in chat

//Dispute demos: a SourceTV recording on the server from the moment of the dispute (needs tv_enable 1).
ConVar g_cvDisputeDemo;
ConVar g_cvDisputeDemoSeconds;
bool g_bDisputeRecording;
char g_sDisputeDemo[128];
Handle g_hDisputeDemoStop;
StringMap g_smAnnounceShown;
ConVar g_cvAnnouncePoll;
Handle g_hAnnounceTimer;

char g_sSchema[SCHEMA_QUERIES][] = {
	"CREATE TABLE IF NOT EXISTS cm_players (steamid64 VARCHAR(20) NOT NULL, name VARCHAR(128) NOT NULL DEFAULT '', avatar_url VARCHAR(255) NOT NULL DEFAULT '', balance BIGINT NOT NULL DEFAULT 0, playtime_seconds INT UNSIGNED NOT NULL DEFAULT 0, connections INT UNSIGNED NOT NULL DEFAULT 0, props_spawned INT UNSIGNED NOT NULL DEFAULT 0, cels_spawned INT UNSIGNED NOT NULL DEFAULT 0, effects_spawned INT UNSIGNED NOT NULL DEFAULT 0, entities_removed INT UNSIGNED NOT NULL DEFAULT 0, is_online TINYINT(1) NOT NULL DEFAULT 0, first_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, last_seen DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (steamid64), KEY idx_balance (balance), KEY idx_playtime (playtime_seconds), KEY idx_props (props_spawned)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_purchases (steamid64 VARCHAR(20) NOT NULL, item VARCHAR(64) NOT NULL, source VARCHAR(8) NOT NULL DEFAULT 'game', purchased_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (steamid64, item)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_shop_items (item VARCHAR(64) NOT NULL, display_name VARCHAR(64) NOT NULL DEFAULT '', price INT UNSIGNED NOT NULL DEFAULT 0, category VARCHAR(32) NOT NULL DEFAULT 'Commands', kind VARCHAR(16) NOT NULL DEFAULT 'command', target VARCHAR(64) NOT NULL DEFAULT '', description VARCHAR(255) NOT NULL DEFAULT '', stock_left INT NULL, repeatable TINYINT(1) NOT NULL DEFAULT 0, sort_order INT NOT NULL DEFAULT 0, enabled TINYINT(1) NOT NULL DEFAULT 1, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (item)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_web_orders (id INT UNSIGNED NOT NULL AUTO_INCREMENT, steamid64 VARCHAR(20) NOT NULL, item VARCHAR(64) NOT NULL, price INT UNSIGNED NOT NULL, status VARCHAR(12) NOT NULL DEFAULT 'pending', message VARCHAR(255) NOT NULL DEFAULT '', server_id INT NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, processed_at DATETIME NULL, PRIMARY KEY (id), KEY idx_status_player (status, steamid64)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_servers (server_id INT NOT NULL, hostname VARCHAR(128) NOT NULL DEFAULT '', address VARCHAR(64) NOT NULL DEFAULT '', map VARCHAR(64) NOT NULL DEFAULT '', players INT NOT NULL DEFAULT 0, max_players INT NOT NULL DEFAULT 0, total_props INT NOT NULL DEFAULT 0, total_cels INT NOT NULL DEFAULT 0, version VARCHAR(16) NOT NULL DEFAULT '', map_started DATETIME NULL, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (server_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_online_players (server_id INT NOT NULL, steamid64 VARCHAR(20) NOT NULL, name VARCHAR(128) NOT NULL DEFAULT '', props INT NOT NULL DEFAULT 0, cels INT NOT NULL DEFAULT 0, balance BIGINT NOT NULL DEFAULT 0, joined_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (server_id, steamid64)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_sessions (id INT UNSIGNED NOT NULL AUTO_INCREMENT, steamid64 VARCHAR(20) NOT NULL, server_id INT NOT NULL, map VARCHAR(64) NOT NULL DEFAULT '', started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, ended_at DATETIME NULL, PRIMARY KEY (id), KEY idx_player (steamid64), KEY idx_started (started_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_events (id INT UNSIGNED NOT NULL AUTO_INCREMENT, server_id INT NOT NULL, steamid64 VARCHAR(20) NULL, name VARCHAR(128) NOT NULL DEFAULT '', type VARCHAR(16) NOT NULL, detail VARCHAR(255) NOT NULL DEFAULT '', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_created (created_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_stats_daily (day DATE NOT NULL, server_id INT NOT NULL, connections INT UNSIGNED NOT NULL DEFAULT 0, peak_players INT UNSIGNED NOT NULL DEFAULT 0, props_spawned INT UNSIGNED NOT NULL DEFAULT 0, cels_spawned INT UNSIGNED NOT NULL DEFAULT 0, effects_spawned INT UNSIGNED NOT NULL DEFAULT 0, PRIMARY KEY (day, server_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_player_samples (server_id INT NOT NULL, recorded_at DATETIME NOT NULL, players INT NOT NULL, PRIMARY KEY (server_id, recorded_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_emblem_suggestions (id INT UNSIGNED NOT NULL AUTO_INCREMENT, steamid64 VARCHAR(20) NOT NULL, player_name VARCHAR(128) NOT NULL DEFAULT '', emblem_id VARCHAR(64) NOT NULL, title VARCHAR(64) NOT NULL DEFAULT '', kv TEXT NOT NULL, note VARCHAR(500) NOT NULL DEFAULT '', status VARCHAR(12) NOT NULL DEFAULT 'pending', admin_note VARCHAR(255) NOT NULL DEFAULT '', reviewed_by VARCHAR(20) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, reviewed_at DATETIME NULL, PRIMARY KEY (id), KEY idx_status (status), KEY idx_player (steamid64)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_maps (map VARCHAR(64) NOT NULL, times_played INT UNSIGNED NOT NULL DEFAULT 0, last_played DATETIME NULL, PRIMARY KEY (map)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_announcements (id INT UNSIGNED NOT NULL AUTO_INCREMENT, message VARCHAR(255) NOT NULL, server_id INT NULL, repeat_minutes INT UNSIGNED NOT NULL DEFAULT 0, show_on_join TINYINT(1) NOT NULL DEFAULT 0, active TINYINT(1) NOT NULL DEFAULT 1, starts_at DATETIME NULL, ends_at DATETIME NULL, created_by VARCHAR(20) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_active (active)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_updates (id INT UNSIGNED NOT NULL AUTO_INCREMENT, posted_on DATE NOT NULL, body TEXT NOT NULL, published TINYINT(1) NOT NULL DEFAULT 1, created_by VARCHAR(20) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_posted (posted_on)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_disputes (id INT UNSIGNED NOT NULL AUTO_INCREMENT, server_id INT NULL, steamid64 VARCHAR(20) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', target_steamid64 VARCHAR(20) NOT NULL DEFAULT '', target_name VARCHAR(64) NOT NULL DEFAULT '', map VARCHAR(64) NOT NULL DEFAULT '', reason VARCHAR(64) NOT NULL DEFAULT '', message VARCHAR(255) NOT NULL DEFAULT '', demo VARCHAR(128) NOT NULL DEFAULT '', status ENUM('open','resolved','closed') NOT NULL DEFAULT 'open', admin_note VARCHAR(255) NOT NULL DEFAULT '', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_status (status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_bug_reports (id INT UNSIGNED NOT NULL AUTO_INCREMENT, server_id INT NULL, steamid64 VARCHAR(20) NOT NULL, name VARCHAR(64) NOT NULL DEFAULT '', map VARCHAR(64) NOT NULL DEFAULT '', pos_x FLOAT NOT NULL DEFAULT 0, pos_y FLOAT NOT NULL DEFAULT 0, pos_z FLOAT NOT NULL DEFAULT 0, message VARCHAR(255) NOT NULL, status ENUM('open','fixed','closed') NOT NULL DEFAULT 'open', admin_note VARCHAR(255) NOT NULL DEFAULT '', created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_status (status)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_collectibles (server_id INT NOT NULL, content MEDIUMTEXT NOT NULL, file_hash INT NOT NULL DEFAULT 0, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (server_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_drop_pool (emblem_id VARCHAR(64) NOT NULL, droppable TINYINT(1) NOT NULL DEFAULT 1, updated_by VARCHAR(20) NULL, updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (emblem_id)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_drop_schedule (id INT UNSIGNED NOT NULL AUTO_INCREMENT, run_at DATETIME NOT NULL, boxes INT NOT NULL DEFAULT 5, repeat_minutes INT UNSIGNED NOT NULL DEFAULT 0, server_id INT NULL, active TINYINT(1) NOT NULL DEFAULT 1, last_run DATETIME NULL, note VARCHAR(128) NOT NULL DEFAULT '', created_by VARCHAR(20) NULL, created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (id), KEY idx_due (active, run_at)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
	"CREATE TABLE IF NOT EXISTS cm_site_settings (name VARCHAR(64) NOT NULL, value VARCHAR(255) NOT NULL DEFAULT '', updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (name)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"
};

// Columns added after the first release. Run one by one; "duplicate column" (1060) means already done.
char g_sMigrations[MIGRATION_QUERIES][] = {
	"ALTER TABLE cm_disputes ADD COLUMN demo VARCHAR(128) NOT NULL DEFAULT '' AFTER message",
	"ALTER TABLE cm_shop_items ADD COLUMN kind VARCHAR(16) NOT NULL DEFAULT 'command' AFTER category",
	"ALTER TABLE cm_shop_items ADD COLUMN target VARCHAR(64) NOT NULL DEFAULT '' AFTER kind",
	"ALTER TABLE cm_shop_items ADD COLUMN description VARCHAR(255) NOT NULL DEFAULT '' AFTER target",
	"ALTER TABLE cm_shop_items ADD COLUMN stock_left INT NULL AFTER description",
	"ALTER TABLE cm_shop_items ADD COLUMN repeatable TINYINT(1) NOT NULL DEFAULT 0 AFTER stock_left",
	"ALTER TABLE cm_shop_items ADD COLUMN sort_order INT NOT NULL DEFAULT 0 AFTER repeatable",
	"ALTER TABLE cm_players ADD COLUMN land_bans INT UNSIGNED NOT NULL DEFAULT 0",
	"ALTER TABLE cm_players ADD COLUMN kills INT UNSIGNED NOT NULL DEFAULT 0",
	"ALTER TABLE cm_players ADD COLUMN deaths INT UNSIGNED NOT NULL DEFAULT 0",
	"ALTER TABLE cm_players ADD COLUMN enemy_kills INT UNSIGNED NOT NULL DEFAULT 0",
	"ALTER TABLE cm_players ADD COLUMN presents_given INT UNSIGNED NOT NULL DEFAULT 0",
	"ALTER TABLE cm_players ADD COLUMN emblems_owned INT UNSIGNED NOT NULL DEFAULT 0",
	"ALTER TABLE cm_players ADD COLUMN props_given INT UNSIGNED NOT NULL DEFAULT 0"
};

//Leaderboard stats other plugins report with Cel_AddPlayerStat / Cel_SetPlayerStat (columns in cm_players).
//Counted up, except emblems_owned, a total that is replaced. props_given: props and cels handed over with !give.
#define PLAYER_STATS 7
char g_sStatColumn[PLAYER_STATS][] = { "land_bans", "kills", "deaths", "enemy_kills", "presents_given", "emblems_owned", "props_given" };
bool g_bStatAbsolute[PLAYER_STATS] = { false, false, false, false, false, true, false };
int g_iPendingStat[MAXPLAYERS + 1][PLAYER_STATS];
bool g_bStatChanged[MAXPLAYERS + 1][PLAYER_STATS];

public Plugin myinfo =
{
	name = "|CelMod| Database",
	author = CEL_AUTHOR,
	description = "Shares live server data with the |CelMod| website and delivers web shop orders.",
	version = CEL_VERSION,
	url = CEL_URL
};

public void OnPluginStart()
{

	g_alShopItems = new ArrayList(ByteCountToCells(64));
	g_smRecentlyLeft = new StringMap();
	g_smAnnounceShown = new StringMap();

	g_cvConfig = CreateConVar("cm_db_config", "celmod", "Name of the databases.cfg entry shared with the website.");
	g_cvServerID = CreateConVar("cm_db_server_id", "1", "Unique ID for this server in the shared database (match the website config).", _, true, 1.0);
	g_cvAddress = CreateConVar("cm_db_address", "", "Public ip:port shown on the website. Leave empty to detect it.");
	g_cvHeartbeat = CreateConVar("cm_db_heartbeat", "15.0", "Seconds between live status updates.", _, true, 5.0);
	g_cvOrderPoll = CreateConVar("cm_db_order_poll", "5.0", "Seconds between checks for new web shop orders.", _, true, 2.0);
	g_cvAnnouncePoll = CreateConVar("cm_db_announce_poll", "30.0", "Seconds between checks for announcements made on the website.", _, true, 10.0);
	g_cvSample = CreateConVar("cm_db_sample", "300.0", "Seconds between player count samples for the activity chart.", _, true, 60.0);

	AutoExecConfig(true, "celmod.database");

	HookEvent("player_disconnect", Event_PlayerDisconnect, EventHookMode_Pre);
	HookEvent("player_death", Event_StatsPlayerDeath);

	g_cvDisputeDemo = CreateConVar("cm_dispute_demo", "1", "1: !dispute records a SourceTV demo on the server (needs tv_enable 1), with the reported player's details in it.", _, true, 0.0, true, 1.0);
	g_cvDisputeDemoSeconds = CreateConVar("cm_dispute_demo_seconds", "180", "How long a dispute demo records, in seconds. Another dispute while recording makes it longer.", _, true, 30.0, true, 1800.0);
	RegConsoleCmd("v_news", Command_News, "|CelMod| Shows what's new: the latest updates posted on the website.");
	RegConsoleCmd("v_dispute", Command_Dispute, "|CelMod| Reports a player who is causing you problems to the admins.");
	RegAdminCmd("v_disputes", Command_Disputes, ADMFLAG_GENERIC, "|CelMod| Admins: lists the open disputes; pick one to read it and mark it resolved or closed. !disputes all includes finished ones.");
	AddCommandListener(Listener_DisputeChat, "say");
	AddCommandListener(Listener_DisputeChat, "say_team");
	RegConsoleCmd("v_reportbug", Command_ReportBug, "|CelMod| Reports a bug or glitch to the admins: !reportbug <what happened>.");
	RegAdminCmd("cm_db_status", Command_DBStatus, ADMFLAG_ROOT, "|CelMod| Shows the shared database connection status.");
}

public void OnConfigsExecuted()
{
	if (g_dbCelMod == null && !g_bConnecting)
	{
		ConnectDatabase();
	}

	RestartTimers();
}

public void OnMapStart()
{
	GetCurrentMap(g_sMap, sizeof(g_sMap));
	g_iMapStart = GetTime();
	g_bMapLogged = false;

	if (g_dbCelMod != null)
	{
		LogMapStart();
		SyncShopItems();
		SyncCollectibles();
	}
}

//The website reads the emblems from here (Emblem Drops tab, Emblem Editor), so it always has this server's
//collectibles.txt. Sent when it has changed since the last time, checked every map.
int g_iCollectiblesHash = 0;

void SyncCollectibles()
{
	char sPath[PLATFORM_MAX_PATH];

	BuildPath(Path_SM, sPath, sizeof(sPath), "data/celmod/collectibles.txt");

	int iSize = FileSize(sPath);

	if (iSize < 1 || iSize > 400000)
	{
		return;
	}

	File fFile = OpenFile(sPath, "rb");

	if (fFile == null)
	{
		return;
	}

	char[] sText = new char[iSize + 1];
	int iRead = fFile.ReadString(sText, iSize + 1, iSize);

	delete fFile;

	if (iRead < 1)
	{
		return;
	}

	sText[iRead] = '\0';

	// A simple hash (djb2), so an unchanged file isn't sent again.
	int iHash = 5381;

	for (int i = 0; i < iRead; i++)
	{
		iHash = ((iHash << 5) + iHash) + sText[i];
	}

	if (iHash == g_iCollectiblesHash)
	{
		return;
	}

	int iEscapedSize = iRead * 2 + 1;
	char[] sEscaped = new char[iEscapedSize];

	if (!g_dbCelMod.Escape(sText, sEscaped, iEscapedSize))
	{
		return;
	}

	int iQuerySize = iEscapedSize + 256;
	char[] sQuery = new char[iQuerySize];

	FormatEx(sQuery, iQuerySize, "INSERT INTO cm_collectibles (server_id, content, file_hash) VALUES (%d, '%s', %d) ON DUPLICATE KEY UPDATE content = VALUES(content), file_hash = VALUES(file_hash), updated_at = NOW()", g_cvServerID.IntValue, sEscaped, iHash);

	g_dbCelMod.Query(SQL_OnCollectiblesSynced, sQuery, iHash);
}

public void SQL_OnCollectiblesSynced(Database dbDatabase, DBResultSet rsResults, const char[] sError, any iHash)
{
	if (rsResults == null)
	{
		LogError("|CelMod| Couldn't send collectibles.txt to the website: %s", sError);
		return;
	}

	g_iCollectiblesHash = iHash;
}

public void OnMapEnd()
{
	FlushDailyStats(0);

	// The map change ends a SourceTV recording on its own.
	delete g_hDisputeDemoStop;
	g_bDisputeRecording = false;
}

void RestartTimers()
{
	delete g_hHeartbeatTimer;
	delete g_hOrderTimer;
	delete g_hSampleTimer;
	delete g_hAnnounceTimer;

	g_hHeartbeatTimer = CreateTimer(g_cvHeartbeat.FloatValue, Timer_Heartbeat, _, TIMER_REPEAT);
	g_hOrderTimer = CreateTimer(g_cvOrderPoll.FloatValue, Timer_PollOrders, _, TIMER_REPEAT);
	g_hSampleTimer = CreateTimer(g_cvSample.FloatValue, Timer_Sample, _, TIMER_REPEAT);
	g_hAnnounceTimer = CreateTimer(g_cvAnnouncePoll.FloatValue, Timer_PollAnnouncements, _, TIMER_REPEAT);
}

//Announcements:
public Action Timer_PollAnnouncements(Handle hTimer)
{
	char sQuery[512];

	if (g_dbCelMod == null)
	{
		return Plugin_Continue;
	}

	FormatEx(sQuery, sizeof(sQuery), "SELECT id, message, repeat_minutes, show_on_join, UNIX_TIMESTAMP() - UNIX_TIMESTAMP(created_at) FROM cm_announcements WHERE active = 1 AND (starts_at IS NULL OR starts_at <= NOW()) AND (ends_at IS NULL OR ends_at > NOW()) AND (server_id IS NULL OR server_id = %d) ORDER BY id LIMIT %d", g_cvServerID.IntValue, MAX_ANNOUNCEMENTS);

	g_dbCelMod.Query(SQL_OnRotateSetting, "SELECT value FROM cm_site_settings WHERE name = 'announce_rotation'");
	g_dbCelMod.Query(SQL_OnAnnouncements, sQuery);

	PollEmblemDrops();

	return Plugin_Continue;
}

//Emblem drops from the website's admin panel (Emblem Drops tab): which emblems can drop, and scheduled drops.
void PollEmblemDrops()
{
	char sQuery[2600];

	if (GetFeatureStatus(FeatureType_Native, "Cel_StartEmblemDrop") != FeatureStatus_Available)
	{
		return;
	}

	g_dbCelMod.Query(SQL_OnDropPool, "SELECT emblem_id, droppable FROM cm_drop_pool");
	g_dbCelMod.Query(SQL_OnGiftList, "SELECT value FROM cm_site_settings WHERE name = 'gift_list'");

	// The website shows the server's own list (cm_emblem_gift_list) as the default for build emblems.
	static char sLastDefault[1024] = "\x01";
	char sDefault[1024], sEscaped[2100];
	ConVar cvGiftList = FindConVar("cm_emblem_gift_list");

	if (cvGiftList != null)
	{
		cvGiftList.GetString(sDefault, sizeof(sDefault));

		if (!StrEqual(sDefault, sLastDefault) && g_dbCelMod.Escape(sDefault, sEscaped, sizeof(sEscaped)))
		{
			strcopy(sLastDefault, sizeof(sLastDefault), sDefault);

			FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_site_settings (name, value) VALUES ('gift_list_default', '%s') ON DUPLICATE KEY UPDATE value = VALUES(value), updated_at = NOW()", sEscaped);
			g_dbCelMod.Query(SQL_Generic, sQuery);
		}
	}

	FormatEx(sQuery, sizeof(sQuery), "SELECT id, boxes FROM cm_drop_schedule WHERE active = 1 AND run_at <= NOW() AND (server_id IS NULL OR server_id = %d) ORDER BY run_at LIMIT 5", g_cvServerID.IntValue);
	g_dbCelMod.Query(SQL_OnDueDrops, sQuery);
}

public void SQL_OnDropPool(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aData)
{
	char sId[64];

	if (rsResults == null)
	{
		return; // the table isn't there yet
	}

	// Back to collectibles.txt first, so an admin's choice that was taken away is undone too.
	Cel_ResetEmblemDroppable();

	while (rsResults.FetchRow())
	{
		rsResults.FetchString(0, sId, sizeof(sId));
		Cel_SetEmblemDroppable(sId, rsResults.FetchInt(1) == 1);
	}
}

public void SQL_OnGiftList(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aData)
{
	char sList[2048];

	if (rsResults == null)
	{
		return;
	}

	if (rsResults.FetchRow())
	{
		rsResults.FetchString(0, sList, sizeof(sList));
	}

	Cel_SetEmblemGiftList(sList);
}

public void SQL_OnDueDrops(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aData)
{
	char sQuery[512];

	if (rsResults == null)
	{
		return;
	}

	while (rsResults.FetchRow())
	{
		int iId = rsResults.FetchInt(0), iBoxes = rsResults.FetchInt(1);

		// Claimed first (moved on to its next time, or finished), so two servers never both run the same drop.
		FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_drop_schedule SET last_run = NOW(), active = IF(repeat_minutes > 0, 1, 0), run_at = IF(repeat_minutes > 0, GREATEST(NOW(), run_at) + INTERVAL repeat_minutes MINUTE, run_at) WHERE id = %d AND active = 1 AND run_at <= NOW()", iId);

		g_dbCelMod.Query(SQL_OnClaimDrop, sQuery, iBoxes);
	}
}

public void SQL_OnClaimDrop(Database dbDatabase, DBResultSet rsResults, const char[] sError, any iBoxes)
{
	if (rsResults == null || rsResults.AffectedRows < 1)
	{
		return;
	}

	int iFell = Cel_StartEmblemDrop(iBoxes);

	if (iFell < 1)
	{
		LogMessage("|CelMod| A scheduled emblem drop was due, but no boxes could fall (it needs a living player under open sky).");
	}
}

public void SQL_OnAnnouncements(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aData)
{
	char sKey[16];
	float fLast;

	if (rsResults == null)
	{
		LogError("|CelMod| Could not read announcements: %s", sError);
		return;
	}

	g_iAnnounceCount = 0;

	while (rsResults.FetchRow() && g_iAnnounceCount < MAX_ANNOUNCEMENTS)
	{
		int i = g_iAnnounceCount++;

		g_iAnnounceID[i] = rsResults.FetchInt(0);
		rsResults.FetchString(1, g_sAnnounce[i], sizeof(g_sAnnounce[]));
		g_iAnnounceRepeat[i] = rsResults.FetchInt(2);
		g_bAnnounceOnJoin[i] = (rsResults.FetchInt(3) == 1);

		int iAge = rsResults.FetchInt(4);

		Format(sKey, sizeof(sKey), "a%d", g_iAnnounceID[i]);

		bool bSeen = g_smAnnounceShown.GetValue(sKey, fLast);

		//New on the website (or just started): everyone sees it now. Ones this server has not seen yet but
		//that are old (e.g. after a restart) only show again when their repeat comes round.
		if (!bSeen)
		{
			if (iAge < 600 || g_iAnnounceRepeat[i] > 0)
			{
				Announce(i);
			}

			g_smAnnounceShown.SetValue(sKey, GetEngineTime());
			continue;
		}

		if (g_iAnnounceRepeat[i] > 0 && GetEngineTime() - fLast >= g_iAnnounceRepeat[i] * 60.0)
		{
			Announce(i);

			g_smAnnounceShown.SetValue(sKey, GetEngineTime());
		}
	}

	RotateAnnouncements();
}

//!reportbug <what happened>: saved for the admins (the website's admin panel, Bug Reports tab) with where the
//player was standing. Without the database it goes to data/celmod/bugreports.txt so it's never lost.
public Action Command_ReportBug(int iClient, int iArgs)
{
	char sMessage[256], sName[64], sEscMessage[520], sEscName[136], sEscMap[136], sQuery[1200];
	float fPos[3];

	if (iClient < 1 || !IsClientInGame(iClient))
	{
		return Plugin_Handled;
	}

	GetCmdArgString(sMessage, sizeof(sMessage));
	StripQuotes(sMessage);
	TrimString(sMessage);

	if (strlen(sMessage) < 8)
	{
		Cel_ReplyToCommand(iClient, "Found a bug or glitch? Say {green}!reportbug <what happened>{default}, e.g. {green}!reportbug my door cel won't open{default}.");
		return Plugin_Handled;
	}

	if (g_fLastBugReport[iClient] > 0.0 && GetEngineTime() - g_fLastBugReport[iClient] < 60.0)
	{
		Cel_ReplyToCommand(iClient, "Thanks! Please wait a minute before sending another bug report.");
		return Plugin_Handled;
	}

	g_fLastBugReport[iClient] = GetEngineTime();

	GetClientName(iClient, sName, sizeof(sName));
	GetClientAbsOrigin(iClient, fPos);

	if (g_dbCelMod != null && g_sSteamID[iClient][0] != '\0' && g_dbCelMod.Escape(sMessage, sEscMessage, sizeof(sEscMessage)) && g_dbCelMod.Escape(sName, sEscName, sizeof(sEscName)) && g_dbCelMod.Escape(g_sMap, sEscMap, sizeof(sEscMap)))
	{
		FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_bug_reports (server_id, steamid64, name, map, pos_x, pos_y, pos_z, message) VALUES (%d, '%s', '%s', '%s', %.1f, %.1f, %.1f, '%s')", g_cvServerID.IntValue, g_sSteamID[iClient], sEscName, sEscMap, fPos[0], fPos[1], fPos[2], sEscMessage);

		g_dbCelMod.Query(SQL_Generic, sQuery);
	}

	char sPath[PLATFORM_MAX_PATH], sSteam[32];

	BuildPath(Path_SM, sPath, sizeof(sPath), "data/celmod/bugreports.txt");

	if (!GetClientAuthId(iClient, AuthId_Steam2, sSteam, sizeof(sSteam)))
	{
		strcopy(sSteam, sizeof(sSteam), "unknown");
	}

	LogToFileEx(sPath, "%N <%s> on %s at %.0f %.0f %.0f: %s", iClient, sSteam, g_sMap, fPos[0], fPos[1], fPos[2], sMessage);

	// Admins on the server hear about it right away.
	for (int i = 1; i <= MaxClients; i++)
	{
		if (i != iClient && IsClientInGame(i) && !IsFakeClient(i) && CheckCommandAccess(i, "cm_bugreports_notify", ADMFLAG_GENERIC))
		{
			Cel_PrintToChat(i, "Bug report from {green}%N{default}: %s", iClient, sMessage);
		}
	}

	Cel_ReplyToCommand(iClient, "Thanks! Your bug report was sent to the admins.");

	return Plugin_Handled;
}

public void SQL_OnRotateSetting(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aData)
{
	int iMinutes = 0;

	if (rsResults != null && rsResults.FetchRow())
	{
		char sValue[16];

		rsResults.FetchString(0, sValue, sizeof(sValue));
		iMinutes = StringToInt(sValue);
	}

	// Just switched on (or changed): the first one comes after a full interval, not at once.
	if (iMinutes != g_iRotateMinutes)
	{
		g_fLastRotate = GetEngineTime();
	}

	g_iRotateMinutes = iMinutes;
}

// Called after each refresh of the list: shows the next announcement in the rotation when it's due.
void RotateAnnouncements()
{
	if (g_iRotateMinutes < 1 || g_iAnnounceCount < 1 || GetEngineTime() - g_fLastRotate < g_iRotateMinutes * 60.0)
	{
		return;
	}

	for (int iTries = 0; iTries < 2; iTries++)
	{
		// The bag is empty: a new shuffled round of every announcement, not starting with the one just shown.
		if (g_iRotateBagCount < 1)
		{
			for (int i = 0; i < g_iAnnounceCount; i++)
			{
				g_iRotateBag[i] = g_iAnnounceID[i];
			}

			g_iRotateBagCount = g_iAnnounceCount;

			for (int i = g_iRotateBagCount - 1; i > 0; i--)
			{
				int j = GetRandomInt(0, i), iSwap = g_iRotateBag[i];

				g_iRotateBag[i] = g_iRotateBag[j];
				g_iRotateBag[j] = iSwap;
			}

			if (g_iRotateBagCount > 1 && g_iRotateBag[g_iRotateBagCount - 1] == g_iRotateLastID)
			{
				int iSwap = g_iRotateBag[0];

				g_iRotateBag[0] = g_iRotateBag[g_iRotateBagCount - 1];
				g_iRotateBag[g_iRotateBagCount - 1] = iSwap;
			}
		}

		// The next one still on the list (one deleted or paused on the website since is skipped).
		while (g_iRotateBagCount > 0)
		{
			int iID = g_iRotateBag[--g_iRotateBagCount];

			for (int i = 0; i < g_iAnnounceCount; i++)
			{
				if (g_iAnnounceID[i] == iID)
				{
					Announce(i);

					g_iRotateLastID = iID;
					g_fLastRotate = GetEngineTime();
					return;
				}
			}
		}
	}
}

void Announce(int iIndex)
{
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && !IsFakeClient(i))
		{
			// Announcements from the website say |CM|, not |CelMod|.
			CPrintToChat(i, "{blue}|CM|{default} %s", g_sAnnounce[iIndex]);
		}
	}
}

//Players joining see the announcements marked "show on join".
public Action Timer_JoinAnnouncements(Handle hTimer, any iUserID)
{
	char sKey[16];
	int iClient = GetClientOfUserId(iUserID);

	if (iClient < 1 || !IsClientInGame(iClient))
	{
		return Plugin_Stop;
	}

	//Once per visit, not again at every map change (a player keeps their user id across map changes).
	IntToString(iUserID, sKey, sizeof(sKey));

	if (!g_smAnnounceShown.SetValue(sKey, 0.0, false))
	{
		return Plugin_Stop;
	}

	for (int i = 0; i < g_iAnnounceCount; i++)
	{
		if (g_bAnnounceOnJoin[i])
		{
			CPrintToChat(iClient, "{blue}|CM|{default} %s", g_sAnnounce[i]);
		}
	}

	return Plugin_Stop;
}

//Connection:
void ConnectDatabase()
{
	char sConfig[64];

	g_cvConfig.GetString(sConfig, sizeof(sConfig));

	if (!SQL_CheckConfig(sConfig))
	{
		LogError("|CelMod| No \"%s\" entry in databases.cfg, website sync is disabled.", sConfig);
		return;
	}

	g_bConnecting = true;

	Database.Connect(SQL_OnConnect, sConfig);
}

public void SQL_OnConnect(Database dbDatabase, const char[] sError, any aData)
{
	g_bConnecting = false;

	if (dbDatabase == null)
	{
		LogError("|CelMod| Could not connect to the shared database: %s (retrying in 30s)", sError);
		CreateTimer(30.0, Timer_Reconnect);
		return;
	}

	char sDriver[16];
	dbDatabase.Driver.GetIdentifier(sDriver, sizeof(sDriver));

	if (!StrEqual(sDriver, "mysql"))
	{
		LogError("|CelMod| The shared database must be MySQL/MariaDB (got \"%s\"), website sync is disabled.", sDriver);
		delete dbDatabase;
		return;
	}

	g_dbCelMod = dbDatabase;
	g_dbCelMod.SetCharset("utf8mb4");

	Transaction txSchema = new Transaction();

	for (int i = 0; i < SCHEMA_QUERIES; i++)
	{
		txSchema.AddQuery(g_sSchema[i]);
	}

	g_dbCelMod.Execute(txSchema, SQL_OnSchemaReady, SQL_OnTxnError);
}

public void SQL_OnSchemaReady(Database dbDatabase, any aData, int iNumQueries, DBResultSet[] rsResults, any[] aQueryData)
{
	char sQuery[256];

	PrintToServer("|CelMod| Connected to the shared website database.");

	for (int i = 0; i < MIGRATION_QUERIES; i++)
	{
		g_dbCelMod.Query(SQL_OnMigration, g_sMigrations[i], _, DBPrio_High);
	}

	// Orders that were mid-delivery when this server last stopped go back in the queue.
	// Re-delivering is safe: an item the player already owns is never charged twice.
	FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_web_orders SET status = 'pending' WHERE status = 'processing' AND server_id = %d", g_cvServerID.IntValue);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	SyncShopItems();
	SyncCollectibles();
	LogMapStart();

	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && !IsFakeClient(i) && !g_bTracked[i])
		{
			TrackClient(i, true);
		}
	}

	Timer_Heartbeat(null);
}

public Action Timer_Reconnect(Handle hTimer)
{
	if (g_dbCelMod == null && !g_bConnecting)
	{
		ConnectDatabase();
	}

	return Plugin_Stop;
}

public Action Command_DBStatus(int iClient, int iArgs)
{
	ReplyToCommand(iClient, "|CelMod| Shared database: %s (server id %d, %d shop items synced)", g_dbCelMod != null ? "connected" : "not connected", g_cvServerID.IntValue, g_alShopItems.Length);

	return Plugin_Handled;
}

//Shop:
/**
 * Copies the shop catalog (celmod-shop: commands, rare props, player models, emblems, hats) to
 * cm_shop_items, including how many are left. Runs on connect, each map and about once a minute.
 */
void SyncShopItems()
{
	char sCategory[32], sDescription[128], sEscCategory[65], sEscDescription[257], sEscName[129], sEscTarget[129];
	char sKey[64], sName[64], sQuery[1536], sStock[16], sTarget[64], sType[16];
	int iLeft, iPrice;
	bool bRepeatable;

	if (g_dbCelMod == null)
	{
		return;
	}

	g_alShopItems.Clear();

	Transaction txShop = new Transaction();
	txShop.AddQuery("UPDATE cm_shop_items SET enabled = 0");

	for (int i = 0; i < Cel_ShopGetItemCount(); i++)
	{
		if (!Cel_ShopGetItem(i, sKey, sizeof(sKey), sName, sizeof(sName), sCategory, sizeof(sCategory), sDescription, sizeof(sDescription), iPrice, iLeft, bRepeatable)
			|| !Cel_ShopGetItemType(i, sType, sizeof(sType), sTarget, sizeof(sTarget))
			|| !IsSafeKey(sKey) || !IsSafeKey(sType))
		{
			continue;
		}

		if (!bRepeatable)
		{
			g_alShopItems.PushString(sKey);
		}

		g_dbCelMod.Escape(sName, sEscName, sizeof(sEscName));
		g_dbCelMod.Escape(sCategory, sEscCategory, sizeof(sEscCategory));
		g_dbCelMod.Escape(sDescription, sEscDescription, sizeof(sEscDescription));
		g_dbCelMod.Escape(sTarget, sEscTarget, sizeof(sEscTarget));

		if (iLeft < 0)
		{
			strcopy(sStock, sizeof(sStock), "NULL");
		} else {
			IntToString(iLeft, sStock, sizeof(sStock));
		}

		FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_shop_items (item, display_name, price, category, kind, target, description, stock_left, repeatable, sort_order, enabled, updated_at) VALUES ('%s', '%s', %d, '%s', '%s', '%s', '%s', %s, %d, %d, 1, NOW()) ON DUPLICATE KEY UPDATE display_name = VALUES(display_name), price = VALUES(price), category = VALUES(category), kind = VALUES(kind), target = VALUES(target), description = VALUES(description), stock_left = VALUES(stock_left), repeatable = VALUES(repeatable), sort_order = VALUES(sort_order), enabled = 1, updated_at = NOW()",
			sKey, sEscName, iPrice, sEscCategory, sType, sEscTarget, sEscDescription, sStock, bRepeatable ? 1 : 0, i);
		txShop.AddQuery(sQuery);
	}

	g_dbCelMod.Execute(txShop, SQL_OnTxnOk, SQL_OnTxnError);
}

/** Shop keys and categories go into SQL unescaped, so only allow [A-Za-z0-9_-]. */
bool IsSafeKey(const char[] sKey)
{
	int iLen = strlen(sKey);

	if (iLen == 0)
	{
		return false;
	}

	for (int i = 0; i < iLen; i++)
	{
		if (!IsCharAlpha(sKey[i]) && !IsCharNumeric(sKey[i]) && sKey[i] != '_' && sKey[i] != '-')
		{
			return false;
		}
	}

	return true;
}

//Clients:
public void OnClientPostAdminCheck(int iClient)
{
	if (IsFakeClient(iClient))
	{
		return;
	}

	// Give the economy plugin a moment to load the player's balance.
	CreateTimer(3.0, Timer_TrackClient, GetClientUserId(iClient));
	CreateTimer(15.0, Timer_JoinAnnouncements, GetClientUserId(iClient), TIMER_FLAG_NO_MAPCHANGE);
}

public Action Timer_TrackClient(Handle hTimer, int iUserID)
{
	int iClient = GetClientOfUserId(iUserID);

	if (iClient != 0 && IsClientInGame(iClient) && !g_bTracked[iClient])
	{
		TrackClient(iClient, false);
	}

	return Plugin_Stop;
}

void TrackClient(int iClient, bool bLate)
{
	char sEscName[257], sName[128], sQuery[768];

	if (g_dbCelMod == null || !GetClientAuthId(iClient, AuthId_SteamID64, g_sSteamID[iClient], sizeof(g_sSteamID[])))
	{
		return;
	}

	g_bTracked[iClient] = true;
	g_bPurchasesSynced[iClient] = false;
	g_iJoinTime[iClient] = GetTime();
	g_iPlayMark[iClient] = g_iJoinTime[iClient];
	g_iPendingProps[iClient] = 0;
	g_iPendingCels[iClient] = 0;
	g_iPendingEffects[iClient] = 0;
	g_iPendingRemoved[iClient] = 0;

	for (int i = 0; i < PLAYER_STATS; i++)
	{
		g_iPendingStat[iClient][i] = 0;
		g_bStatChanged[iClient][i] = false;
	}

	GetClientName(iClient, sName, sizeof(sName));
	g_dbCelMod.Escape(sName, sEscName, sizeof(sEscName));

	// A rejoin right after a map change is the same visit, not a new connection.
	int iLeftAt;
	bool bReturning = bLate || (g_smRecentlyLeft.GetValue(g_sSteamID[iClient], iLeftAt) && GetTime() - iLeftAt < 300);
	g_smRecentlyLeft.Remove(g_sSteamID[iClient]);

	FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_players (steamid64, name, balance, connections, is_online, first_seen, last_seen) VALUES ('%s', '%s', %d, 1, 1, NOW(), NOW()) ON DUPLICATE KEY UPDATE name = VALUES(name), balance = VALUES(balance), connections = connections + %d, is_online = 1, last_seen = NOW()", g_sSteamID[iClient], sEscName, Cel_GetClientBalance(iClient), bReturning ? 0 : 1);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_sessions (steamid64, server_id, map) VALUES ('%s', %d, '%s')", g_sSteamID[iClient], g_cvServerID.IntValue, g_sMap);
	g_dbCelMod.Query(SQL_OnSessionCreated, sQuery, GetClientUserId(iClient));

	if (!bReturning)
	{
		LogEvent(iClient, "connect", "");

		FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_stats_daily (day, server_id, connections) VALUES (CURDATE(), %d, 1) ON DUPLICATE KEY UPDATE connections = connections + 1", g_cvServerID.IntValue);
		g_dbCelMod.Query(SQL_Generic, sQuery);
	}

	SyncClientPurchases(iClient);
}

public void SQL_OnSessionCreated(Database dbDatabase, DBResultSet rsResults, const char[] sError, int iUserID)
{
	if (rsResults == null)
	{
		LogError("|CelMod| Database error: %s", sError);
		return;
	}

	int iClient = GetClientOfUserId(iUserID);

	if (iClient != 0)
	{
		g_iSessionID[iClient] = rsResults.InsertId;
	}
}

/** Runs on every disconnect, including map changes. */
public void OnClientDisconnect(int iClient)
{
	g_fLastBugReport[iClient] = 0.0;
	g_fLastDispute[iClient] = 0.0;
	g_bDisputeTyping[iClient] = false;
	g_iDisputeTarget[iClient] = 0;

	char sQuery[512];

	if (!g_bTracked[iClient])
	{
		return;
	}

	g_bTracked[iClient] = false;

	if (g_dbCelMod == null)
	{
		return;
	}

	FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_players SET balance = %d, last_seen = NOW(), playtime_seconds = playtime_seconds + %d, props_spawned = props_spawned + %d, cels_spawned = cels_spawned + %d, effects_spawned = effects_spawned + %d, entities_removed = entities_removed + %d WHERE steamid64 = '%s'", Cel_GetClientBalance(iClient), GetTime() - g_iPlayMark[iClient], g_iPendingProps[iClient], g_iPendingCels[iClient], g_iPendingEffects[iClient], g_iPendingRemoved[iClient], g_sSteamID[iClient]);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	FlushPlayerStats(iClient, null);

	if (g_iSessionID[iClient] > 0)
	{
		FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_sessions SET ended_at = NOW() WHERE id = %d", g_iSessionID[iClient]);
		g_dbCelMod.Query(SQL_Generic, sQuery);
		g_iSessionID[iClient] = 0;
	}

	g_smRecentlyLeft.SetValue(g_sSteamID[iClient], GetTime());
}

/** Only fires when a player really leaves (not on map change). */
public Action Event_PlayerDisconnect(Event eEvent, const char[] sName, bool bDontBroadcast)
{
	char sQuery[256], sSteamID[32];
	int iClient = GetClientOfUserId(eEvent.GetInt("userid"));

	if (iClient == 0 || IsFakeClient(iClient) || g_dbCelMod == null || !GetClientAuthId(iClient, AuthId_SteamID64, sSteamID, sizeof(sSteamID), false))
	{
		return Plugin_Continue;
	}

	LogEvent(iClient, "disconnect", "");

	FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_players SET is_online = 0 WHERE steamid64 = '%s'", sSteamID);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	FormatEx(sQuery, sizeof(sQuery), "DELETE FROM cm_online_players WHERE server_id = %d AND steamid64 = '%s'", g_cvServerID.IntValue, sSteamID);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	g_smRecentlyLeft.Remove(sSteamID);

	return Plugin_Continue;
}

void SyncClientPurchases(int iClient)
{
	char sItem[64], sQuery[256];

	for (int i = 0; i < g_alShopItems.Length; i++)
	{
		g_alShopItems.GetString(i, sItem, sizeof(sItem));

		if (Cel_ShopOwnsItem(iClient, sItem))
		{
			FormatEx(sQuery, sizeof(sQuery), "INSERT IGNORE INTO cm_purchases (steamid64, item, source) VALUES ('%s', '%s', 'game')", g_sSteamID[iClient], sItem);

			DataPack dpPurchase = new DataPack();
			dpPurchase.WriteCell(GetClientUserId(iClient));
			dpPurchase.WriteCell(g_bPurchasesSynced[iClient]);
			dpPurchase.WriteString(sItem);

			g_dbCelMod.Query(SQL_OnPurchaseSynced, sQuery, dpPurchase);
		}
	}

	g_bPurchasesSynced[iClient] = true;
}

public void SQL_OnPurchaseSynced(Database dbDatabase, DBResultSet rsResults, const char[] sError, DataPack dpPurchase)
{
	char sItem[64];

	dpPurchase.Reset();
	int iClient = GetClientOfUserId(dpPurchase.ReadCell());
	bool bAnnounce = view_as<bool>(dpPurchase.ReadCell());
	dpPurchase.ReadString(sItem, sizeof(sItem));
	delete dpPurchase;

	if (rsResults == null)
	{
		LogError("|CelMod| Database error: %s", sError);
		return;
	}

	// A brand new row after the first sync means they just bought it in-game.
	if (bAnnounce && iClient != 0 && rsResults.AffectedRows == 1)
	{
		LogEvent(iClient, "purchase", sItem);
	}
}

//Live data:
public Action Timer_Heartbeat(Handle hTimer)
{
	char sAddress[64], sEscHost[257], sEscName[257], sHostname[128], sName[128], sQuery[1536];
	int iPlayers, iTotalCels, iTotalProps;

	if (g_dbCelMod == null)
	{
		return Plugin_Continue;
	}

	int iServerID = g_cvServerID.IntValue;

	Transaction txBeat = new Transaction();

	FormatEx(sQuery, sizeof(sQuery), "DELETE FROM cm_online_players WHERE server_id = %d", iServerID);
	txBeat.AddQuery(sQuery);

	for (int i = 1; i <= MaxClients; i++)
	{
		if (!IsClientInGame(i) || IsFakeClient(i))
		{
			continue;
		}

		iPlayers++;
		iTotalProps += Cel_GetPropCount(i);
		iTotalCels += Cel_GetCelCount(i);

		if (!g_bTracked[i])
		{
			continue;
		}

		GetClientName(i, sName, sizeof(sName));
		g_dbCelMod.Escape(sName, sEscName, sizeof(sEscName));

		FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_online_players (server_id, steamid64, name, props, cels, balance, joined_at) VALUES (%d, '%s', '%s', %d, %d, %d, FROM_UNIXTIME(%d))", iServerID, g_sSteamID[i], sEscName, Cel_GetPropCount(i), Cel_GetCelCount(i), Cel_GetClientBalance(i), g_iJoinTime[i]);
		txBeat.AddQuery(sQuery);

		FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_players SET name = '%s', balance = %d, is_online = 1, last_seen = NOW(), playtime_seconds = playtime_seconds + %d, props_spawned = props_spawned + %d, cels_spawned = cels_spawned + %d, effects_spawned = effects_spawned + %d, entities_removed = entities_removed + %d WHERE steamid64 = '%s'", sEscName, Cel_GetClientBalance(i), GetTime() - g_iPlayMark[i], g_iPendingProps[i], g_iPendingCels[i], g_iPendingEffects[i], g_iPendingRemoved[i], g_sSteamID[i]);
		txBeat.AddQuery(sQuery);

		g_iPlayMark[i] = GetTime();
		g_iPendingProps[i] = 0;
		g_iPendingCels[i] = 0;
		g_iPendingEffects[i] = 0;
		g_iPendingRemoved[i] = 0;

		FlushPlayerStats(i, txBeat);
	}

	FindConVar("hostname").GetString(sHostname, sizeof(sHostname));
	g_dbCelMod.Escape(sHostname, sEscHost, sizeof(sEscHost));
	GetServerAddress(sAddress, sizeof(sAddress));

	FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_servers (server_id, hostname, address, map, players, max_players, total_props, total_cels, version, map_started, updated_at) VALUES (%d, '%s', '%s', '%s', %d, %d, %d, %d, '%s', FROM_UNIXTIME(%d), NOW()) ON DUPLICATE KEY UPDATE hostname = VALUES(hostname), address = VALUES(address), map = VALUES(map), players = VALUES(players), max_players = VALUES(max_players), total_props = VALUES(total_props), total_cels = VALUES(total_cels), version = VALUES(version), map_started = VALUES(map_started), updated_at = NOW()", iServerID, sEscHost, sAddress, g_sMap, iPlayers, MaxClients, iTotalProps, iTotalCels, CEL_VERSION, g_iMapStart);
	txBeat.AddQuery(sQuery);

	// Anyone not on a live server (e.g. after a crash) is no longer online.
	txBeat.AddQuery("DELETE o FROM cm_online_players o JOIN cm_servers s ON s.server_id = o.server_id WHERE s.updated_at < NOW() - INTERVAL 5 MINUTE");
	txBeat.AddQuery("UPDATE cm_players p LEFT JOIN cm_online_players o ON o.steamid64 = p.steamid64 SET p.is_online = 0 WHERE p.is_online = 1 AND o.steamid64 IS NULL");

	g_dbCelMod.Execute(txBeat, SQL_OnTxnOk, SQL_OnTxnError);

	FlushDailyStats(iPlayers);

	// Pick up in-game purchases and stock changes about once a minute.
	if (++g_iTick % 4 == 0)
	{
		SyncShopItems();

		for (int i = 1; i <= MaxClients; i++)
		{
			if (g_bTracked[i])
			{
				SyncClientPurchases(i);
			}
		}
	}

	return Plugin_Continue;
}

void FlushDailyStats(int iPlayers)
{
	char sQuery[512];

	if (g_dbCelMod == null)
	{
		return;
	}

	FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_stats_daily (day, server_id, peak_players, props_spawned, cels_spawned, effects_spawned) VALUES (CURDATE(), %d, %d, %d, %d, %d) ON DUPLICATE KEY UPDATE peak_players = GREATEST(peak_players, VALUES(peak_players)), props_spawned = props_spawned + VALUES(props_spawned), cels_spawned = cels_spawned + VALUES(cels_spawned), effects_spawned = effects_spawned + VALUES(effects_spawned)", g_cvServerID.IntValue, iPlayers, g_iDayProps, g_iDayCels, g_iDayEffects);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	g_iDayProps = 0;
	g_iDayCels = 0;
	g_iDayEffects = 0;
}

public Action Timer_Sample(Handle hTimer)
{
	char sQuery[256];
	int iPlayers;

	if (g_dbCelMod == null)
	{
		return Plugin_Continue;
	}

	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && !IsFakeClient(i))
		{
			iPlayers++;
		}
	}

	FormatEx(sQuery, sizeof(sQuery), "INSERT IGNORE INTO cm_player_samples (server_id, recorded_at, players) VALUES (%d, NOW(), %d)", g_cvServerID.IntValue, iPlayers);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	return Plugin_Continue;
}

void LogMapStart()
{
	char sQuery[256];

	if (g_bMapLogged || g_sMap[0] == '\0')
	{
		return;
	}

	g_bMapLogged = true;

	FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_maps (map, times_played, last_played) VALUES ('%s', 1, NOW()) ON DUPLICATE KEY UPDATE times_played = times_played + 1, last_played = NOW()", g_sMap);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	LogEvent(0, "map_change", g_sMap);
}

void LogEvent(int iClient, const char[] sType, const char[] sDetail)
{
	char sEscDetail[257], sEscName[257], sName[128], sQuery[768], sSteam[40];

	if (g_dbCelMod == null)
	{
		return;
	}

	if (iClient > 0)
	{
		GetClientName(iClient, sName, sizeof(sName));
		FormatEx(sSteam, sizeof(sSteam), "'%s'", g_sSteamID[iClient]);
	} else {
		strcopy(sName, sizeof(sName), "Server");
		strcopy(sSteam, sizeof(sSteam), "NULL");
	}

	g_dbCelMod.Escape(sName, sEscName, sizeof(sEscName));
	g_dbCelMod.Escape(sDetail, sEscDetail, sizeof(sEscDetail));

	FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_events (server_id, steamid64, name, type, detail) VALUES (%d, %s, '%s', '%s', '%s')", g_cvServerID.IntValue, sSteam, sEscName, sType, sEscDetail);
	g_dbCelMod.Query(SQL_Generic, sQuery);
}

void GetServerAddress(char[] sAddress, int iMaxLength)
{
	g_cvAddress.GetString(sAddress, iMaxLength);

	if (sAddress[0] != '\0')
	{
		return;
	}

	int iIP = FindConVar("hostip").IntValue;

	FormatEx(sAddress, iMaxLength, "%d.%d.%d.%d:%d", (iIP >>> 24) & 0xFF, (iIP >>> 16) & 0xFF, (iIP >>> 8) & 0xFF, iIP & 0xFF, FindConVar("hostport").IntValue);
}

//Spawn counters:
public void Cel_OnPropSpawn(int iProp, int iOwner, EntityType etEntityType)
{
	if (iOwner > 0 && iOwner <= MaxClients)
	{
		g_iPendingProps[iOwner]++;
	}
	g_iDayProps++;
}

public void Cel_OnCelSpawn(int iCel, int iOwner, EntityType etEntityType)
{
	if (iOwner > 0 && iOwner <= MaxClients)
	{
		g_iPendingCels[iOwner]++;
	}
	g_iDayCels++;
}

public void Cel_OnEffectSpawn(int iEffect, int iOwner, EffectType etEffectType)
{
	if (iOwner > 0 && iOwner <= MaxClients)
	{
		g_iPendingEffects[iOwner]++;
	}
	g_iDayEffects++;
}

public void Cel_OnEntityRemove(int iEntity, int iOwner, bool bCel)
{
	if (iOwner > 0 && iOwner <= MaxClients)
	{
		g_iPendingRemoved[iOwner]++;
	}
}

//Web shop orders:
public Action Timer_PollOrders(Handle hTimer)
{
	char sIDs[2048], sQuery[2304];

	if (g_dbCelMod == null)
	{
		return Plugin_Continue;
	}

	for (int i = 1; i <= MaxClients; i++)
	{
		if (g_bTracked[i])
		{
			if (sIDs[0] != '\0')
			{
				StrCat(sIDs, sizeof(sIDs), ",");
			}
			Format(sIDs, sizeof(sIDs), "%s'%s'", sIDs, g_sSteamID[i]);
		}
	}

	if (sIDs[0] == '\0')
	{
		return Plugin_Continue;
	}

	FormatEx(sQuery, sizeof(sQuery), "SELECT id, steamid64, item, price FROM cm_web_orders WHERE status = 'pending' AND steamid64 IN (%s) ORDER BY id LIMIT 10", sIDs);
	g_dbCelMod.Query(SQL_OnPendingOrders, sQuery);

	return Plugin_Continue;
}

public void SQL_OnPendingOrders(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aData)
{
	char sItem[64], sQuery[256], sSteamID[32];

	if (rsResults == null)
	{
		LogError("|CelMod| Database error: %s", sError);
		return;
	}

	while (rsResults.FetchRow())
	{
		int iOrder = rsResults.FetchInt(0);
		rsResults.FetchString(1, sSteamID, sizeof(sSteamID));
		rsResults.FetchString(2, sItem, sizeof(sItem));
		int iOrderPrice = rsResults.FetchInt(3);

		// Claim the order first so two servers can never deliver it twice.
		FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_web_orders SET status = 'processing', server_id = %d WHERE id = %d AND status = 'pending'", g_cvServerID.IntValue, iOrder);

		DataPack dpOrder = new DataPack();
		dpOrder.WriteCell(iOrder);
		dpOrder.WriteString(sSteamID);
		dpOrder.WriteString(sItem);
		dpOrder.WriteCell(iOrderPrice);

		g_dbCelMod.Query(SQL_OnOrderClaimed, sQuery, dpOrder);
	}
}

public void SQL_OnOrderClaimed(Database dbDatabase, DBResultSet rsResults, const char[] sError, DataPack dpOrder)
{
	char sDeliverError[128], sItem[64], sQuery[512], sSteamID[32];
	int iClient;

	dpOrder.Reset();
	int iOrder = dpOrder.ReadCell();
	dpOrder.ReadString(sSteamID, sizeof(sSteamID));
	dpOrder.ReadString(sItem, sizeof(sItem));
	int iOrderPrice = dpOrder.ReadCell();
	delete dpOrder;

	if (rsResults == null)
	{
		LogError("|CelMod| Database error: %s", sError);
		return;
	}

	if (rsResults.AffectedRows != 1)
	{
		return; // another server took it
	}

	for (int i = 1; i <= MaxClients; i++)
	{
		if (g_bTracked[i] && StrEqual(g_sSteamID[i], sSteamID))
		{
			iClient = i;
			break;
		}
	}

	if (iClient == 0)
	{
		FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_web_orders SET status = 'pending', server_id = NULL WHERE id = %d", iOrder);
		g_dbCelMod.Query(SQL_Generic, sQuery);
		return;
	}

	// celmod-shop checks the item, stock, ownership and balance, charges and gives it.
	// It never charges more than the price the player saw on the website.
	int iPrice = Cel_ShopDeliver(iClient, sItem, iOrderPrice, sDeliverError, sizeof(sDeliverError));

	if (iPrice == -1)
	{
		FinishOrder(iOrder, "failed", sDeliverError);
		Cel_PrintToChat(iClient, "Your web shop order for {green}%s{default} failed: %s", sItem, sDeliverError);
		return;
	}

	Cel_PrintToChat(iClient, "Your web shop order for {green}%s{default} has arrived!", sItem);

	FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_web_orders SET price = %d WHERE id = %d", iPrice, iOrder);
	g_dbCelMod.Query(SQL_Generic, sQuery);
	FinishOrder(iOrder, "completed", "Delivered in-game.");

	FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_purchases (steamid64, item, source) VALUES ('%s', '%s', 'web') ON DUPLICATE KEY UPDATE source = 'web'", sSteamID, sItem);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_players SET balance = %d WHERE steamid64 = '%s'", Cel_GetClientBalance(iClient), sSteamID);
	g_dbCelMod.Query(SQL_Generic, sQuery);

	LogEvent(iClient, "web_purchase", sItem);

	SyncShopItems(); // stock went down
}

void FinishOrder(int iOrder, const char[] sStatus, const char[] sMessage)
{
	char sEscMessage[512], sQuery[768];

	g_dbCelMod.Escape(sMessage, sEscMessage, sizeof(sEscMessage));

	FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_web_orders SET status = '%s', message = '%s', processed_at = NOW() WHERE id = %d", sStatus, sEscMessage, iOrder);
	g_dbCelMod.Query(SQL_Generic, sQuery);
}

//Callbacks:
public void SQL_OnMigration(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aData)
{
	if (rsResults == null && StrContains(sError, "Duplicate column", false) == -1)
	{
		LogError("|CelMod| Database upgrade failed: %s", sError);
	}
}

public void SQL_Generic(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aData)
{
	if (rsResults == null)
	{
		LogError("|CelMod| Database error: %s", sError);
	}
}

public void SQL_OnTxnOk(Database dbDatabase, any aData, int iNumQueries, DBResultSet[] rsResults, any[] aQueryData)
{
}

public void SQL_OnTxnError(Database dbDatabase, any aData, int iNumQueries, const char[] sError, int iFailIndex, any[] aQueryData)
{
	LogError("|CelMod| Database transaction failed at query %d: %s", iFailIndex, sError);
}

//Leaderboard stats:
public APLRes AskPluginLoad2(Handle hMyself, bool bLate, char[] sError, int iErr_max)
{
	CreateNative("Cel_AddPlayerStat", Native_AddPlayerStat);
	MarkNativeAsOptional("Cel_SetEmblemDroppable");
	MarkNativeAsOptional("Cel_ResetEmblemDroppable");
	MarkNativeAsOptional("Cel_StartEmblemDrop");
	MarkNativeAsOptional("Cel_SetEmblemGiftList");
	CreateNative("Cel_SetPlayerStat", Native_SetPlayerStat);

	RegPluginLibrary("celmod-database");

	return APLRes_Success;
}

int FindStat(const char[] sStat)
{
	for (int i = 0; i < PLAYER_STATS; i++)
	{
		if (StrEqual(g_sStatColumn[i], sStat, false))
		{
			return i;
		}
	}

	return -1;
}

public int Native_AddPlayerStat(Handle hPlugin, int iNumParams)
{
	char sStat[32];
	int iClient = GetNativeCell(1);

	GetNativeString(2, sStat, sizeof(sStat));

	int iStat = FindStat(sStat);

	if (iClient < 1 || iClient > MaxClients || iStat == -1 || g_bStatAbsolute[iStat])
	{
		return 0;
	}

	g_iPendingStat[iClient][iStat] += GetNativeCell(3);
	g_bStatChanged[iClient][iStat] = true;

	return 0;
}

public int Native_SetPlayerStat(Handle hPlugin, int iNumParams)
{
	char sStat[32];
	int iClient = GetNativeCell(1);

	GetNativeString(2, sStat, sizeof(sStat));

	int iStat = FindStat(sStat);

	if (iClient < 1 || iClient > MaxClients || iStat == -1 || !g_bStatAbsolute[iStat])
	{
		return 0;
	}

	g_iPendingStat[iClient][iStat] = GetNativeCell(3);
	g_bStatChanged[iClient][iStat] = true;

	return 0;
}

//Player kills and deaths, for the leaderboards.
public void Event_StatsPlayerDeath(Event eEvent, const char[] sName, bool bDontBroadcast)
{
	int iVictim = GetClientOfUserId(eEvent.GetInt("userid"));
	int iAttacker = GetClientOfUserId(eEvent.GetInt("attacker"));

	if (iVictim > 0 && !IsFakeClient(iVictim))
	{
		g_iPendingStat[iVictim][2]++;
		g_bStatChanged[iVictim][2] = true;
	}

	if (iAttacker > 0 && iAttacker != iVictim && !IsFakeClient(iAttacker))
	{
		g_iPendingStat[iAttacker][1]++;
		g_bStatChanged[iAttacker][1] = true;
	}
}

//Writes a player's changed stats, in the heartbeat's transaction or on its own.
void FlushPlayerStats(int iClient, Transaction txAdd)
{
	char sQuery[512], sPart[64];

	if (!g_bTracked[iClient] && txAdd != null)
	{
		return;
	}

	sQuery[0] = '\0';

	for (int i = 0; i < PLAYER_STATS; i++)
	{
		if (!g_bStatChanged[iClient][i])
		{
			continue;
		}

		if (g_bStatAbsolute[i])
		{
			FormatEx(sPart, sizeof(sPart), "%s = %d", g_sStatColumn[i], g_iPendingStat[iClient][i]);
		} else {
			FormatEx(sPart, sizeof(sPart), "%s = %s + %d", g_sStatColumn[i], g_sStatColumn[i], g_iPendingStat[iClient][i]);
			g_iPendingStat[iClient][i] = 0;
		}

		g_bStatChanged[iClient][i] = false;

		Format(sQuery, sizeof(sQuery), "%s%s%s", sQuery, sQuery[0] == '\0' ? "" : ", ", sPart);
	}

	if (sQuery[0] == '\0' || g_dbCelMod == null)
	{
		return;
	}

	Format(sQuery, sizeof(sQuery), "UPDATE cm_players SET %s WHERE steamid64 = '%s'", sQuery, g_sSteamID[iClient]);

	if (txAdd != null)
	{
		txAdd.AddQuery(sQuery);
	} else {
		g_dbCelMod.Query(SQL_Generic, sQuery);
	}
}

//!dispute: a menu of the other players, then of what's wrong. The report goes to the admins on the server, the
//website's admin panel (Disputes tab) and data/celmod/disputes.txt.
public Action Command_Dispute(int iClient, int iArgs)
{
	char sInfo[16], sName[MAX_NAME_LENGTH];

	if (iClient < 1 || !IsClientInGame(iClient))
	{
		return Plugin_Handled;
	}

	if (g_fLastDispute[iClient] > 0.0 && GetEngineTime() - g_fLastDispute[iClient] < 60.0)
	{
		Cel_ReplyToCommand(iClient, "Thanks, the admins have your last dispute. Please wait a minute before sending another.");
		return Plugin_Handled;
	}

	Menu mPlayers = new Menu(Menu_DisputePlayer);

	mPlayers.SetTitle("|CelMod| Dispute\nWho is causing you problems?");

	for (int i = 1; i <= MaxClients; i++)
	{
		if (i != iClient && IsClientInGame(i) && !IsFakeClient(i))
		{
			IntToString(GetClientUserId(i), sInfo, sizeof(sInfo));
			GetClientName(i, sName, sizeof(sName));
			mPlayers.AddItem(sInfo, sName);
		}
	}

	if (mPlayers.ItemCount < 1)
	{
		delete mPlayers;
		Cel_ReplyToCommand(iClient, "There's nobody else on the server to report. If something else is wrong, use {green}!reportbug{default}.");
		return Plugin_Handled;
	}

	mPlayers.Display(iClient, 30);

	return Plugin_Handled;
}

public int Menu_DisputePlayer(Menu mMenu, MenuAction maAction, int iClient, int iItem)
{
	if (maAction == MenuAction_End)
	{
		delete mMenu;
	} else if (maAction == MenuAction_Select)
	{
		char sInfo[16], sTitle[128];

		mMenu.GetItem(iItem, sInfo, sizeof(sInfo));

		int iTarget = GetClientOfUserId(StringToInt(sInfo));

		if (iTarget < 1)
		{
			Cel_PrintToChat(iClient, "That player has left the server.");
			return 0;
		}

		g_iDisputeTarget[iClient] = GetClientUserId(iTarget);

		Menu mReasons = new Menu(Menu_DisputeReason);

		FormatEx(sTitle, sizeof(sTitle), "|CelMod| Dispute: %N\nWhat are they doing?", iTarget);
		mReasons.SetTitle(sTitle);

		for (int i = 0; i < sizeof(g_sDisputeReasons); i++)
		{
			IntToString(i, sInfo, sizeof(sInfo));
			mReasons.AddItem(sInfo, g_sDisputeReasons[i]);
		}

		mReasons.ExitBackButton = false;
		mReasons.Display(iClient, 30);
	}

	return 0;
}

public int Menu_DisputeReason(Menu mMenu, MenuAction maAction, int iClient, int iItem)
{
	if (maAction == MenuAction_End)
	{
		delete mMenu;
	} else if (maAction == MenuAction_Select)
	{
		int iReason = iItem;

		if (iReason == sizeof(g_sDisputeReasons) - 1)
		{
			g_bDisputeTyping[iClient] = true;

			Cel_PrintToChat(iClient, "Type what's happening in chat (your message only goes to the admins). Type {green}cancel{default} to stop.");
			return 0;
		}

		SendDispute(iClient, iReason, "");
	}

	return 0;
}

//The "Other" text: the next thing the player says is the dispute, and isn't shown in chat.
public Action Listener_DisputeChat(int iClient, const char[] sCommand, int iArgs)
{
	char sText[256];

	if (iClient < 1 || !g_bDisputeTyping[iClient])
	{
		return Plugin_Continue;
	}

	GetCmdArgString(sText, sizeof(sText));
	StripQuotes(sText);
	TrimString(sText);

	if (sText[0] == '\0' || sText[0] == '!' || sText[0] == '/')
	{
		return Plugin_Continue;
	}

	g_bDisputeTyping[iClient] = false;

	if (StrEqual(sText, "cancel", false))
	{
		Cel_PrintToChat(iClient, "Dispute cancelled.");
		return Plugin_Handled;
	}

	SendDispute(iClient, sizeof(g_sDisputeReasons) - 1, sText);

	return Plugin_Handled;
}

void SendDispute(int iClient, int iReason, const char[] sMessage)
{
	char sName[64], sTargetName[64], sTargetSteam[32] = "", sReason[64], sQuery[1600];
	char sEscName[136], sEscTarget[136], sEscMap[136], sEscReason[136], sEscMessage[520];

	int iTarget = GetClientOfUserId(g_iDisputeTarget[iClient]);

	if (iTarget < 1 || !IsClientInGame(iTarget))
	{
		Cel_PrintToChat(iClient, "That player has left the server, so the dispute wasn't sent.");
		return;
	}

	g_fLastDispute[iClient] = GetEngineTime();

	strcopy(sReason, sizeof(sReason), iReason == sizeof(g_sDisputeReasons) - 1 ? "Other" : g_sDisputeReasons[iReason]);
	GetClientName(iClient, sName, sizeof(sName));
	GetClientName(iTarget, sTargetName, sizeof(sTargetName));
	GetClientAuthId(iTarget, AuthId_SteamID64, sTargetSteam, sizeof(sTargetSteam));

	bool bDemo = StartDisputeDemo(iClient, iTarget);

	if (g_dbCelMod != null && g_sSteamID[iClient][0] != '\0'
		&& g_dbCelMod.Escape(sName, sEscName, sizeof(sEscName)) && g_dbCelMod.Escape(sTargetName, sEscTarget, sizeof(sEscTarget))
		&& g_dbCelMod.Escape(g_sMap, sEscMap, sizeof(sEscMap)) && g_dbCelMod.Escape(sReason, sEscReason, sizeof(sEscReason))
		&& g_dbCelMod.Escape(sMessage, sEscMessage, sizeof(sEscMessage)))
	{
		FormatEx(sQuery, sizeof(sQuery), "INSERT INTO cm_disputes (server_id, steamid64, name, target_steamid64, target_name, map, reason, message, demo) VALUES (%d, '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s.dem')", g_cvServerID.IntValue, g_sSteamID[iClient], sEscName, sTargetSteam, sEscTarget, sEscMap, sEscReason, sEscMessage, bDemo ? g_sDisputeDemo : "");
		ReplaceString(sQuery, sizeof(sQuery), "'.dem')", "'')");

		g_dbCelMod.Query(SQL_Generic, sQuery);
	}

	char sPath[PLATFORM_MAX_PATH];

	BuildPath(Path_SM, sPath, sizeof(sPath), "data/celmod/disputes.txt");
	LogToFileEx(sPath, "%N against %N (%s) on %s: %s%s%s%s%s", iClient, iTarget, sTargetSteam, g_sMap, sReason, sMessage[0] != '\0' ? ": " : "", sMessage, bDemo ? " | demo: " : "", bDemo ? g_sDisputeDemo : "");

	for (int i = 1; i <= MaxClients; i++)
	{
		if (i != iClient && IsClientInGame(i) && !IsFakeClient(i) && CheckCommandAccess(i, "cm_disputes_notify", ADMFLAG_GENERIC))
		{
			Cel_PrintToChat(i, "Dispute from {green}%N{default} against {green}%N{default}: %s%s%s", iClient, iTarget, sReason, sMessage[0] != '\0' ? ": " : "", sMessage);
		}
	}

	Cel_PrintToChat(iClient, "Thanks! Your dispute about {green}%N{default} was sent to the admins. Use {green}!landban{default} to keep them off your land meanwhile.", iTarget);
}

//!disputes: the open disputes (newest first) in a menu, read from the database the website's Disputes tab uses.
//Without the database, the last ones from data/celmod/disputes.txt are printed in the console.
public Action Command_Disputes(int iClient, int iArgs)
{
	char sArg[16], sQuery[512];
	
	GetCmdArg(1, sArg, sizeof(sArg));
	
	bool bAll = StrEqual(sArg, "all", false);
	
	if (g_dbCelMod == null)
	{
		PrintDisputeLog(iClient);
		return Plugin_Handled;
	}
	
	FormatEx(sQuery, sizeof(sQuery), "SELECT id, name, target_name, reason, status, TIMESTAMPDIFF(MINUTE, created_at, NOW()) FROM cm_disputes %s ORDER BY id DESC LIMIT 50", bAll ? "" : "WHERE status = 'open'");
	
	g_dbCelMod.Query(SQL_OnDisputeList, sQuery, iClient > 0 ? GetClientUserId(iClient) : 0);
	
	return Plugin_Handled;
}

void PrintDisputeLog(int iClient)
{
	char sPath[PLATFORM_MAX_PATH], sLine[512];
	ArrayList alLines = new ArrayList(ByteCountToCells(sizeof(sLine)));
	
	BuildPath(Path_SM, sPath, sizeof(sPath), "data/celmod/disputes.txt");
	
	File fLog = OpenFile(sPath, "r");
	
	if (fLog != null)
	{
		while (fLog.ReadLine(sLine, sizeof(sLine)))
		{
			TrimString(sLine);
			
			if (sLine[0] != '\0')
			{
				alLines.PushString(sLine);
			}
		}
		
		delete fLog;
	}
	
	if (alLines.Length == 0)
	{
		Cel_ReplyToCommand(iClient, "There are no disputes.");
	} else {
		int iFrom = alLines.Length > 15 ? alLines.Length - 15 : 0;
		
		Cel_ReplyToCommand(iClient, "The database is offline: the last {green}%d{default} disputes are in your console.", alLines.Length - iFrom);
		
		for (int i = iFrom; i < alLines.Length; i++)
		{
			alLines.GetString(i, sLine, sizeof(sLine));
			
			if (iClient > 0)
			{
				PrintToConsole(iClient, "%s", sLine);
			} else {
				PrintToServer("%s", sLine);
			}
		}
	}
	
	delete alLines;
}

//A short "5m", "3h" or "2d" for how long ago a dispute was sent.
void FormatAgo(int iMinutes, char[] sAgo, int iMaxLength)
{
	if (iMinutes < 60)
	{
		FormatEx(sAgo, iMaxLength, "%dm", iMinutes);
	} else if (iMinutes < 1440)
	{
		FormatEx(sAgo, iMaxLength, "%dh", iMinutes / 60);
	} else {
		FormatEx(sAgo, iMaxLength, "%dd", iMinutes / 1440);
	}
}

public void SQL_OnDisputeList(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aUserId)
{
	int iClient = GetClientOfUserId(aUserId);
	
	if (aUserId != 0 && (iClient < 1 || !IsClientInGame(iClient)))
	{
		return;
	}
	
	if (rsResults == null)
	{
		LogError("|CelMod| Could not read disputes: %s", sError);
		Cel_ReplyToCommand(iClient, "Couldn't read the disputes from the database right now.");
		return;
	}
	
	if (rsResults.RowCount == 0)
	{
		Cel_ReplyToCommand(iClient, "There are no open disputes. {green}!disputes all{default} shows finished ones too.");
		return;
	}
	
	char sName[64], sTarget[64], sReason[64], sStatus[16], sAgo[16], sItem[192], sId[16];
	
	//From the server console: a plain list.
	if (iClient == 0)
	{
		while (rsResults.FetchRow())
		{
			rsResults.FetchString(1, sName, sizeof(sName));
			rsResults.FetchString(2, sTarget, sizeof(sTarget));
			rsResults.FetchString(3, sReason, sizeof(sReason));
			rsResults.FetchString(4, sStatus, sizeof(sStatus));
			FormatAgo(rsResults.FetchInt(5), sAgo, sizeof(sAgo));
			PrintToServer("#%d [%s, %s ago] %s against %s: %s", rsResults.FetchInt(0), sStatus, sAgo, sName, sTarget, sReason);
		}
		
		return;
	}
	
	Menu mList = new Menu(Menu_DisputeList);
	
	mList.SetTitle("|CelMod| Disputes (%d)\nPick one to read it", rsResults.RowCount);
	
	while (rsResults.FetchRow())
	{
		int iId = rsResults.FetchInt(0);
		
		rsResults.FetchString(1, sName, sizeof(sName));
		rsResults.FetchString(2, sTarget, sizeof(sTarget));
		rsResults.FetchString(3, sReason, sizeof(sReason));
		rsResults.FetchString(4, sStatus, sizeof(sStatus));
		FormatAgo(rsResults.FetchInt(5), sAgo, sizeof(sAgo));
		
		FormatEx(sItem, sizeof(sItem), "%s%s vs %s: %s (%s)", StrEqual(sStatus, "open") ? "" : "[done] ", sName, sTarget, sReason, sAgo);
		IntToString(iId, sId, sizeof(sId));
		mList.AddItem(sId, sItem);
	}
	
	mList.Display(iClient, MENU_TIME_FOREVER);
}

public int Menu_DisputeList(Menu mMenu, MenuAction maAction, int iClient, int iItem)
{
	if (maAction == MenuAction_End)
	{
		delete mMenu;
	} else if (maAction == MenuAction_Select && g_dbCelMod != null)
	{
		char sId[16], sQuery[512];
		
		mMenu.GetItem(iItem, sId, sizeof(sId));
		
		FormatEx(sQuery, sizeof(sQuery), "SELECT id, name, steamid64, target_name, target_steamid64, map, reason, message, demo, status, admin_note, TIMESTAMPDIFF(MINUTE, created_at, NOW()) FROM cm_disputes WHERE id = %d", StringToInt(sId));
		
		g_dbCelMod.Query(SQL_OnDisputeDetail, sQuery, GetClientUserId(iClient));
	}
	
	return 0;
}

public void SQL_OnDisputeDetail(Database dbDatabase, DBResultSet rsResults, const char[] sError, any aUserId)
{
	int iClient = GetClientOfUserId(aUserId);
	
	if (iClient < 1 || !IsClientInGame(iClient) || rsResults == null || !rsResults.FetchRow())
	{
		return;
	}
	
	char sName[64], sSteam[24], sTarget[64], sTargetSteam[24], sMap[64], sReason[64], sMessage[256], sDemo[128], sStatus[16], sNote[256], sAgo[16], sText[1024], sId[16];
	
	int iId = rsResults.FetchInt(0);
	
	rsResults.FetchString(1, sName, sizeof(sName));
	rsResults.FetchString(2, sSteam, sizeof(sSteam));
	rsResults.FetchString(3, sTarget, sizeof(sTarget));
	rsResults.FetchString(4, sTargetSteam, sizeof(sTargetSteam));
	rsResults.FetchString(5, sMap, sizeof(sMap));
	rsResults.FetchString(6, sReason, sizeof(sReason));
	rsResults.FetchString(7, sMessage, sizeof(sMessage));
	rsResults.FetchString(8, sDemo, sizeof(sDemo));
	rsResults.FetchString(9, sStatus, sizeof(sStatus));
	rsResults.FetchString(10, sNote, sizeof(sNote));
	FormatAgo(rsResults.FetchInt(11), sAgo, sizeof(sAgo));
	
	//The full details (Steam IDs, the demo's file name) go to the console, where they can be copied.
	PrintToConsole(iClient, "|CelMod| Dispute #%d (%s, %s ago, on %s)", iId, sStatus, sAgo, sMap);
	PrintToConsole(iClient, "  From:    %s (%s)", sName, sSteam);
	PrintToConsole(iClient, "  Against: %s (%s)", sTarget, sTargetSteam);
	PrintToConsole(iClient, "  Reason:  %s%s%s", sReason, sMessage[0] != '\0' ? ": " : "", sMessage);
	
	if (sDemo[0] != '\0')
	{
		PrintToConsole(iClient, "  Demo:    %s (on the server)", sDemo);
	}
	
	if (sNote[0] != '\0')
	{
		PrintToConsole(iClient, "  Note:    %s", sNote);
	}
	
	FormatEx(sText, sizeof(sText), "|CelMod| Dispute #%d (%s, %s ago)\n \nFrom: %s\nAgainst: %s\nMap: %s\nReason: %s%s%s%s%s\n ", iId, sStatus, sAgo, sName, sTarget, sMap, sReason, sMessage[0] != '\0' ? "\n" : "", sMessage, sDemo[0] != '\0' ? "\nDemo: " : "", sDemo);
	
	Menu mDetail = new Menu(Menu_DisputeDetail);
	
	mDetail.SetTitle("%s\n(Steam IDs are in your console)", sText);
	
	IntToString(iId, sId, sizeof(sId));
	
	char sInfo[24];
	
	FormatEx(sInfo, sizeof(sInfo), "resolved:%s", sId);
	mDetail.AddItem(sInfo, "Mark resolved", StrEqual(sStatus, "resolved") ? ITEMDRAW_DISABLED : ITEMDRAW_DEFAULT);
	FormatEx(sInfo, sizeof(sInfo), "closed:%s", sId);
	mDetail.AddItem(sInfo, "Close (no action needed)", StrEqual(sStatus, "closed") ? ITEMDRAW_DISABLED : ITEMDRAW_DEFAULT);
	FormatEx(sInfo, sizeof(sInfo), "open:%s", sId);
	mDetail.AddItem(sInfo, "Reopen", StrEqual(sStatus, "open") ? ITEMDRAW_DISABLED : ITEMDRAW_DEFAULT);
	
	mDetail.ExitBackButton = true;
	mDetail.Display(iClient, MENU_TIME_FOREVER);
}

public int Menu_DisputeDetail(Menu mMenu, MenuAction maAction, int iClient, int iItem)
{
	if (maAction == MenuAction_End)
	{
		delete mMenu;
	} else if (maAction == MenuAction_Cancel && iItem == MenuCancel_ExitBack)
	{
		FakeClientCommand(iClient, "v_disputes");
	} else if (maAction == MenuAction_Select && g_dbCelMod != null)
	{
		char sInfo[24], sParts[2][16], sQuery[256], sAdmin[64], sNote[200], sEscNote[420];
		
		mMenu.GetItem(iItem, sInfo, sizeof(sInfo));
		ExplodeString(sInfo, ":", sParts, sizeof(sParts), sizeof(sParts[]));
		
		//The note says who handled it, in game, like the website's admin panel does.
		GetClientName(iClient, sAdmin, sizeof(sAdmin));
		FormatEx(sNote, sizeof(sNote), "%s in game by %s", sParts[0], sAdmin);
		g_dbCelMod.Escape(sNote, sEscNote, sizeof(sEscNote));
		
		FormatEx(sQuery, sizeof(sQuery), "UPDATE cm_disputes SET status = '%s', admin_note = IF(admin_note = '', '%s', admin_note) WHERE id = %d", sParts[0], sEscNote, StringToInt(sParts[1]));
		g_dbCelMod.Query(SQL_Generic, sQuery);
		
		Cel_PrintToChat(iClient, "Dispute #%s is now {green}%s{default}.", sParts[1], sParts[0]);
		LogAction(iClient, -1, "\"%L\" set dispute #%s to %s", iClient, sParts[1], sParts[0]);
	}
	
	return 0;
}

//The SourceTV bot, or 0 when SourceTV is off.
int GetSourceTV()
{
	for (int i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && IsClientSourceTV(i))
		{
			return i;
		}
	}

	return 0;
}

//Starts (or lengthens) a dispute demo, like the original server's "Recording Dispute demo...". The details of the
//reported player are printed into it, so whoever watches it knows who it's about. Returns false when no demo is made.
bool StartDisputeDemo(int iClient, int iTarget)
{
	int iTV = GetSourceTV();

	if (!g_cvDisputeDemo.BoolValue || iTV == 0)
	{
		return false;
	}

	// A demo SourceTV records on its own (tv_autorecord) can't run alongside ours.
	ConVar cvAuto = FindConVar("tv_autorecord");

	if (!g_bDisputeRecording && cvAuto != null && cvAuto.BoolValue)
	{
		return false;
	}

	if (!g_bDisputeRecording)
	{
		char sTime[32];

		FormatTime(sTime, sizeof(sTime), "%Y%m%d-%H%M%S");
		FormatEx(g_sDisputeDemo, sizeof(g_sDisputeDemo), "dispute_%s_%s", sTime, g_sMap);

		ServerCommand("tv_record \"%s\"", g_sDisputeDemo);

		g_bDisputeRecording = true;
	}

	delete g_hDisputeDemoStop;
	g_hDisputeDemoStop = CreateTimer(g_cvDisputeDemoSeconds.FloatValue, Timer_StopDisputeDemo);

	Cel_PrintToChat(iClient, "Recording Dispute demo...");

	// A moment later, once the recording has begun, so the lines are in it.
	DataPack dpInfo;

	CreateDataTimer(1.0, Timer_DisputeDemoInfo, dpInfo);
	dpInfo.WriteCell(GetClientUserId(iClient));
	dpInfo.WriteCell(GetClientUserId(iTarget));

	return true;
}

public Action Timer_DisputeDemoInfo(Handle hTimer, DataPack dpInfo)
{
	char sName[MAX_NAME_LENGTH], sSteam[32], sIP[32], sCountry[64], sTime[32];

	dpInfo.Reset();

	int iClient = GetClientOfUserId(dpInfo.ReadCell()), iTarget = GetClientOfUserId(dpInfo.ReadCell()), iTV = GetSourceTV();

	if (iTarget < 1 || iTV == 0)
	{
		return Plugin_Stop;
	}

	GetClientName(iTarget, sName, sizeof(sName));

	if (!GetClientAuthId(iTarget, AuthId_Steam2, sSteam, sizeof(sSteam)))
	{
		strcopy(sSteam, sizeof(sSteam), "unknown");
	}

	GetClientIP(iTarget, sIP, sizeof(sIP));

	if (!GeoipCountry(sIP, sCountry, sizeof(sCountry)))
	{
		strcopy(sCountry, sizeof(sCountry), "Unknown");
	}

	FormatTime(sTime, sizeof(sTime), "%m/%d/%Y %H:%M:%S");

	// The full details, IP included, only go into the demo (it's recorded by SourceTV on the server, for admins).
	Cel_PrintToChat(iTV, "Recording Dispute demo...");
	Cel_PrintToChat(iTV, "Name: %s, SteamID: %s, IP: %s, Country: %s, Time: %s, Map: %s", sName, sSteam, sIP, sCountry, sTime, g_sMap);

	if (iClient > 0 && IsClientInGame(iClient))
	{
		Cel_PrintToChat(iTV, "Reported by: %N", iClient);

		// The player who reported sees the same line without the other player's IP address.
		Cel_PrintToChat(iClient, "Name: {green}%s{default}, SteamID: {green}%s{default}, Country: {green}%s{default}, Time: {green}%s{default}, Map: {green}%s{default}", sName, sSteam, sCountry, sTime, g_sMap);
	}

	return Plugin_Stop;
}

public Action Timer_StopDisputeDemo(Handle hTimer)
{
	g_hDisputeDemoStop = null;

	if (g_bDisputeRecording)
	{
		ServerCommand("tv_stoprecord");

		g_bDisputeRecording = false;
	}

	return Plugin_Stop;
}

//!news: the latest updates from the website's admin panel (Updates tab), in a panel. "Full list" opens the updates
//page (!updates). Without the database it goes straight to that page.
public Action Command_News(int iClient, int iArgs)
{
	if (iClient < 1 || !IsClientInGame(iClient))
	{
		return Plugin_Handled;
	}

	if (g_dbCelMod == null)
	{
		FakeClientCommand(iClient, "v_updates");
		return Plugin_Handled;
	}

	g_dbCelMod.Query(SQL_OnNews, "SELECT DATE_FORMAT(posted_on, '%c/%e/%Y'), body FROM cm_updates WHERE published = 1 ORDER BY posted_on DESC, id DESC LIMIT 3", GetClientUserId(iClient));

	return Plugin_Handled;
}

public void SQL_OnNews(Database dbDatabase, DBResultSet rsResults, const char[] sError, any iUserId)
{
	char sDate[16], sBody[2048], sLines[24][128], sLine[160];
	int iClient = GetClientOfUserId(iUserId);

	if (iClient < 1 || !IsClientInGame(iClient))
	{
		return;
	}

	if (rsResults == null || rsResults.RowCount < 1)
	{
		FakeClientCommand(iClient, "v_updates");
		return;
	}

	Panel pNews = new Panel();

	pNews.SetTitle("|CelMod| What's new\n ");

	int iShown = 0;

	while (rsResults.FetchRow() && iShown < 14)
	{
		rsResults.FetchString(0, sDate, sizeof(sDate));
		rsResults.FetchString(1, sBody, sizeof(sBody));

		// The website's formatting marks aren't shown in game.
		ReplaceString(sBody, sizeof(sBody), "**", "");
		ReplaceString(sBody, sizeof(sBody), "__", "");
		ReplaceString(sBody, sizeof(sBody), "`", "");
		ReplaceString(sBody, sizeof(sBody), "\r", "");

		FormatEx(sLine, sizeof(sLine), "-=- %s", sDate);
		pNews.DrawText(sLine);
		iShown++;

		int iCount = ExplodeString(sBody, "\n", sLines, sizeof(sLines), sizeof(sLines[]));

		for (int i = 0; i < iCount && iShown < 14; i++)
		{
			TrimString(sLines[i]);

			if (sLines[i][0] == '\0')
			{
				continue;
			}

			// Long lines are cut so the panel stays readable; the full text is on the website.
			if (strlen(sLines[i]) > 70)
			{
				strcopy(sLines[i][67], 4, "...");
			}

			FormatEx(sLine, sizeof(sLine), "   %s", sLines[i]);
			pNews.DrawText(sLine);
			iShown++;
		}

		pNews.DrawText(" ");
	}

	pNews.DrawItem("Full list of updates");
	pNews.DrawItem("Close");

	pNews.Send(iClient, Panel_News, 30);

	delete pNews;
}

public int Panel_News(Menu mMenu, MenuAction maAction, int iClient, int iItem)
{
	if (maAction == MenuAction_Select && iItem == 1)
	{
		FakeClientCommand(iClient, "v_updates");
	}

	return 0;
}
